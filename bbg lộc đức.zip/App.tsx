import React, { useState, useEffect } from 'react';
import { CustomerInfo, CartItem, QuoteSettings, Product } from './types';
import { MOCK_PRODUCTS } from './constants';
import QuoteTemplate from './components/QuoteTemplate';
import { generateQuoteNote, generateEmailDraft, suggestAccessories } from './services/geminiService';
import { 
  Printer, 
  Send, 
  Plus, 
  Trash2, 
  Search, 
  Settings, 
  Sparkles,
  ShoppingCart,
  FileText,
  Save,
  Wand2,
  X,
  Mail,
  Copy,
  Percent,
  Stamp
} from 'lucide-react';

const App: React.FC = () => {
  // State initialization with localStorage check
  const [customer, setCustomer] = useState<CustomerInfo>(() => {
    const saved = localStorage.getItem('ld_customer');
    return saved ? JSON.parse(saved) : {
      companyName: '',
      taxId: '',
      contactPerson: '',
      phone: '',
      address: '',
      email: '',
    };
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('ld_cart');
    return saved ? JSON.parse(saved) : [];
  });

  const [settings, setSettings] = useState<QuoteSettings>(() => {
    const saved = localStorage.getItem('ld_settings');
    const defaults = {
      vatRate: 0.10,
      quoteDate: new Date().toISOString(),
      quoteNumber: `BG-${new Date().getFullYear()}${Math.floor(Math.random() * 10000)}`,
      notes: '',
      showStamp: true,
    };
    return saved ? { ...defaults, ...JSON.parse(saved) } : defaults;
  });

  const [searchTerm, setSearchTerm] = useState('');
  const [isGeneratingNote, setIsGeneratingNote] = useState(false);
  const [isSuggesting, setIsSuggesting] = useState(false);
  const [activeTab, setActiveTab] = useState<'customer' | 'products' | 'settings'>('customer');
  
  // Custom Product State
  const [showCustomProduct, setShowCustomProduct] = useState(false);
  const [customProduct, setCustomProduct] = useState<Partial<Product>>({
    name: '', price: 0, unit: 'Cái', specs: '', image: 'https://placehold.co/100x100?text=Product'
  });

  // Email Modal State
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [emailDraft, setEmailDraft] = useState<{subject: string, body: string} | null>(null);
  const [isDraftingEmail, setIsDraftingEmail] = useState(false);

  // Persistence Effect
  useEffect(() => {
    localStorage.setItem('ld_customer', JSON.stringify(customer));
    localStorage.setItem('ld_cart', JSON.stringify(cart));
    localStorage.setItem('ld_settings', JSON.stringify(settings));
  }, [customer, cart, settings]);

  // Handlers
  const handleAddToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => 
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...product, quantity: 1, discount: 0 }];
    });
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        return { ...item, quantity: Math.max(1, item.quantity + delta) };
      }
      return item;
    }));
  };

  const handleUpdateDiscount = (id: string, val: string) => {
    const num = Math.min(100, Math.max(0, parseFloat(val) || 0));
    setCart(prev => prev.map(item => 
      item.id === id ? { ...item, discount: num } : item
    ));
  };

  const handleRemoveItem = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const handleAddCustomProduct = () => {
    if (!customProduct.name || !customProduct.price) return;
    const newProduct: Product = {
      id: `custom-${Date.now()}`,
      sku: 'CUSTOM',
      name: customProduct.name,
      price: Number(customProduct.price),
      unit: customProduct.unit || 'Cái',
      specs: customProduct.specs || 'N/A',
      image: customProduct.image || 'https://placehold.co/100x100'
    };
    handleAddToCart(newProduct);
    setShowCustomProduct(false);
    setCustomProduct({ name: '', price: 0, unit: 'Cái', specs: '', image: 'https://placehold.co/100x100?text=Product' });
  };

  const handlePrint = () => {
    window.print();
  };

  const handleGenerateAINote = async () => {
    setIsGeneratingNote(true);
    const note = await generateQuoteNote(customer, cart);
    setSettings(prev => ({ ...prev, notes: note }));
    setIsGeneratingNote(false);
  };

  const handleSuggestProducts = async () => {
    if (cart.length === 0) {
      alert("Vui lòng thêm sản phẩm vào giỏ trước để nhận gợi ý.");
      return;
    }
    setIsSuggesting(true);
    const suggestions = await suggestAccessories(cart);
    if (suggestions.length > 0) {
      // Add suggestions directly to list if not present, or just show them. 
      // For simplicity, let's append them to the cart directly or show a confirm.
      // Better UX: Show them in a temporary list.
      // Hack for now: Add them to MOCK_PRODUCTS temporarily or just handleAddToCart them one by one via alert/confirm?
      // Let's just add them to the cart for the user to review.
      suggestions.forEach(p => handleAddToCart(p));
      alert(`Đã thêm ${suggestions.length} gợi ý từ AI vào giỏ hàng!`);
    } else {
      alert("Không tìm thấy gợi ý phù hợp.");
    }
    setIsSuggesting(false);
  };

  const handleDraftEmail = async () => {
    if (!customer.email) {
      alert("Vui lòng nhập Email khách hàng trước.");
      setActiveTab('customer');
      return;
    }
    setShowEmailModal(true);
    setIsDraftingEmail(true);
    
    const total = cart.reduce((sum, item) => {
       const lineTotal = item.price * item.quantity * (1 - (item.discount||0)/100);
       return sum + lineTotal;
    }, 0) * (1 + settings.vatRate);

    const draft = await generateEmailDraft(customer, cart, total);
    setEmailDraft(draft);
    setIsDraftingEmail(false);
  };

  const filteredProducts = MOCK_PRODUCTS.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    p.sku.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col md:flex-row">
      {/* LEFT SIDEBAR / CONTROLS - Hidden when printing */}
      <div className="w-full md:w-[450px] bg-white border-r border-gray-200 flex flex-col h-screen overflow-hidden print:hidden shadow-xl z-20">
        <div className="p-4 bg-yellow-500 text-white shadow-md flex justify-between items-center">
          <div className="flex items-center gap-2">
            <FileText className="w-6 h-6" />
            <div>
              <h1 className="text-xl font-bold leading-tight">Lộc Đức Quotes</h1>
              <p className="text-yellow-100 text-xs">Hệ thống báo giá tự động</p>
            </div>
          </div>
          <div className="text-xs bg-yellow-600 px-2 py-1 rounded flex items-center gap-1">
             <Save className="w-3 h-3" /> Auto-saved
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-200">
          <button onClick={() => setActiveTab('customer')} className={`flex-1 py-3 text-sm font-medium transition-colors ${activeTab === 'customer' ? 'text-yellow-600 border-b-2 border-yellow-500 bg-yellow-50' : 'text-gray-500 hover:bg-gray-50'}`}>Khách hàng</button>
          <button onClick={() => setActiveTab('products')} className={`flex-1 py-3 text-sm font-medium transition-colors ${activeTab === 'products' ? 'text-yellow-600 border-b-2 border-yellow-500 bg-yellow-50' : 'text-gray-500 hover:bg-gray-50'}`}>Sản phẩm ({cart.length})</button>
          <button onClick={() => setActiveTab('settings')} className={`flex-1 py-3 text-sm font-medium transition-colors ${activeTab === 'settings' ? 'text-yellow-600 border-b-2 border-yellow-500 bg-yellow-50' : 'text-gray-500 hover:bg-gray-50'}`}>Cấu hình</button>
        </div>

        {/* Tab Content Area */}
        <div className="flex-1 overflow-y-auto p-4 bg-gray-50">
          
          {activeTab === 'customer' && (
            <div className="space-y-4 animate-fadeIn">
              <h2 className="text-sm font-bold text-gray-700 uppercase mb-2 border-b pb-2">Thông tin người mua</h2>
              <div className="grid grid-cols-1 gap-3">
                <input type="text" value={customer.companyName} onChange={e => setCustomer({...customer, companyName: e.target.value})} className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-yellow-400 outline-none text-sm" placeholder="Tên Công Ty / Khách Hàng" />
                <input type="text" value={customer.taxId} onChange={e => setCustomer({...customer, taxId: e.target.value})} className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-yellow-400 outline-none text-sm" placeholder="Mã Số Thuế (MST)" />
                <div className="grid grid-cols-2 gap-2">
                   <input type="text" value={customer.contactPerson} onChange={e => setCustomer({...customer, contactPerson: e.target.value})} className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-yellow-400 outline-none text-sm" placeholder="Người liên hệ" />
                   <input type="text" value={customer.phone} onChange={e => setCustomer({...customer, phone: e.target.value})} className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-yellow-400 outline-none text-sm" placeholder="Số điện thoại" />
                </div>
                <textarea value={customer.address} onChange={e => setCustomer({...customer, address: e.target.value})} className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-yellow-400 outline-none h-16 text-sm" placeholder="Địa chỉ xuất hóa đơn..." />
                <input type="email" value={customer.email} onChange={e => setCustomer({...customer, email: e.target.value})} className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-yellow-400 outline-none text-sm" placeholder="Email nhận báo giá" />
              </div>
            </div>
          )}

          {activeTab === 'products' && (
            <div className="space-y-4 h-full flex flex-col">
              <div className="flex gap-2">
                 <div className="relative flex-1">
                  <Search className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
                  <input type="text" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full pl-9 p-2 border border-gray-300 rounded focus:ring-2 focus:ring-yellow-400 outline-none text-sm" placeholder="Tìm sản phẩm..." />
                </div>
                <button onClick={() => setShowCustomProduct(!showCustomProduct)} className={`p-2 rounded border ${showCustomProduct ? 'bg-gray-200 border-gray-400' : 'bg-white border-gray-300'} hover:bg-gray-100`} title="Thêm sản phẩm ngoài">
                  <Plus className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              {/* Custom Product Form */}
              {showCustomProduct && (
                <div className="bg-white p-3 rounded border border-yellow-300 shadow-sm text-sm space-y-2 animate-fadeIn">
                  <div className="font-bold text-gray-700">Thêm sản phẩm tùy chỉnh:</div>
                  <input type="text" placeholder="Tên sản phẩm" className="w-full p-1 border rounded" value={customProduct.name} onChange={e => setCustomProduct({...customProduct, name: e.target.value})} />
                  <div className="flex gap-2">
                    <input type="number" placeholder="Giá bán" className="flex-1 p-1 border rounded" value={customProduct.price || ''} onChange={e => setCustomProduct({...customProduct, price: parseFloat(e.target.value)})} />
                    <input type="text" placeholder="ĐVT" className="w-20 p-1 border rounded" value={customProduct.unit} onChange={e => setCustomProduct({...customProduct, unit: e.target.value})} />
                  </div>
                  <input type="text" placeholder="Thông số kỹ thuật" className="w-full p-1 border rounded" value={customProduct.specs} onChange={e => setCustomProduct({...customProduct, specs: e.target.value})} />
                  <button onClick={handleAddCustomProduct} className="w-full bg-yellow-500 text-white py-1 rounded hover:bg-yellow-600 font-bold">Thêm vào giỏ</button>
                </div>
              )}
              
              {/* Search Results */}
              {!showCustomProduct && (
                <div className="flex-1 overflow-y-auto max-h-[180px] border border-gray-200 rounded bg-white">
                  {filteredProducts.map(product => (
                    <div key={product.id} className="flex items-center p-2 hover:bg-yellow-50 border-b border-gray-100 last:border-0 cursor-pointer group" onClick={() => handleAddToCart(product)}>
                      <img src={product.image} alt="" className="w-8 h-8 object-contain mr-3" />
                      <div className="flex-1">
                        <p className="text-xs font-bold text-gray-800 line-clamp-1">{product.name}</p>
                        <p className="text-xs text-red-600 font-semibold">{product.price.toLocaleString()} đ</p>
                      </div>
                      <Plus className="w-4 h-4 text-gray-300 group-hover:text-green-500" />
                    </div>
                  ))}
                </div>
              )}

              {/* AI Suggestion */}
              <button 
                onClick={handleSuggestProducts} 
                disabled={isSuggesting || cart.length === 0}
                className="w-full py-2 bg-gradient-to-r from-purple-500 to-indigo-600 text-white rounded text-xs font-bold flex items-center justify-center gap-2 hover:opacity-90 disabled:opacity-50"
              >
                <Wand2 className="w-3 h-3" />
                {isSuggesting ? 'Đang tìm phụ kiện...' : 'AI Gợi ý phụ kiện đi kèm'}
              </button>

              {/* Cart Items */}
              <div className="flex-1 overflow-y-auto">
                <h3 className="text-xs font-bold text-gray-500 uppercase mb-2 mt-2">Giỏ hàng ({cart.length})</h3>
                <div className="space-y-2 pb-20">
                  {cart.map(item => (
                    <div key={item.id} className="bg-white p-3 rounded shadow-sm border border-gray-100 relative group">
                       <button onClick={() => handleRemoveItem(item.id)} className="absolute top-2 right-2 text-gray-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity">
                         <Trash2 className="w-4 h-4" />
                       </button>
                       <p className="text-xs font-bold text-gray-800 pr-6 mb-2">{item.name}</p>
                       <div className="flex items-center justify-between gap-2">
                          {/* Qty */}
                          <div className="flex items-center border border-gray-300 rounded bg-gray-50">
                             <button onClick={() => handleUpdateQuantity(item.id, -1)} className="px-2 py-1 hover:bg-white text-xs font-bold text-gray-600">-</button>
                             <span className="px-2 text-xs font-bold w-6 text-center">{item.quantity}</span>
                             <button onClick={() => handleUpdateQuantity(item.id, 1)} className="px-2 py-1 hover:bg-white text-xs font-bold text-gray-600">+</button>
                          </div>
                          
                          {/* Discount */}
                          <div className="flex items-center border border-gray-300 rounded bg-white w-20 px-1">
                             <Percent className="w-3 h-3 text-gray-400" />
                             <input 
                                type="number" 
                                className="w-full text-xs p-1 outline-none text-right" 
                                placeholder="0" 
                                value={item.discount || ''} 
                                onChange={(e) => handleUpdateDiscount(item.id, e.target.value)}
                                min="0" max="100"
                             />
                          </div>

                          <p className="text-sm font-bold text-red-600 min-w-[80px] text-right">
                            {(item.price * item.quantity * (1 - (item.discount || 0)/100)).toLocaleString()}
                          </p>
                       </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="space-y-4">
              <h2 className="text-sm font-bold text-gray-700 uppercase mb-2 border-b pb-2">Cấu hình báo giá</h2>
              <div className="grid grid-cols-2 gap-3">
                 <div>
                  <label className="block text-xs font-semibold text-gray-500 mb-1">Số báo giá</label>
                  <input type="text" value={settings.quoteNumber} onChange={e => setSettings({...settings, quoteNumber: e.target.value})} className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-yellow-400 outline-none font-mono text-sm" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-500 mb-1">Ngày lập</label>
                  <input type="date" value={settings.quoteDate ? settings.quoteDate.split('T')[0] : ''} onChange={e => setSettings({...settings, quoteDate: e.target.value})} className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-yellow-400 outline-none text-sm" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-500 mb-1">Thuế VAT</label>
                <select value={settings.vatRate} onChange={e => setSettings({...settings, vatRate: parseFloat(e.target.value)})} className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-yellow-400 outline-none bg-white text-sm">
                  <option value={0}>0%</option>
                  <option value={0.08}>8%</option>
                  <option value={0.10}>10%</option>
                </select>
              </div>

              {/* Stamp Toggle */}
              <div className="flex items-center gap-2 mt-4 p-3 bg-red-50 rounded border border-red-200 cursor-pointer" onClick={() => setSettings({...settings, showStamp: !settings.showStamp})}>
                <div className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${settings.showStamp ? 'bg-red-500 border-red-500' : 'bg-white border-gray-300'}`}>
                   {settings.showStamp && <Stamp className="w-3 h-3 text-white" />}
                </div>
                <label className="text-xs font-bold text-red-700 select-none cursor-pointer flex-1">
                  Hiển thị dấu mộc đỏ (Góc trái trên cùng)
                </label>
              </div>
              
              <div className="pt-4 border-t border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-xs font-semibold text-gray-500">Ghi chú (Lời nhắn)</label>
                  <button onClick={handleGenerateAINote} disabled={isGeneratingNote} className="flex items-center text-xs text-purple-600 hover:text-purple-800 font-semibold disabled:opacity-50">
                    <Sparkles className="w-3 h-3 mr-1" />
                    {isGeneratingNote ? 'Đang viết...' : 'Dùng AI viết hộ'}
                  </button>
                </div>
                <textarea value={settings.notes} onChange={e => setSettings({...settings, notes: e.target.value})} className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-yellow-400 outline-none h-24 text-sm" placeholder="Nhập ghi chú hoặc dùng AI..." />
              </div>
            </div>
          )}

        </div>

        {/* Action Buttons */}
        <div className="p-4 bg-white border-t border-gray-200 space-y-2">
          <button onClick={handlePrint} className="w-full flex items-center justify-center gap-2 bg-gray-800 hover:bg-gray-900 text-white py-3 rounded-lg font-bold transition-colors shadow-lg">
            <Printer className="w-5 h-5" /> In Báo Giá / Lưu PDF
          </button>
          
          <button onClick={handleDraftEmail} className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-bold transition-colors shadow-lg">
            <Mail className="w-5 h-5" /> Soạn Email với AI
          </button>
        </div>
      </div>

      {/* RIGHT PREVIEW AREA */}
      <div className="flex-1 bg-gray-500 p-8 overflow-y-auto print:p-0 print:bg-white print:overflow-visible flex justify-center items-start">
        <div className="print:hidden fixed top-4 right-4 text-white text-sm opacity-50 pointer-events-none">Preview Mode</div>
        <div className="shadow-2xl print:shadow-none bg-white scale-[0.8] origin-top md:scale-100 transition-transform">
           <QuoteTemplate customer={customer} items={cart} settings={settings} />
        </div>
      </div>

      {/* EMAIL MODAL */}
      {showEmailModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 print:hidden">
          <div className="bg-white rounded-lg w-full max-w-2xl flex flex-col max-h-[90vh]">
            <div className="p-4 border-b flex justify-between items-center bg-gray-50 rounded-t-lg">
              <h3 className="font-bold text-lg flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-600" />
                AI Soạn Email
              </h3>
              <button onClick={() => setShowEmailModal(false)} className="text-gray-500 hover:text-red-500"><X className="w-6 h-6" /></button>
            </div>
            
            <div className="p-6 overflow-y-auto flex-1">
              {isDraftingEmail ? (
                <div className="flex flex-col items-center justify-center py-12 space-y-4">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
                  <p className="text-gray-500 animate-pulse">AI đang phân tích báo giá và soạn nội dung...</p>
                </div>
              ) : emailDraft ? (
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-500 mb-1">Tiêu đề (Subject)</label>
                    <div className="p-2 bg-gray-100 rounded border border-gray-200 font-medium select-all">
                      {emailDraft.subject}
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-500 mb-1">Nội dung</label>
                    <div 
                      className="p-4 bg-gray-50 rounded border border-gray-200 text-sm whitespace-pre-wrap leading-relaxed h-[300px] overflow-y-auto"
                      dangerouslySetInnerHTML={{ __html: emailDraft.body }}
                    />
                  </div>
                </div>
              ) : (
                <p className="text-red-500">Có lỗi xảy ra khi tạo email.</p>
              )}
            </div>

            <div className="p-4 border-t bg-gray-50 rounded-b-lg flex justify-end gap-2">
              <button onClick={() => setShowEmailModal(false)} className="px-4 py-2 text-gray-600 hover:bg-gray-200 rounded font-medium">Đóng</button>
              {emailDraft && (
                <button 
                  onClick={() => {
                    const el = document.createElement('div');
                    el.innerHTML = emailDraft.body;
                    const textBody = el.innerText; // Basic strip tags for mailto
                    const mailto = `mailto:${customer.email}?subject=${encodeURIComponent(emailDraft.subject)}&body=${encodeURIComponent(textBody)}`;
                    window.location.href = mailto;
                  }}
                  className="px-4 py-2 bg-blue-600 text-white rounded font-bold hover:bg-blue-700 flex items-center gap-2"
                >
                  <Send className="w-4 h-4" /> Mở trong App Mail
                </button>
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export default App;
