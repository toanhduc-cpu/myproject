import React from 'react';
import { CustomerInfo, CartItem, QuoteSettings } from '../types';
import { COMPANY_INFO } from '../constants';

interface QuoteTemplateProps {
  customer: CustomerInfo;
  items: CartItem[];
  settings: QuoteSettings;
}

const QuoteTemplate: React.FC<QuoteTemplateProps> = ({ customer, items, settings }) => {
  const hasDiscount = items.some(item => item.discount > 0);

  const calculateLineTotal = (item: CartItem) => {
    const baseTotal = item.price * item.quantity;
    const discountAmount = (baseTotal * (item.discount || 0)) / 100;
    return baseTotal - discountAmount;
  };

  const calculateSubtotal = () => items.reduce((sum, item) => sum + calculateLineTotal(item), 0);
  const subtotal = calculateSubtotal();
  const vatAmount = subtotal * settings.vatRate;
  const total = subtotal + vatAmount;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
  };

  return (
    <div id="quote-template" className="bg-white p-8 max-w-[210mm] mx-auto min-h-[297mm] shadow-lg print:shadow-none print:w-[210mm] print:h-auto text-sm font-sans text-gray-800 relative">
      {/* Background Watermark */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.03] flex items-center justify-center overflow-hidden">
        <div className="text-[100px] font-bold -rotate-45 select-none text-gray-900 whitespace-nowrap">TÂN LỘC ĐỨC</div>
      </div>

      {/* Header */}
      <div className="flex justify-between items-start mb-6 border-b-2 border-yellow-500 pb-4 relative z-10">
        
        {/* COMPANY STAMP (Dấu treo) */}
        {settings.showStamp && (
          <div className="absolute -top-2 -left-2 z-20 pointer-events-none">
             <div className="w-28 h-28 border-[3px] border-red-600 rounded-full flex items-center justify-center relative opacity-80 rotate-[-12deg] mix-blend-multiply bg-white/10 backdrop-blur-[1px]">
                <div className="absolute inset-1 border border-red-600 rounded-full"></div>
                <div className="text-center text-red-600 font-bold leading-tight">
                   <div className="text-[8px] uppercase tracking-widest mb-1">Công Ty TNHH</div>
                   <div className="text-base uppercase border-t border-b border-red-600 py-1 my-1 px-1">Tân<br/>Lộc Đức</div>
                   <div className="text-[8px] tracking-wide">MST: {COMPANY_INFO.taxId}</div>
                   <div className="absolute top-1/2 left-1 text-red-600 text-[8px] -translate-y-1/2 -rotate-90">★</div>
                   <div className="absolute top-1/2 right-1 text-red-600 text-[8px] -translate-y-1/2 rotate-90">★</div>
                </div>
             </div>
          </div>
        )}

        <div className="w-2/3 pr-4">
          <div className="flex items-center gap-4 mb-2">
            <div className="w-16 h-16 bg-yellow-500 rounded-lg flex items-center justify-center text-white font-bold text-xl relative z-30 shrink-0">
              LĐ
            </div>
            <div className="relative z-30">
              <h1 className="text-xl font-bold text-red-600 uppercase bg-white/80 inline-block px-1 rounded leading-tight">{COMPANY_INFO.name}</h1>
              <p className="font-semibold text-gray-600 text-xs mt-1">Uy tín - Chất lượng - Tận tâm</p>
            </div>
          </div>
          <div className="text-xs space-y-1 text-gray-600 mt-2 relative z-30 leading-relaxed">
            <div className="flex gap-1 items-start">
               <span className="font-bold shrink-0">Địa chỉ:</span> 
               <div className="flex flex-col">
                  {COMPANY_INFO.address.split('|').map((line, i) => (
                    <span key={i}>{line.trim()}</span>
                  ))}
               </div>
            </div>
            <p><span className="font-bold">MST:</span> {COMPANY_INFO.taxId} | <span className="font-bold">Hotline:</span> {COMPANY_INFO.phone}</p>
            <p><span className="font-bold">Email:</span> {COMPANY_INFO.email} | <span className="font-bold">Website:</span> {COMPANY_INFO.website}</p>
          </div>
        </div>
        <div className="w-1/3 text-right">
          <h2 className="text-3xl font-bold text-yellow-600 mb-2">BÁO GIÁ</h2>
          <p className="text-gray-500 italic">Số: {settings.quoteNumber}</p>
          <p className="text-gray-500 italic">Ngày: {new Date(settings.quoteDate).toLocaleDateString('vi-VN')}</p>
        </div>
      </div>

      {/* Customer Info */}
      <div className="mb-6 grid grid-cols-2 gap-8 relative z-10">
        <div>
          <h3 className="text-yellow-600 font-bold uppercase mb-2 border-b border-gray-200 pb-1">Đơn vị bán hàng</h3>
          <div className="text-sm space-y-1">
            <p className="font-bold">{COMPANY_INFO.name}</p>
             {COMPANY_INFO.address.split('|').map((line, i) => (
               <p key={i} className="whitespace-pre-line">{line.trim()}</p>
            ))}
            <p>Đại diện: Phòng Kinh Doanh</p>
            <p>SĐT: {COMPANY_INFO.phone}</p>
          </div>
        </div>
        <div>
          <h3 className="text-yellow-600 font-bold uppercase mb-2 border-b border-gray-200 pb-1">Khách hàng</h3>
          <div className="text-sm space-y-1">
            <p className="font-bold">{customer.companyName || customer.contactPerson || 'Khách lẻ'}</p>
            <p>Địa chỉ: {customer.address || '---'}</p>
            <p>Người nhận: {customer.contactPerson || '---'}</p>
            <p>SĐT: {customer.phone || '---'} | MST: {customer.taxId || '---'}</p>
          </div>
        </div>
      </div>

      {/* Product Table */}
      <div className="mb-6 relative z-10">
        <table className="w-full border-collapse border border-yellow-500">
          <thead className="bg-yellow-400 text-white text-xs uppercase text-center">
            <tr>
              <th className="border border-yellow-500 p-2 w-10">STT</th>
              <th className="border border-yellow-500 p-2 w-20">Hình ảnh</th>
              <th className="border border-yellow-500 p-2">Tên sản phẩm & Thông số kỹ thuật</th>
              <th className="border border-yellow-500 p-2 w-16">ĐVT</th>
              <th className="border border-yellow-500 p-2 w-14">SL</th>
              <th className="border border-yellow-500 p-2 w-24">Đơn giá</th>
              {hasDiscount && <th className="border border-yellow-500 p-2 w-14">CK(%)</th>}
              <th className="border border-yellow-500 p-2 w-28">Thành tiền</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item, index) => (
              <tr key={index} className="text-sm hover:bg-yellow-50">
                <td className="border border-yellow-200 p-2 text-center">{index + 1}</td>
                <td className="border border-yellow-200 p-2 text-center">
                  <img src={item.image} alt="product" className="w-12 h-12 object-contain mx-auto mix-blend-multiply" />
                </td>
                <td className="border border-yellow-200 p-2 align-top">
                  <p className="font-bold text-gray-800">{item.name}</p>
                  <p className="text-xs text-gray-500 mt-1 italic">{item.specs}</p>
                  <p className="text-xs text-gray-400 mt-1">Mã: {item.sku}</p>
                </td>
                <td className="border border-yellow-200 p-2 text-center">{item.unit}</td>
                <td className="border border-yellow-200 p-2 text-center font-bold">{item.quantity}</td>
                <td className="border border-yellow-200 p-2 text-right">{formatCurrency(item.price)}</td>
                {hasDiscount && (
                  <td className="border border-yellow-200 p-2 text-center text-red-500">
                    {item.discount > 0 ? `${item.discount}%` : '-'}
                  </td>
                )}
                <td className="border border-yellow-200 p-2 text-right font-bold">{formatCurrency(calculateLineTotal(item))}</td>
              </tr>
            ))}
            {/* Totals */}
            <tr>
              <td colSpan={hasDiscount ? 6 : 5} className="border-t border-yellow-500"></td>
              <td className="border border-yellow-200 p-2 text-right font-semibold">Cộng tiền hàng:</td>
              <td className="border border-yellow-200 p-2 text-right">{formatCurrency(subtotal)}</td>
            </tr>
            <tr>
              <td colSpan={hasDiscount ? 6 : 5} className="border-none"></td>
              <td className="border border-yellow-200 p-2 text-right font-semibold">Thuế VAT ({(settings.vatRate * 100).toFixed(0)}%):</td>
              <td className="border border-yellow-200 p-2 text-right">{formatCurrency(vatAmount)}</td>
            </tr>
            <tr className="bg-yellow-100">
              <td colSpan={hasDiscount ? 6 : 5} className="border-none"></td>
              <td className="border border-yellow-500 p-2 text-right font-bold text-red-600 uppercase">Tổng cộng:</td>
              <td className="border border-yellow-500 p-2 text-right font-bold text-red-600">{formatCurrency(total)}</td>
            </tr>
          </tbody>
        </table>
        <p className="text-xs italic text-gray-500 mt-2 text-right">Bằng chữ: <span className="font-medium text-gray-700">Chưa hỗ trợ đọc số tiền (Feature pending)</span></p>
      </div>

      {/* Notes & Footer */}
      <div className="grid grid-cols-2 gap-8 mt-8 relative z-10">
        <div>
           <div className="bg-gray-50 p-4 rounded border border-gray-200 text-xs">
            <h4 className="font-bold text-gray-700 mb-2">Ghi chú & Điều khoản:</h4>
            <ul className="list-disc list-inside space-y-1 text-gray-600">
              <li>Báo giá có hiệu lực trong vòng 07 ngày.</li>
              <li>Hàng hóa chính hãng, mới 100%.</li>
              <li>Bảo hành theo tiêu chuẩn nhà sản xuất.</li>
              <li>Thanh toán 100% trước khi giao hàng hoặc theo thỏa thuận.</li>
            </ul>
            {settings.notes && (
                <div className="mt-3 pt-2 border-t border-gray-200 italic text-gray-800">
                   "{settings.notes}"
                </div>
            )}
           </div>
           
           {/* Bank Info */}
           <div className="mt-4 flex gap-4 items-center p-3 border border-dashed border-yellow-400 rounded bg-yellow-50">
             <div className="w-16 h-16 bg-white flex items-center justify-center border text-xs text-center text-gray-400">
                QR CODE
             </div>
             <div className="text-xs">
                <p className="font-bold text-gray-700">Thông tin chuyển khoản:</p>
                <p>Ngân hàng: {COMPANY_INFO.bankName}</p>
                <p>STK: <span className="font-bold font-mono text-base">{COMPANY_INFO.bankAccount}</span></p>
                <p>Chủ TK: {COMPANY_INFO.bankHolder}</p>
             </div>
           </div>
        </div>

        <div className="text-center pt-4">
          <p className="font-bold text-gray-700 mb-16">Đại diện bán hàng</p>
          <p className="text-sm italic text-gray-500">(Ký và ghi rõ họ tên)</p>
          <div className="mt-8 font-bold text-gray-800">
             <span className="font-signature text-2xl text-blue-900">NguyenVanKinhDoanh</span>
             <br/>
             Nguyễn Văn Kinh Doanh
          </div>
        </div>
      </div>
      
      <div className="mt-auto pt-8 text-center text-[10px] text-gray-400 border-t mt-4">
         Hệ thống báo giá tự động - Điện Máy Lộc Đức
      </div>
    </div>
  );
};

export default QuoteTemplate;
