import { Product } from './types';

export const MOCK_PRODUCTS: Product[] = [
  {
    id: '1',
    sku: 'SONY-65X80L',
    name: 'Google Tivi Sony 4K 65 inch KD-65X80L',
    image: 'https://picsum.photos/200/200?random=1',
    price: 16900000,
    specs: '4K HDR, Google TV, Triluminos Pro, Motionflow XR 200',
    unit: 'Cái',
  },
  {
    id: '2',
    sku: 'LG-FV1410S4W',
    name: 'Máy giặt LG Inverter 10 kg FV1410S4W',
    image: 'https://picsum.photos/200/200?random=2',
    price: 8490000,
    specs: 'Inverter, AI DD, Steam+, TurboWash',
    unit: 'Cái',
  },
  {
    id: '3',
    sku: 'DAIKIN-FTKB35',
    name: 'Điều hòa Daikin Inverter 12000 BTU FTKB35XVMV',
    image: 'https://picsum.photos/200/200?random=3',
    price: 10200000,
    specs: 'Inverter, Coanda, Enzyme Blue, Mold Proof',
    unit: 'Bộ',
  },
  {
    id: '4',
    sku: 'TOSHIBA-GR-RT395WE',
    name: 'Tủ lạnh Toshiba Inverter 311 lít GR-RT395WE-PMV',
    image: 'https://picsum.photos/200/200?random=4',
    price: 7800000,
    specs: 'Origin Inverter, PureBio, Air Fall Cooling',
    unit: 'Cái',
  },
  {
    id: '5',
    sku: 'PANASONIC-NC-EG4000',
    name: 'Bình thủy điện Panasonic 4 lít NC-EG4000CSY',
    image: 'https://picsum.photos/200/200?random=5',
    price: 1850000,
    specs: '4 Lít, 700W, Rót nước điện tử, VIP Insulating',
    unit: 'Cái',
  }
];

export const COMPANY_INFO = {
  name: 'CÔNG TY TNHH ĐIỆN MÁY NỘI THẤT TÂN LỘC ĐỨC',
  address: 'Trụ sở: 329 Hồng Bàng, P.11, Q.5, TP.HCM | CN1: 530 An Dương Vương, P.10, Q.6, TP.HCM',
  phone: '0937 276 912 - 1900 2670',
  email: 'dienmaylocduc@gmail.com',
  website: 'dienmaylocduc.vn',
  taxId: '0316359980',
  bankName: 'Vietcombank - CN Bình Tây',
  bankAccount: '0251002345678',
  bankHolder: 'CONG TY TNHH DIEN MAY NOI THAT TAN LOC DUC',
};