import { GoogleGenAI, Type, SchemaType } from "@google/genai";
import { CustomerInfo, CartItem, Product } from "../types";

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.warn("API Key is missing. Gemini features will not work.");
    return null;
  }
  return new GoogleGenAI({ apiKey });
};

export const generateQuoteNote = async (customer: CustomerInfo, items: CartItem[]): Promise<string> => {
  const ai = getClient();
  if (!ai) return "";

  const itemList = items.map(i => `${i.quantity}x ${i.name}`).join(", ");
  
  const prompt = `
    You are a professional sales assistant for "Điện Máy Lộc Đức".
    Write a short, polite, and professional closing note for a price quote (Báo giá).
    
    Customer Name: ${customer.contactPerson || customer.companyName}
    Items interested: ${itemList}
    
    The note should thank them for choosing Lộc Đức, mention that the prices include VAT (if applicable), and encourage them to contact us for support.
    Keep it under 50 words. Write in Vietnamese.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text || "";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Cảm ơn quý khách đã quan tâm đến sản phẩm của Điện Máy Lộc Đức. Rất mong được hợp tác.";
  }
};

export const generateEmailDraft = async (customer: CustomerInfo, items: CartItem[], total: number): Promise<{ subject: string, body: string }> => {
  const ai = getClient();
  if (!ai) return { subject: "", body: "" };

  const itemList = items.map(i => `- ${i.name} (${i.quantity} ${i.unit})`).join("\n");
  const formattedTotal = new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(total);

  const prompt = `
    Write a professional email draft for sending a price quote to a customer in Vietnamese.
    
    Company: Điện Máy Lộc Đức
    Customer: ${customer.contactPerson || customer.companyName}
    Items:
    ${itemList}
    Total Value: ${formattedTotal}
    
    Return a JSON object with "subject" and "body" fields. 
    The body should be polite, professional HTML text (use <br> for line breaks), thanking the customer and mentioning the attached PDF.
  `;

  try {
     const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            subject: { type: Type.STRING },
            body: { type: Type.STRING }
          }
        }
      }
    });
    
    const text = response.text || "{}";
    return JSON.parse(text);
  } catch (error) {
    console.error("Gemini Email Error:", error);
    return { 
      subject: `Gửi báo giá - Điện Máy Lộc Đức`, 
      body: `Kính gửi Quý khách,<br><br>Cảm ơn Quý khách đã quan tâm đến sản phẩm của Điện Máy Lộc Đức.<br>Chúng tôi xin gửi kèm báo giá chi tiết trong file đính kèm.<br><br>Trân trọng.` 
    };
  }
};

export const suggestAccessories = async (items: CartItem[]): Promise<Product[]> => {
  const ai = getClient();
  if (!ai) return [];

  const itemNames = items.map(i => i.name).join(", ");
  const prompt = `
    Based on the following electronic products in the cart: ${itemNames}
    Suggest 3 relevant accessories or related services (like installation, warranty, cables, mounts) that the customer might need.
    
    Return a JSON list of products.
    The prices should be realistic in VND (numbers only).
    Images can be generic placeholder URLs like 'https://placehold.co/200x200?text=Accessory'.
    Set SKU to 'SUGGESTED'.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING }, // Just generate random string
              sku: { type: Type.STRING },
              name: { type: Type.STRING },
              price: { type: Type.NUMBER },
              specs: { type: Type.STRING },
              unit: { type: Type.STRING },
              image: { type: Type.STRING }
            }
          }
        }
      }
    });

    const products = JSON.parse(response.text || "[]");
    // Ensure IDs are unique client-side
    return products.map((p: any, idx: number) => ({
      ...p,
      id: `ai-suggest-${Date.now()}-${idx}`,
      sku: 'AI-SUGGEST'
    }));
  } catch (error) {
    console.error("Gemini Suggestion Error:", error);
    return [];
  }
};
