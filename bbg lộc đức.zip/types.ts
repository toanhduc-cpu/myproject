export interface Product {
  id: string;
  sku: string;
  name: string;
  image: string;
  price: number;
  specs: string; // Technical specifications
  unit: string;
}

export interface CartItem extends Product {
  quantity: number;
  discount: number; // Percentage or fixed amount could be implemented, keeping simple for now
}

export interface CustomerInfo {
  companyName: string;
  taxId: string; // MST
  contactPerson: string;
  phone: string;
  address: string;
  email: string;
}

export interface QuoteSettings {
  vatRate: number; // e.g., 0.08 or 0.10
  quoteDate: string;
  quoteNumber: string;
  notes: string;
  showStamp: boolean;
}
