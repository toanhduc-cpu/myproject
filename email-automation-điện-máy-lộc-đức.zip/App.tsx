import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import CampaignManager from './components/CampaignManager';
import CatalogueManager from './components/CatalogueManager';
import ContactManager from './components/ContactManager';
import RecycleBin from './components/RecycleBin';
import Guide from './components/Guide';
import { ViewState, CatalogueItem, Stats, ContactGroup, LeadStatus, MarketingEvent, CampaignTemplate, ActivityLog, ActivityType, RecycleBinItem, TrashItemType } from './types';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>('dashboard');
  
  // Activity Logs State
  const [activities, setActivities] = useState<ActivityLog[]>([
      { id: 'log-1', type: 'SYSTEM', action: 'Khởi động hệ thống', target: 'LocDuc Hub', status: 'SUCCESS', timestamp: Date.now() - 3600000 }
  ]);

  const logActivity = (type: ActivityType, action: string, target: string, status: 'SUCCESS' | 'WARNING' | 'ERROR' = 'SUCCESS') => {
      const newLog: ActivityLog = {
          id: Date.now().toString() + Math.random(),
          type,
          action,
          target,
          status,
          timestamp: Date.now()
      };
      setActivities(prev => [newLog, ...prev]);
  };

  // Initial Data for Catalogues
  const [catalogues, setCatalogues] = useState<CatalogueItem[]>([
    { id: '1', name: 'Máy hàn', link: 'https://dienmaylocduc.vn/catalogue-may-han', description: 'Các loại máy hàn điện tử, hàn tig/mig. Phù hợp cho xưởng cơ khí, công trình xây dựng.' },
    { id: '2', name: 'Dụng cụ cầm tay', link: 'https://dienmaylocduc.vn/catalogue-dung-cu', description: 'Khoan, mài, cắt Bosch/Makita. Phù hợp cho sửa chữa, lắp đặt nội thất, gia dụng.' },
    { id: '3', name: 'Vật tư kim khí', link: 'https://dienmaylocduc.vn/catalogue-kim-khi', description: 'Que hàn, đá cắt, bulong, ốc vít. Vật tư tiêu hao số lượng lớn.' },
  ]);

  // Initial Data for Events
  const [events, setEvents] = useState<MarketingEvent[]>([
    { id: 'evt-1', name: 'Tết Nguyên Đán 2025', date: '2025-01-29', note: 'Dịp nghỉ lễ lớn nhất, nhu cầu mua sắm trước tết và sản xuất sau tết.', suggestedCatalogueIds: ['2'] },
    { id: 'evt-2', name: 'Quốc Tế Lao Động 1/5', date: '2025-05-01', note: 'Kỳ nghỉ lễ, thường có các đợt sửa chữa bảo trì nhà xưởng.', suggestedCatalogueIds: ['1', '3'] },
  ]);

  // Initial Data for Campaign Templates
  const [campaignTemplates, setCampaignTemplates] = useState<CampaignTemplate[]>([]);

  // Initial Data for Contact Groups (Global State) with Sample Data for 'Máy hàn', 'Dụng cụ cầm tay', 'Vật tư kim khí'
  const [contactGroups, setContactGroups] = useState<ContactGroup[]>([
    {
      id: 'sample-group-1',
      name: 'Khách hàng Cơ Khí (Mẫu)',
      catalogueId: '1', // ID 1 corresponds to 'Máy hàn'
      createdAt: Date.now(),
      leads: [
        { 
          id: 'lead-1', 
          companyName: 'Cơ Khí Đại Phát', 
          email: 'thumua@cokhidaiphat.com', 
          productInterest: 'Máy hàn Tig', 
          status: LeadStatus.NEW, 
          createdAt: Date.now() 
        },
        { 
          id: 'lead-2', 
          companyName: 'Xây Dựng Hòa Bình', 
          email: 'vattu@hoabinhcorp.vn', 
          productInterest: 'Máy hàn Mig 500A', 
          status: LeadStatus.NEW, 
          createdAt: Date.now() 
        },
        { 
          id: 'lead-3', 
          companyName: 'Xưởng Inox Thành Công', 
          email: 'lienhe@inoxthanhcong.com', 
          productInterest: 'Máy hàn Laser', 
          status: LeadStatus.NEW, 
          createdAt: Date.now() 
        }
      ]
    },
    {
      id: 'sample-group-2',
      name: 'Khách hàng Mộc & Nội Thất (Mẫu)',
      catalogueId: '2', // ID 2 corresponds to 'Dụng cụ cầm tay'
      createdAt: Date.now() - 86400000,
      leads: [
        { 
          id: 'lead-dc-1', 
          companyName: 'Xưởng Mộc Kiến Vàng', 
          email: 'kienvang.wood@gmail.com', 
          productInterest: 'Máy chà nhám', 
          status: LeadStatus.NEW, 
          createdAt: Date.now() 
        },
        { 
          id: 'lead-dc-2', 
          companyName: 'Nội Thất Nhà Đẹp 365', 
          email: 'contact@nhadep365.vn', 
          productInterest: 'Máy khoan pin Bosch', 
          status: LeadStatus.NEW, 
          createdAt: Date.now() 
        },
        { 
          id: 'lead-dc-3', 
          companyName: 'Công Ty Decor Xanh', 
          email: 'purchase@decorxanh.com', 
          productInterest: 'Máy cắt gỗ cầm tay', 
          status: LeadStatus.NEW, 
          createdAt: Date.now() 
        }
      ]
    },
    {
      id: 'sample-group-3',
      name: 'Đại lý Vật Tư Kim Khí (Mẫu)',
      catalogueId: '3', // ID 3 corresponds to 'Vật tư kim khí'
      createdAt: Date.now() - 172800000,
      leads: [
        { 
          id: 'lead-kk-1', 
          companyName: 'Cửa hàng Điện Nước An Khang', 
          email: 'ankhang.store@gmail.com', 
          productInterest: 'Bulong Inox 304', 
          status: LeadStatus.NEW, 
          createdAt: Date.now() 
        },
        { 
          id: 'lead-kk-2', 
          companyName: 'Đại lý Vật Tư Hưng Thịnh', 
          email: 'hungthinh.steel@gmail.com', 
          productInterest: 'Que hàn Việt Đức', 
          status: LeadStatus.NEW, 
          createdAt: Date.now() 
        },
        { 
          id: 'lead-kk-3', 
          companyName: 'Xưởng Cơ Khí Phước Lộc', 
          email: 'phuocloc.mech@gmail.com', 
          productInterest: 'Đá cắt sắt 350', 
          status: LeadStatus.NEW, 
          createdAt: Date.now() 
        }
      ]
    }
  ]);

  const [recycleBin, setRecycleBin] = useState<RecycleBinItem[]>([]);

  const [stats, setStats] = useState<Stats>({
    totalSent: 1245,
    openRate: 42,
    responseRate: 15,
    leadsGenerated: 186
  });

  // --- TRASH LOGIC ---
  const moveToTrash = (itemData: any, type: TrashItemType, name: string) => {
      const trashItem: RecycleBinItem = {
          id: Date.now().toString() + Math.random(),
          originalData: itemData,
          type,
          name,
          deletedAt: Date.now()
      };
      setRecycleBin(prev => [trashItem, ...prev]);

      // Remove from source
      switch(type) {
          case 'CATALOGUE':
              setCatalogues(prev => prev.filter(c => c.id !== itemData.id));
              break;
          case 'CONTACT_GROUP':
              setContactGroups(prev => prev.filter(g => g.id !== itemData.id));
              break;
          case 'EVENT':
              setEvents(prev => prev.filter(e => e.id !== itemData.id));
              break;
          case 'CAMPAIGN_TEMPLATE':
              setCampaignTemplates(prev => prev.filter(t => t.id !== itemData.id));
              break;
      }
      logActivity(type as ActivityType, 'Xóa (Chuyển vào thùng rác)', name, 'WARNING');
  };

  const restoreFromTrash = (item: RecycleBinItem) => {
      // Remove from trash
      setRecycleBin(prev => prev.filter(i => i.id !== item.id));

      // Restore to source
      switch(item.type) {
          case 'CATALOGUE':
              setCatalogues(prev => [...prev, item.originalData]);
              break;
          case 'CONTACT_GROUP':
              setContactGroups(prev => [...prev, item.originalData]);
              break;
          case 'EVENT':
              setEvents(prev => [...prev, item.originalData]);
              break;
          case 'CAMPAIGN_TEMPLATE':
              setCampaignTemplates(prev => [...prev, item.originalData]);
              break;
      }
  };

  const permanentDelete = (id: string) => {
      setRecycleBin(prev => prev.filter(i => i.id !== id));
  };

  const handleUpdateStats = (newSentCount: number) => {
    setStats(prev => ({
      ...prev,
      totalSent: prev.totalSent + newSentCount,
      leadsGenerated: prev.leadsGenerated + Math.floor(newSentCount * 0.1) // Simulate 10% lead gen
    }));
  };

  const renderContent = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard stats={stats} activities={activities} />;
      case 'contacts':
        return <ContactManager 
                  contactGroups={contactGroups} 
                  setContactGroups={setContactGroups} 
                  catalogues={catalogues} 
                  logActivity={logActivity}
                  onMoveToTrash={moveToTrash}
                />;
      case 'campaign':
        return <CampaignManager 
                  catalogues={catalogues} 
                  contactGroups={contactGroups} 
                  setContactGroups={setContactGroups}
                  events={events}
                  setEvents={setEvents}
                  campaignTemplates={campaignTemplates}
                  setCampaignTemplates={setCampaignTemplates}
                  onStatsUpdate={handleUpdateStats} 
                  onNavigateToContacts={() => setCurrentView('contacts')}
                  logActivity={logActivity}
                  onMoveToTrash={moveToTrash}
               />;
      case 'catalogues':
        return <CatalogueManager 
                  catalogues={catalogues} 
                  setCatalogues={setCatalogues} 
                  logActivity={logActivity}
                  onMoveToTrash={moveToTrash}
                />;
      case 'guide':
        return <Guide />;
      case 'recycleBin':
        return <RecycleBin 
                  items={recycleBin} 
                  onRestore={restoreFromTrash} 
                  onPermanentDelete={permanentDelete}
                  logActivity={logActivity}
               />;
      default:
        return <Dashboard stats={stats} activities={activities} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-white text-black font-sans">
      <Sidebar
        currentView={currentView}
        onChangeView={setCurrentView}
        recycleBinCount={recycleBin.length}
      />

      <main className="flex-1 ml-64 p-8">
        <header className="flex justify-between items-center mb-8">
          <div>
            <h2 className="text-2xl font-bold text-slate-800">
              {currentView === 'dashboard' && 'Tổng Quan'}
              {currentView === 'contacts' && 'Quản Lý Danh Bạ Khách Hàng'}
              {currentView === 'campaign' && 'Chiến Dịch Tự Động'}
              {currentView === 'catalogues' && 'Quản Lý Catalogue'}
              {currentView === 'guide' && 'Hướng Dẫn & Quy Trình'}
              {currentView === 'recycleBin' && 'Thùng Rác & Khôi Phục'}
            </h2>
            <p className="text-slate-500 text-sm">Hệ thống quản trị Marketing cho Điện Máy Lộc Đức</p>
          </div>
          <div className="flex items-center gap-3">
             <div className="bg-white border border-slate-200 px-4 py-2 rounded-full text-sm font-medium text-slate-600 shadow-sm">
                User: Admin
             </div>
          </div>
        </header>

        {renderContent()}
      </main>
    </div>
  );
};

export default App;