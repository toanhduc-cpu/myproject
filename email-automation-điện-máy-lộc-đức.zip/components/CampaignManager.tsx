import React, { useState, useEffect } from 'react';
import { CatalogueItem, ContactGroup, Campaign, CampaignStatus, MarketingEvent, LeadStatus, CampaignTemplate, Lead, ActivityType, TrashItemType } from '../types';
import { Plus, Wand2, Send, Loader2, Calendar, ArrowRight, Clock, History, LayoutTemplate, CalendarRange, Play, Save, Search, XCircle, FileText, CheckCircle2, FileDown, X, Eye, PenTool, AlertTriangle, Trash2, Tag, Filter, Sparkles, CheckSquare, Square, ThumbsUp, AlertCircle, ShieldAlert, Pin, BellRing, CloudLightning, LayoutGrid, List } from 'lucide-react';
import { generateEmailTemplate, suggestCataloguesForEvent, generateSalesEmail } from '../services/geminiService';

interface CampaignManagerProps {
    catalogues: CatalogueItem[];
    contactGroups: ContactGroup[]; 
    setContactGroups: React.Dispatch<React.SetStateAction<ContactGroup[]>>;
    events: MarketingEvent[];
    setEvents: React.Dispatch<React.SetStateAction<MarketingEvent[]>>;
    campaignTemplates: CampaignTemplate[];
    setCampaignTemplates: React.Dispatch<React.SetStateAction<CampaignTemplate[]>>;
    onStatsUpdate: (count: number) => void;
    onNavigateToContacts: () => void;
    logActivity: (type: ActivityType, action: string, target: string, status?: 'SUCCESS' | 'WARNING' | 'ERROR') => void;
    onMoveToTrash: (item: any, type: TrashItemType, name: string) => void;
}

type Tab = 'HISTORY' | 'EVENTS' | 'TEMPLATES' | 'CREATE_WIZARD';
type WizardStep = 'EVENT_SELECT' | 'CONTENT' | 'AUDIENCE' | 'SCHEDULE';

const MAX_DAILY_LIMIT = 500; // Limit emails per day to avoid spam

const CampaignManager: React.FC<CampaignManagerProps> = ({ 
    catalogues, contactGroups, setContactGroups, 
    events, setEvents, 
    campaignTemplates, setCampaignTemplates,
    onStatsUpdate, onNavigateToContacts, logActivity, onMoveToTrash 
}) => {
    // Main View State
    const [activeTab, setActiveTab] = useState<Tab>('HISTORY');
    const [campaigns, setCampaigns] = useState<Campaign[]>([]);

    // History Search & Filter State
    const [historySearch, setHistorySearch] = useState('');
    const [historyFilter, setHistoryFilter] = useState<CampaignStatus | 'ALL'>('ALL');

    // --- EVENT MANAGEMENT STATE ---
    const [newEventName, setNewEventName] = useState('');
    const [newEventDate, setNewEventDate] = useState('');
    const [newEventNote, setNewEventNote] = useState('');
    const [isSuggestingForEvent, setIsSuggestingForEvent] = useState(false);
    const [eventToDelete, setEventToDelete] = useState<MarketingEvent | null>(null);
    const [eventViewMode, setEventViewMode] = useState<'grid' | 'list'>('grid');
    
    // New State for Month Tabs
    const currentMonthIndex = new Date().getMonth() + 1; // 1-12
    const [activeEventMonth, setActiveEventMonth] = useState<number>(currentMonthIndex);

    // --- TEMPLATE MANAGEMENT STATE ---
    const [viewingTemplate, setViewingTemplate] = useState<CampaignTemplate | null>(null);
    const [templateToDelete, setTemplateToDelete] = useState<CampaignTemplate | null>(null);

    // --- WIZARD STATE ---
    const [wizardStep, setWizardStep] = useState<WizardStep>('EVENT_SELECT');
    const [selectedEventId, setSelectedEventId] = useState<string>(''); // Can be empty if skipping
    const [selectedCatalogueId, setSelectedCatalogueId] = useState<string>('');
    const [generatedTemplate, setGeneratedTemplate] = useState('');
    const [isGeneratingTemplate, setIsGeneratingTemplate] = useState(false);
    
    // CHANGED: selectedGroupId (string) -> selectedGroupIds (string[])
    const [selectedGroupIds, setSelectedGroupIds] = useState<string[]>([]);
    const [filterByInterest, setFilterByInterest] = useState(false); // Default false to show all
    
    const [scheduleDate, setScheduleDate] = useState('');
    const [campaignName, setCampaignName] = useState('');
    const [customInstruction, setCustomInstruction] = useState('');

    // --- MODAL STATES ---
    const [viewingQuoteLead, setViewingQuoteLead] = useState<Lead | null>(null);
    const [showSuccessModal, setShowSuccessModal] = useState(false);
    const [lastCampaignStatus, setLastCampaignStatus] = useState<'SENT' | 'SCHEDULED'>('SENT');

    // --- EFFECT: Auto Generate Preview ---
    useEffect(() => {
        if (activeTab === 'CREATE_WIZARD' && wizardStep === 'CONTENT' && selectedCatalogueId) {
            const timer = setTimeout(() => {
                handleGeneratePreview();
            }, 800); 
            return () => clearTimeout(timer);
        }
    }, [selectedCatalogueId, customInstruction, activeTab, wizardStep]);

    // --- HANDLERS FOR EVENTS ---
    const handleAddEvent = async () => {
        if(!newEventName || !newEventDate) return;
        setIsSuggestingForEvent(true);
        
        let suggestedIds: string[] = [];
        try {
            suggestedIds = await suggestCataloguesForEvent(newEventName, newEventNote, catalogues);
        } catch (e) {
            console.error(e);
        } finally {
             setIsSuggestingForEvent(false);
        }

        const newEvent: MarketingEvent = {
            id: Date.now().toString(),
            name: newEventName,
            date: newEventDate,
            note: newEventNote,
            suggestedCatalogueIds: suggestedIds
        };
        setEvents([...events, newEvent].sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime()));
        
        // Switch to the month of the new event
        const newEvtMonth = new Date(newEventDate).getMonth() + 1;
        setActiveEventMonth(newEvtMonth);

        logActivity('SYSTEM', 'Tạo sự kiện mới', newEventName, 'SUCCESS');
        setNewEventName('');
        setNewEventDate('');
        setNewEventNote('');
    };

    const confirmDeleteEvent = () => {
        if (eventToDelete) {
            onMoveToTrash(eventToDelete, 'EVENT', eventToDelete.name);
            setEventToDelete(null);
        }
    };

    const handleSyncEcommerceEvents = () => {
        const currentYear = new Date().getFullYear();
        const newEvents: MarketingEvent[] = [];
        const catalogueIds = catalogues.map(c => c.id);

        // 1. Double Days (1.1, 2.2 ... 12.12)
        for (let i = 1; i <= 12; i++) {
            const dateStr = `${currentYear}-${i.toString().padStart(2, '0')}-${i.toString().padStart(2, '0')}`;
            // Randomly select 1-2 catalogues for variety
            const randomCatIds = catalogueIds.sort(() => 0.5 - Math.random()).slice(0, 2);
            
            newEvents.push({
                id: `double-${i}-${currentYear}`,
                name: `Siêu Sale ${i}.${i} (Ngày Đôi)`,
                date: dateStr,
                note: `Chiến dịch đồng bộ sàn TMĐT lớn nhất tháng ${i}. Tập trung đẩy hàng tồn và Flash Sale.`,
                suggestedCatalogueIds: randomCatIds
            });
        }

        // 2. Mid Month Sales (15th)
        for (let i = 1; i <= 12; i++) {
            const dateStr = `${currentYear}-${i.toString().padStart(2, '0')}-15`;
            const randomCatIds = catalogueIds.sort(() => 0.5 - Math.random()).slice(0, 1);
            
            newEvents.push({
                id: `mid-${i}-${currentYear}`,
                name: `Sale Giữa Tháng ${i}`,
                date: dateStr,
                note: 'Săn sale giữa tháng - Cơ hội kích cầu nhẹ.',
                suggestedCatalogueIds: randomCatIds
            });
        }

        // 3. Payday Sales (25th)
        for (let i = 1; i <= 12; i++) {
            const dateStr = `${currentYear}-${i.toString().padStart(2, '0')}-25`;
            // Payday usually good for expensive items
            const randomCatIds = catalogueIds.slice(0, 2); 
            
            newEvents.push({
                id: `payday-${i}-${currentYear}`,
                name: `Sale Lương Về Tháng ${i}`,
                date: dateStr,
                note: 'Khách hàng có tài chính mạnh nhất vào cuối tháng. Tập trung bán combo giá trị cao.',
                suggestedCatalogueIds: randomCatIds
            });
        }

        // Filter out existing events by date to prevent duplicates
        const existingDates = new Set(events.map(e => e.date));
        const finalEvents = newEvents.filter(e => !existingDates.has(e.date));

        if (finalEvents.length === 0) {
            alert('Lịch sự kiện năm nay đã đầy đủ!');
            return;
        }

        setEvents(prev => [...prev, ...finalEvents].sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime()));
        logActivity('SYSTEM', 'Đồng bộ Lịch Sàn TMĐT', `Đã thêm ${finalEvents.length} sự kiện`, 'SUCCESS');
        alert(`Đã đồng bộ thành công ${finalEvents.length} sự kiện từ các sàn TMĐT!`);
    };

    // --- HANDLERS FOR TEMPLATES ---
    const handleUseTemplate = (template: CampaignTemplate) => {
        setCampaignName(template.name.replace(' (Mẫu)', ''));
        setSelectedCatalogueId(template.catalogueId);
        setSelectedGroupIds(template.targetGroupIds || []);
        setCustomInstruction(template.customInstruction);
        setWizardStep('SCHEDULE'); 
        setActiveTab('CREATE_WIZARD');
        setGeneratedTemplate('');
        setWizardStep('CONTENT');
        setViewingTemplate(null); // Close modal if open
    };

    const confirmDeleteTemplate = () => {
        if (templateToDelete) {
            onMoveToTrash(templateToDelete, 'CAMPAIGN_TEMPLATE', templateToDelete.name);
            setTemplateToDelete(null); // Close confirmation modal
            setViewingTemplate(null); // Close detail modal if open
        }
    };

    // --- HANDLERS FOR WIZARD ---

    const handleGeneratePreview = async () => {
        const catalogue = catalogues.find(c => c.id === selectedCatalogueId);
        if (!catalogue) return;
        const event = events.find(e => e.id === selectedEventId);

        setIsGeneratingTemplate(true);
        try {
            const template = await generateEmailTemplate(catalogue, event?.name, customInstruction);
            setGeneratedTemplate(template);
        } catch (error: any) {
            console.log("Error generating template", error);
        } finally {
            setIsGeneratingTemplate(false);
        }
    };

    const handleSelectEventInWizard = (evtId: string) => {
        setSelectedEventId(evtId);
        const evt = events.find(e => e.id === evtId);
        if(evt) {
            setCampaignName(`Chiến dịch ${evt.name}`);
            setScheduleDate(`${evt.date}T09:00`); 
            if (evt.suggestedCatalogueIds.length > 0) {
                const firstSuggestedId = evt.suggestedCatalogueIds[0];
                if (firstSuggestedId !== selectedCatalogueId) {
                    setSelectedCatalogueId(firstSuggestedId);
                    setGeneratedTemplate('');
                }
            }
        } else {
             if(!campaignName) setCampaignName('');
             setScheduleDate('');
        }
    };

    // Get all leads from all selected groups
    const getSelectedLeads = () => {
        return contactGroups
            .filter(g => selectedGroupIds.includes(g.id))
            .flatMap(g => g.leads);
    };

    const toggleGroupSelection = (id: string) => {
        const group = contactGroups.find(g => g.id === id);
        if (!group) return;

        const isSelected = selectedGroupIds.includes(id);

        if (isSelected) {
            // Deselecting is always allowed
            setSelectedGroupIds(prev => prev.filter(g => g !== id));
        } else {
            // Selecting: Check limit
            const currentCount = getSelectedLeads().length;
            const newTotal = currentCount + group.leads.length;

            if (newTotal > MAX_DAILY_LIMIT) {
                alert(`⚠️ VƯỢT QUÁ GIỚI HẠN GỬI!\n\nĐể đảm bảo an toàn và không bị Spam, bạn chỉ được gửi tối đa ${MAX_DAILY_LIMIT} email/ngày.\n\n- Hiện tại: ${currentCount} khách\n- Nhóm này: ${group.leads.length} khách\n- Tổng: ${newTotal} (Vượt quá ${newTotal - MAX_DAILY_LIMIT})\n\nVui lòng chọn nhóm nhỏ hơn hoặc bỏ chọn bớt các nhóm khác.`);
                return;
            }
            setSelectedGroupIds(prev => [...prev, id]);
        }
    };

    const handleSingleSend = async (lead: Lead) => {
        // Find which group this lead belongs to
        const group = contactGroups.find(g => g.leads.some(l => l.id === lead.id));
        const catalogue = catalogues.find(c => c.id === selectedCatalogueId);
        if (!group || !catalogue) return;

        const updateLeadStatus = (status: LeadStatus) => {
            const updatedGroups = contactGroups.map(g => {
                if (g.id === group.id) {
                    return {
                        ...g,
                        leads: g.leads.map(l => l.id === lead.id ? { ...l, status } : l)
                    };
                }
                return g;
            });
            setContactGroups(updatedGroups);
        };

        updateLeadStatus(LeadStatus.SENDING);

        try {
            await generateSalesEmail(lead.companyName, lead.productInterest, catalogue);
            await new Promise(resolve => setTimeout(resolve, 1500));
            updateLeadStatus(LeadStatus.SENT);
            onStatsUpdate(1);
            logActivity('CAMPAIGN', 'Gửi lẻ (Thử nghiệm)', `Đến: ${lead.companyName}`, 'SUCCESS');
        } catch (e) {
            updateLeadStatus(LeadStatus.FAILED);
            alert("Gửi thất bại cho khách hàng này.");
        }
    };

    const handleFinishCampaign = (isScheduled: boolean) => {
        if (!campaignName) {
             alert("Vui lòng đặt tên cho chiến dịch.");
             return;
        }

        const selectedLeads = getSelectedLeads();
        if (selectedLeads.length === 0) return;

        const newCampaign: Campaign = {
            id: Date.now().toString(),
            name: campaignName,
            catalogueId: selectedCatalogueId,
            targetGroupIds: selectedGroupIds,
            status: isScheduled ? CampaignStatus.SCHEDULED : CampaignStatus.COMPLETED,
            scheduledTime: isScheduled && scheduleDate ? new Date(scheduleDate).getTime() : Date.now(),
            totalLeads: selectedLeads.length,
            successCount: isScheduled ? 0 : selectedLeads.length, 
            templatePreview: generatedTemplate,
            sentTime: isScheduled ? undefined : Date.now(),
            eventId: selectedEventId || undefined
        };

        setCampaigns([newCampaign, ...campaigns]);
        
        const logAction = isScheduled ? 'Lên lịch chiến dịch' : 'Gửi chiến dịch ngay';
        logActivity('CAMPAIGN', logAction, `${campaignName} (${selectedLeads.length} khách)`, 'SUCCESS');

        if (!isScheduled) {
             // Update status for leads in ALL selected groups
             const updatedGroups = contactGroups.map(g => {
                if (selectedGroupIds.includes(g.id)) {
                    return {
                        ...g,
                        leads: g.leads.map(l => ({ ...l, status: LeadStatus.SENT }))
                    };
                }
                return g;
            });
            setContactGroups(updatedGroups);
            onStatsUpdate(selectedLeads.length);
        }

        // Show Success Modal instead of Window Confirm
        setLastCampaignStatus(isScheduled ? 'SCHEDULED' : 'SENT');
        setShowSuccessModal(true);
    };

    const handleSaveAsTemplate = () => {
        const newTemplate: CampaignTemplate = {
            id: Date.now().toString(),
            name: campaignName + ' (Mẫu)',
            catalogueId: selectedCatalogueId,
            targetGroupIds: selectedGroupIds,
            customInstruction: customInstruction
        };
        setCampaignTemplates([...campaignTemplates, newTemplate]);
        logActivity('CAMPAIGN', 'Lưu mẫu chiến dịch', newTemplate.name, 'SUCCESS');
        handleCloseSuccessModal();
    };

    const handleCloseSuccessModal = () => {
        setShowSuccessModal(false);
        setActiveTab('HISTORY');
        resetWizard();
    };

    const resetWizard = () => {
        setWizardStep('EVENT_SELECT');
        setSelectedCatalogueId('');
        setGeneratedTemplate('');
        setSelectedGroupIds([]);
        setScheduleDate('');
        setCampaignName('');
        setSelectedEventId('');
        setCustomInstruction('');
        setFilterByInterest(false);
    };

    // Filter & Sort Contact Groups
    // Logic: Show all groups by default, but put matching ones on top.
    const displayedContactGroups = contactGroups
        .filter(group => !filterByInterest || (!group.catalogueId || group.catalogueId === selectedCatalogueId))
        .sort((a, b) => {
            // Sort matching groups to the top
            const aMatch = a.catalogueId === selectedCatalogueId ? 1 : 0;
            const bMatch = b.catalogueId === selectedCatalogueId ? 1 : 0;
            return bMatch - aMatch;
        });

    const filteredCampaigns = campaigns.filter(c => {
        const matchesSearch = c.name.toLowerCase().includes(historySearch.toLowerCase());
        const matchesStatus = historyFilter === 'ALL' || c.status === historyFilter;
        return matchesSearch && matchesStatus;
    });

    // --- HELPERS FOR EVENT TABS ---
    const getEventsForMonth = (month: number) => {
        return events.filter(e => {
            // Assuming date format YYYY-MM-DD
            const m = parseInt(e.date.split('-')[1]);
            return m === month;
        });
    };
    
    // Count events per month to show dots/badges
    const eventCounts = Array.from({ length: 12 }, (_, i) => getEventsForMonth(i + 1).length);
    const currentViewEvents = getEventsForMonth(activeEventMonth);

    // --- RENDER HELPERS ---

    const renderDeleteEventModal = () => {
        if (!eventToDelete) return null;
        return (
            <div className="fixed inset-0 bg-black/50 z-[90] flex items-center justify-center p-4 animate-fade-in">
                <div className="bg-white rounded-xl shadow-xl w-full max-w-sm p-6">
                    <div className="flex flex-col items-center text-center mb-6">
                        <div className="w-12 h-12 bg-red-100 text-red-500 rounded-full flex items-center justify-center mb-4">
                            <AlertTriangle size={28} />
                        </div>
                        <h3 className="text-lg font-bold text-slate-800">Xóa Sự Kiện?</h3>
                        <p className="text-sm text-slate-500 mt-2">
                            Bạn có chắc muốn xóa sự kiện <strong>"{eventToDelete.name}"</strong>? <br/>
                            Dữ liệu sẽ được chuyển vào thùng rác.
                        </p>
                    </div>
                    <div className="flex gap-3">
                        <button 
                            onClick={() => setEventToDelete(null)}
                            className="flex-1 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg transition-colors"
                        >
                            Hủy bỏ
                        </button>
                        <button 
                            onClick={confirmDeleteEvent}
                            className="flex-1 px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-medium rounded-lg transition-colors"
                        >
                            Xóa & Backup
                        </button>
                    </div>
                </div>
            </div>
        );
    };

    const renderDeleteTemplateModal = () => {
        if (!templateToDelete) return null;
        return (
            <div className="fixed inset-0 bg-black/50 z-[90] flex items-center justify-center p-4 animate-fade-in">
                <div className="bg-white rounded-xl shadow-xl w-full max-w-sm p-6">
                    <div className="flex flex-col items-center text-center mb-6">
                        <div className="w-12 h-12 bg-red-100 text-red-500 rounded-full flex items-center justify-center mb-4">
                            <AlertTriangle size={28} />
                        </div>
                        <h3 className="text-lg font-bold text-slate-800">Xóa Mẫu Chiến Dịch?</h3>
                        <p className="text-sm text-slate-500 mt-2">
                            Bạn có chắc muốn xóa mẫu <strong>"{templateToDelete.name}"</strong> không? <br/>
                            Dữ liệu sẽ được chuyển vào <strong>Thùng rác</strong> và tự động xóa sau 30 ngày.
                        </p>
                    </div>
                    <div className="flex gap-3">
                        <button 
                            onClick={() => setTemplateToDelete(null)}
                            className="flex-1 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg transition-colors"
                        >
                            Hủy bỏ
                        </button>
                        <button 
                            onClick={confirmDeleteTemplate}
                            className="flex-1 px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-medium rounded-lg transition-colors"
                        >
                            Xóa & Backup
                        </button>
                    </div>
                </div>
            </div>
        );
    };

    const renderTemplateDetailModal = () => {
        if (!viewingTemplate) return null;
        const catName = catalogues.find(c => c.id === viewingTemplate.catalogueId)?.name || 'Không tìm thấy';
        
        // Get names of all groups
        const groupNames = contactGroups
            .filter(g => viewingTemplate.targetGroupIds.includes(g.id))
            .map(g => g.name)
            .join(', ');

        return (
            <div className="fixed inset-0 bg-black/50 z-[80] flex items-center justify-center p-4 animate-fade-in">
                <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col">
                    <div className="bg-slate-50 p-6 border-b border-slate-200 flex justify-between items-center">
                        <div>
                            <h3 className="text-lg font-bold text-slate-800">{viewingTemplate.name}</h3>
                            <p className="text-sm text-slate-500">Chi tiết cấu hình mẫu</p>
                        </div>
                        <button onClick={() => setViewingTemplate(null)} className="text-slate-400 hover:text-slate-600">
                            <XCircle size={24} />
                        </button>
                    </div>
                    <div className="p-6 space-y-4">
                        <div className="flex items-start gap-3">
                            <div className="p-2 bg-blue-50 text-blue-600 rounded-lg"><Tag size={18}/></div>
                            <div>
                                <p className="text-sm text-slate-500 font-medium">Sản phẩm tiếp thị:</p>
                                <p className="text-slate-800 font-bold">{catName}</p>
                            </div>
                        </div>
                        <div className="flex items-start gap-3">
                            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg"><Filter size={18}/></div>
                            <div>
                                <p className="text-sm text-slate-500 font-medium">Nhóm khách hàng mục tiêu:</p>
                                <p className="text-slate-800 font-bold">{groupNames || 'Không xác định'}</p>
                            </div>
                        </div>
                        <div className="mt-2">
                            <p className="text-sm text-slate-500 font-medium mb-2 flex items-center gap-2">
                                <PenTool size={14}/> Lời nhắc cho AI (Custom Instruction):
                            </p>
                            <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-sm text-slate-700 italic">
                                "{viewingTemplate.customInstruction || 'Không có ghi chú đặc biệt'}"
                            </div>
                        </div>
                    </div>
                    <div className="p-4 border-t border-slate-200 flex gap-3 bg-slate-50">
                        <button 
                            onClick={() => setTemplateToDelete(viewingTemplate)}
                            className="px-4 py-2 border border-red-200 text-red-600 hover:bg-red-50 rounded-lg font-medium flex items-center gap-2"
                        >
                            <Trash2 size={16} /> Xóa mẫu
                        </button>
                        <button 
                            onClick={() => handleUseTemplate(viewingTemplate)}
                            className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold flex items-center justify-center gap-2 shadow-sm"
                        >
                            <Play size={16} /> Sử dụng mẫu này ngay
                        </button>
                    </div>
                </div>
            </div>
        );
    };

    const renderQuoteModal = () => {
        if (!viewingQuoteLead) return null;
        const catName = catalogues.find(c => c.id === selectedCatalogueId)?.name || 'Sản phẩm';
        const itemPrice = Math.floor(Math.random() * 5000000) + 500000;
        const qty = Math.floor(Math.random() * 5) + 1;
        const total = itemPrice * qty;

        return (
            <div className="fixed inset-0 bg-black/50 z-[70] flex items-center justify-center p-4 animate-fade-in">
                <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
                    <div className="bg-slate-50 p-6 border-b border-slate-200 flex justify-between items-center">
                        <div>
                            <h3 className="text-lg font-bold text-slate-800">Báo Giá Sơ Bộ (Mô Phỏng)</h3>
                            <p className="text-sm text-slate-500">Dành cho: {viewingQuoteLead.companyName}</p>
                        </div>
                        <button onClick={() => setViewingQuoteLead(null)} className="text-slate-400 hover:text-slate-600"><XCircle size={24} /></button>
                    </div>
                    <div className="p-6 overflow-y-auto">
                        <div className="flex justify-between items-start mb-6 text-sm">
                            <div>
                                <p className="text-slate-500">Ngày tạo:</p>
                                <p className="font-medium text-slate-800">{new Date().toLocaleDateString('vi-VN')}</p>
                            </div>
                            <div className="text-right">
                                <p className="text-slate-500">Hiệu lực:</p>
                                <p className="font-medium text-slate-800">07 ngày</p>
                            </div>
                        </div>
                        <table className="w-full text-sm mb-6">
                            <thead>
                                <tr className="border-b-2 border-slate-100">
                                    <th className="text-left py-2 text-slate-600">Sản phẩm</th>
                                    <th className="text-right py-2 text-slate-600">SL</th>
                                    <th className="text-right py-2 text-slate-600">Đơn giá</th>
                                    <th className="text-right py-2 text-slate-600">Thành tiền</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-50">
                                <tr>
                                    <td className="py-3 font-medium text-slate-800">{viewingQuoteLead.productInterest} <span className="text-xs text-slate-400 block font-normal">({catName})</span></td>
                                    <td className="py-3 text-right text-slate-600">{qty}</td>
                                    <td className="py-3 text-right text-slate-600">{itemPrice.toLocaleString('vi-VN')} đ</td>
                                    <td className="py-3 text-right font-bold text-slate-800">{total.toLocaleString('vi-VN')} đ</td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr className="border-t border-slate-200">
                                    <td colSpan={3} className="pt-4 text-right font-bold text-slate-600">Tổng cộng:</td>
                                    <td className="pt-4 text-right font-bold text-blue-600 text-lg">{total.toLocaleString('vi-VN')} đ</td>
                                </tr>
                            </tfoot>
                        </table>
                        <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-100 text-xs text-yellow-800">
                            <strong>Ghi chú nội bộ:</strong> Đây là báo giá hệ thống tự tính toán dựa trên mức giá sỉ trung bình. Vui lòng xác nhận lại với kho trước khi gửi bản cứng cho khách.
                        </div>
                    </div>
                    <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end gap-2">
                        <button onClick={() => setViewingQuoteLead(null)} className="px-4 py-2 text-slate-600 hover:bg-slate-200 rounded-lg font-medium text-sm">Đóng</button>
                        <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium text-sm flex items-center gap-2">
                            <FileDown size={16} /> Tải PDF
                        </button>
                    </div>
                </div>
            </div>
        );
    };

    const renderSuccessModal = () => {
        if (!showSuccessModal) return null;
        const totalLeads = getSelectedLeads().length;

        return (
            <div className="fixed inset-0 bg-black/60 z-[80] flex items-center justify-center p-4 animate-fade-in">
                <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden transform transition-all scale-100">
                    <div className="bg-green-600 p-6 text-white text-center">
                        <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4 backdrop-blur-sm">
                            <CheckCircle2 size={36} className="text-white" />
                        </div>
                        <h3 className="text-2xl font-bold">
                            {lastCampaignStatus === 'SENT' ? 'Gửi Thành Công!' : 'Đã Lên Lịch!'}
                        </h3>
                        <p className="text-green-100 mt-2">
                            {lastCampaignStatus === 'SENT' 
                                ? `Chiến dịch đã được gửi tới ${totalLeads} khách hàng.` 
                                : `Chiến dịch sẽ tự động chạy vào ${new Date(scheduleDate).toLocaleString('vi-VN')}.`
                            }
                        </p>
                    </div>
                    
                    <div className="p-6 space-y-4">
                        <p className="text-slate-600 text-center text-sm mb-4">
                            Bạn có muốn <strong>lưu lại cấu hình này</strong> (Sản phẩm, nhóm khách, lời nhắc AI) để tái sử dụng cho lần sau không?
                        </p>
                        
                        <button 
                            onClick={handleSaveAsTemplate}
                            className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold shadow-lg shadow-blue-200 flex items-center justify-center gap-2 transition-all active:scale-95"
                        >
                            <Save size={20} /> Lưu Làm Mẫu (Khuyên dùng)
                        </button>
                        
                        <button 
                            onClick={handleCloseSuccessModal}
                            className="w-full py-3 bg-white border border-slate-200 text-slate-600 hover:bg-slate-50 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors"
                        >
                            <History size={18} /> Không lưu, quay lại danh sách
                        </button>
                    </div>
                </div>
            </div>
        );
    };

    const renderEventManager = () => (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                 <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                    <CalendarRange size={24} className="text-purple-600" />
                    Quản Lý Sự Kiện & Ngày Lễ
                </h2>
                <div className="flex gap-2 items-center">
                    <div className="flex bg-slate-100 p-1 rounded-lg mr-2">
                        <button 
                            onClick={() => setEventViewMode('grid')}
                            className={`p-1.5 rounded transition-colors ${eventViewMode === 'grid' ? 'bg-white text-purple-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                            title="Dạng lưới"
                        >
                            <LayoutGrid size={16} />
                        </button>
                        <button 
                            onClick={() => setEventViewMode('list')}
                            className={`p-1.5 rounded transition-colors ${eventViewMode === 'list' ? 'bg-white text-purple-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                            title="Dạng danh sách"
                        >
                            <List size={16} />
                        </button>
                    </div>

                    <button
                        onClick={handleSyncEcommerceEvents}
                        className="bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 px-3 py-2 rounded-lg font-medium flex items-center gap-2 text-sm transition-colors shadow-sm"
                        title="Tự động thêm các ngày 1.1, 2.2, 15, 25..."
                    >
                        <CloudLightning size={16} /> Đồng bộ Lịch Sàn TMĐT
                    </button>
                    <button onClick={() => setActiveTab('HISTORY')} className="text-slate-500 hover:text-slate-800 font-medium px-2">
                        Quay lại
                    </button>
                </div>
            </div>

            {/* ADD EVENT FORM */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                <h3 className="font-bold text-slate-800 mb-4">Thêm Sự Kiện Mới</h3>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                    <div className="md:col-span-1">
                        <label className="block text-xs font-medium text-slate-500 mb-1">Tên sự kiện</label>
                        <input 
                            type="text" 
                            className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-purple-500 bg-white text-black"
                            placeholder="VD: 30/4 - 1/5"
                            value={newEventName}
                            onChange={(e) => setNewEventName(e.target.value)}
                        />
                    </div>
                    <div className="md:col-span-1">
                        <label className="block text-xs font-medium text-slate-500 mb-1">Ngày diễn ra</label>
                         <input 
                            type="date" 
                            className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-purple-500 bg-white text-black"
                            value={newEventDate}
                            onChange={(e) => setNewEventDate(e.target.value)}
                        />
                    </div>
                     <div className="md:col-span-1">
                        <label className="block text-xs font-medium text-slate-500 mb-1">Ghi chú (để AI phân tích)</label>
                         <input 
                            type="text" 
                            className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-purple-500 bg-white text-black"
                            placeholder="VD: Dọn dẹp nhà xưởng..."
                            value={newEventNote}
                            onChange={(e) => setNewEventNote(e.target.value)}
                        />
                    </div>
                     <div className="md:col-span-1">
                        <button 
                            onClick={handleAddEvent}
                            disabled={!newEventName || !newEventDate || isSuggestingForEvent}
                            className="w-full bg-purple-600 hover:bg-purple-700 disabled:bg-slate-300 text-white font-medium py-2 rounded-lg flex justify-center items-center gap-2"
                        >
                            {isSuggestingForEvent ? <Loader2 size={16} className="animate-spin" /> : <Plus size={16} />}
                            Thêm & Phân Tích
                        </button>
                    </div>
                </div>
            </div>

            {/* MONTH TABS NAVIGATION */}
            <div className="flex overflow-x-auto pb-2 gap-2 scrollbar-hide">
                {Array.from({ length: 12 }, (_, i) => i + 1).map(month => {
                    const isActive = activeEventMonth === month;
                    const isCurrentMonth = currentMonthIndex === month;
                    const count = eventCounts[month - 1];

                    return (
                        <button
                            key={month}
                            onClick={() => setActiveEventMonth(month)}
                            className={`flex-shrink-0 px-4 py-2.5 rounded-lg text-sm font-medium transition-all relative ${
                                isActive 
                                ? 'bg-purple-600 text-white shadow-md' 
                                : isCurrentMonth 
                                    ? 'bg-purple-50 text-purple-700 border border-purple-200' 
                                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                            }`}
                        >
                            <span className="flex items-center gap-1.5">
                                {isCurrentMonth && isActive && <Pin size={12} className="text-white" fill="white" />}
                                {isCurrentMonth && !isActive && <Pin size={12} className="text-purple-600" />}
                                Tháng {month}
                            </span>
                            {count > 0 && (
                                <span className={`absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full text-[10px] border-2 border-white ${isActive ? 'bg-white text-purple-600' : 'bg-red-500 text-white'}`}>
                                    {count}
                                </span>
                            )}
                        </button>
                    );
                })}
            </div>

            {/* CURRENT MONTH BANNER */}
            {activeEventMonth === currentMonthIndex && currentViewEvents.length > 0 && (
                <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl p-4 text-white shadow-md flex items-center gap-4 animate-fade-in">
                    <div className="bg-white/20 p-2 rounded-full">
                        <BellRing size={24} className="animate-pulse" />
                    </div>
                    <div>
                        <h4 className="font-bold text-lg">Tiêu Điểm Tháng {activeEventMonth} (Tháng Hiện Tại)</h4>
                        <p className="text-indigo-100 text-sm">Có {currentViewEvents.length} sự kiện quan trọng. Hãy chuẩn bị chiến dịch Marketing ngay!</p>
                    </div>
                </div>
            )}

            {/* EVENTS DISPLAY AREA */}
            {currentViewEvents.length === 0 ? (
                <div className="text-center py-12 bg-slate-50 rounded-xl border border-dashed border-slate-300">
                    <Calendar size={48} className="mx-auto mb-3 text-slate-300" />
                    <p className="text-slate-500">Tháng {activeEventMonth} chưa có sự kiện nào.</p>
                </div>
            ) : (
                <>
                {eventViewMode === 'grid' ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {currentViewEvents.map(evt => {
                            const isCurrentMonthEvent = (new Date().getMonth() + 1) === activeEventMonth;
                            
                            return (
                                <div key={evt.id} className={`p-5 rounded-xl border shadow-sm relative group transition-all ${isCurrentMonthEvent ? 'bg-white border-purple-200 ring-1 ring-purple-100' : 'bg-white border-slate-200'}`}>
                                    <button 
                                        onClick={() => setEventToDelete(evt)}
                                        className="absolute top-3 right-3 text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                                    >
                                        <Trash2 size={16} />
                                    </button>
                                    <div className="flex items-center gap-3 mb-3">
                                        <div className={`w-12 h-12 rounded-lg flex flex-col items-center justify-center font-bold border ${isCurrentMonthEvent ? 'bg-purple-100 text-purple-700 border-purple-200' : 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                                            <span className="text-xs uppercase">{new Date(evt.date).toLocaleString('default', { month: 'short' })}</span>
                                            <span className="text-lg leading-none">{new Date(evt.date).getDate()}</span>
                                        </div>
                                        <div>
                                            <h4 className="font-bold text-slate-800">{evt.name}</h4>
                                            <p className="text-xs text-slate-500">{evt.note || 'Không có ghi chú'}</p>
                                        </div>
                                    </div>
                                    
                                    <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                                        <p className="text-xs font-medium text-slate-500 mb-2 flex items-center gap-1">
                                            <Sparkles size={12} className="text-yellow-500"/> Ngành hàng đề xuất:
                                        </p>
                                        <div className="flex flex-wrap gap-1">
                                            {evt.suggestedCatalogueIds.length > 0 ? (
                                                evt.suggestedCatalogueIds.map(catId => {
                                                    const cat = catalogues.find(c => c.id === catId);
                                                    return cat ? (
                                                        <span key={catId} className="px-2 py-0.5 bg-white border border-slate-200 rounded text-xs text-slate-700">
                                                            {cat.name}
                                                        </span>
                                                    ) : null;
                                                })
                                            ) : (
                                                <span className="text-xs text-slate-400 italic">Chưa có đề xuất</span>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                ) : (
                    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden animate-fade-in">
                        <table className="w-full text-left text-sm">
                            <thead className="bg-slate-50 text-slate-600 font-medium border-b border-slate-200">
                                <tr>
                                    <th className="px-4 py-3 w-32">Ngày</th>
                                    <th className="px-4 py-3">Tên Sự Kiện</th>
                                    <th className="px-4 py-3">Ghi Chú & Phân Tích</th>
                                    <th className="px-4 py-3">Sản Phẩm Đề Xuất</th>
                                    <th className="px-4 py-3 w-16"></th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                {currentViewEvents.map(evt => {
                                     const isCurrentMonthEvent = (new Date().getMonth() + 1) === activeEventMonth;
                                     return (
                                        <tr key={evt.id} className={`hover:bg-slate-50 transition-colors ${isCurrentMonthEvent ? 'bg-purple-50/30' : ''}`}>
                                            <td className="px-4 py-3">
                                                 <span className={`inline-block px-2 py-1 rounded text-xs font-bold ${isCurrentMonthEvent ? 'bg-purple-100 text-purple-700' : 'bg-slate-100 text-slate-600'}`}>
                                                    {new Date(evt.date).toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit' })}
                                                 </span>
                                            </td>
                                            <td className="px-4 py-3 font-medium text-slate-800">{evt.name}</td>
                                            <td className="px-4 py-3 text-slate-500 italic">{evt.note || '-'}</td>
                                            <td className="px-4 py-3">
                                                <div className="flex flex-wrap gap-1">
                                                    {evt.suggestedCatalogueIds.length > 0 ? (
                                                        evt.suggestedCatalogueIds.map(catId => {
                                                            const cat = catalogues.find(c => c.id === catId);
                                                            return cat ? (
                                                                <span key={catId} className="px-2 py-0.5 bg-white border border-slate-200 rounded text-xs text-slate-700">
                                                                    {cat.name}
                                                                </span>
                                                            ) : null;
                                                        })
                                                    ) : (
                                                        <span className="text-xs text-slate-400">Chưa có</span>
                                                    )}
                                                </div>
                                            </td>
                                            <td className="px-4 py-3 text-right">
                                                <button 
                                                    onClick={() => setEventToDelete(evt)}
                                                    className="p-1 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded transition-colors"
                                                >
                                                    <Trash2 size={16} />
                                                </button>
                                            </td>
                                        </tr>
                                     );
                                })}
                            </tbody>
                        </table>
                    </div>
                )}
                </>
            )}
        </div>
    );

    const renderTemplates = () => (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                    <LayoutTemplate size={24} className="text-orange-500" />
                    Mẫu Chiến Dịch Đã Lưu
                </h2>
                <button onClick={() => setActiveTab('HISTORY')} className="text-slate-500 hover:text-slate-800 font-medium">
                    Quay lại danh sách
                </button>
            </div>
            {campaignTemplates.length === 0 ? (
                <div className="p-8 text-center text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-300">
                    <LayoutTemplate size={48} className="mx-auto mb-3 opacity-20" />
                    <p>Chưa có mẫu nào.</p>
                    <p className="text-sm">Khi tạo xong chiến dịch, bạn có thể lưu lại làm mẫu.</p>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {campaignTemplates.map(t => {
                        const groupNames = contactGroups
                            .filter(g => t.targetGroupIds.includes(g.id))
                            .map(g => g.name)
                            .join(', ');

                        return (
                            <div key={t.id} className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col hover:shadow-md transition-shadow">
                                <h4 className="font-bold text-slate-800 mb-2 truncate" title={t.name}>{t.name}</h4>
                                <div className="space-y-1 text-xs text-slate-600 mb-4 flex-1">
                                    <p>Sản phẩm: <span className="font-medium">{catalogues.find(c => c.id === t.catalogueId)?.name}</span></p>
                                    <p>Nhóm khách: <span className="font-medium">{groupNames || 'Không có'}</span></p>
                                </div>
                                
                                <div className="flex gap-2 mt-auto">
                                    <button
                                        onClick={() => setViewingTemplate(t)}
                                        className="p-2 bg-slate-50 text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
                                        title="Xem chi tiết"
                                    >
                                        <Eye size={18} />
                                    </button>
                                    <button
                                        onClick={() => setTemplateToDelete(t)}
                                        className="p-2 bg-slate-50 text-red-500 rounded-lg hover:bg-red-50 hover:border-red-100 border border-transparent transition-all"
                                        title="Xóa mẫu này"
                                    >
                                        <Trash2 size={18} />
                                    </button>
                                    <button 
                                        onClick={() => handleUseTemplate(t)}
                                        className="flex-1 py-2 bg-orange-50 text-orange-600 rounded-lg font-bold hover:bg-orange-100 transition-colors flex items-center justify-center gap-2 text-sm"
                                    >
                                        <Play size={14} /> Sử dụng
                                    </button>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );

    const renderHistory = () => (
        <div className="space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                    <History size={24} className="text-blue-600" />
                    Lịch Sử & Kế Hoạch Chiến Dịch
                </h2>
                <div className="flex flex-wrap gap-3">
                    <button
                        onClick={() => setActiveTab('TEMPLATES')}
                        className="bg-white text-slate-700 border border-slate-300 hover:bg-slate-50 px-4 py-2 rounded-lg font-medium flex items-center gap-2 transition-colors"
                    >
                        <LayoutTemplate size={18} /> Mẫu đã lưu
                    </button>
                    <button
                        onClick={() => setActiveTab('EVENTS')}
                        className="bg-white text-slate-700 border border-slate-300 hover:bg-slate-50 px-4 py-2 rounded-lg font-medium flex items-center gap-2 transition-colors"
                    >
                        <CalendarRange size={18} /> Quản Lý Ngày Lễ
                    </button>
                    <button
                        onClick={() => { setActiveTab('CREATE_WIZARD'); resetWizard(); }}
                        className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium flex items-center gap-2 transition-colors shadow-lg shadow-blue-200"
                    >
                        <Plus size={18} /> Tạo Chiến Dịch Mới
                    </button>
                </div>
            </div>

            {/* Search & Filter Bar */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                    <Search className="absolute left-3 top-2.5 text-slate-400" size={18} />
                    <input 
                        type="text" 
                        placeholder="Tìm kiếm chiến dịch..." 
                        className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-sm bg-white text-black"
                        value={historySearch}
                        onChange={(e) => setHistorySearch(e.target.value)}
                    />
                </div>
                <div className="flex items-center gap-2">
                    <Filter className="text-slate-400" size={18} />
                    <select 
                        className="border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none bg-white text-black"
                        value={historyFilter}
                        onChange={(e) => setHistoryFilter(e.target.value as any)}
                    >
                        <option value="ALL">Tất cả trạng thái</option>
                        <option value={CampaignStatus.COMPLETED}>Hoàn thành</option>
                        <option value={CampaignStatus.SCHEDULED}>Đã lên lịch</option>
                        <option value={CampaignStatus.DRAFT}>Nháp</option>
                        <option value={CampaignStatus.CANCELLED}>Đã hủy</option>
                    </select>
                </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                <table className="w-full text-left text-sm">
                    <thead className="bg-slate-50 text-slate-500 font-medium border-b border-slate-100">
                        <tr>
                            <th className="p-4">Tên Chiến Dịch</th>
                            <th className="p-4">Trạng Thái</th>
                            <th className="p-4">Thời Gian</th>
                            <th className="p-4">Danh Sách</th>
                            <th className="p-4">Sản Phẩm</th>
                            <th className="p-4 text-right">Số lượng</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {filteredCampaigns.length === 0 ? (
                            <tr>
                                <td colSpan={6} className="p-12 text-center text-slate-400 italic">
                                    <div className="flex flex-col items-center">
                                        <LayoutTemplate size={48} className="mb-2 opacity-20" />
                                        <p>Không tìm thấy chiến dịch nào.</p>
                                        {campaigns.length === 0 && (
                                            <button 
                                                onClick={() => setActiveTab('CREATE_WIZARD')}
                                                className="mt-2 text-blue-600 hover:underline font-medium"
                                            >
                                                Tạo chiến dịch đầu tiên ngay
                                            </button>
                                        )}
                                    </div>
                                </td>
                            </tr>
                        ) : (
                            filteredCampaigns.map(camp => {
                                const groupNames = contactGroups
                                    .filter(g => camp.targetGroupIds.includes(g.id))
                                    .map(g => g.name)
                                    .join(', ') || 'Danh bạ đã xóa';
                                
                                const catName = catalogues.find(c => c.id === camp.catalogueId)?.name || 'Unknown';
                                const event = events.find(e => e.id === camp.eventId);
                                
                                return (
                                    <tr key={camp.id} className="hover:bg-slate-50">
                                        <td className="p-4 font-medium text-slate-800">
                                            {camp.name}
                                            {event && <span className="block text-xs text-purple-600 mt-0.5">🎉 {event.name}</span>}
                                        </td>
                                        <td className="p-4">
                                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                                ${camp.status === CampaignStatus.COMPLETED ? 'bg-green-100 text-green-700' : ''}
                                                ${camp.status === CampaignStatus.SCHEDULED ? 'bg-blue-100 text-blue-700' : ''}
                                                ${camp.status === CampaignStatus.DRAFT ? 'bg-slate-100 text-slate-600' : ''}
                                                ${camp.status === CampaignStatus.CANCELLED ? 'bg-red-100 text-red-600' : ''}
                                            `}>
                                                {camp.status}
                                            </span>
                                        </td>
                                        <td className="p-4 text-slate-600">
                                            {camp.status === CampaignStatus.SCHEDULED ? (
                                                <div className="flex items-center gap-1 text-blue-600">
                                                    <Clock size={14} />
                                                    {new Date(camp.scheduledTime).toLocaleString('vi-VN')}
                                                </div>
                                            ) : (
                                                new Date(camp.sentTime || camp.scheduledTime).toLocaleDateString('vi-VN')
                                            )}
                                        </td>
                                        <td className="p-4 text-slate-600 max-w-xs truncate" title={groupNames}>{groupNames}</td>
                                        <td className="p-4 text-slate-600">{catName}</td>
                                        <td className="p-4 text-right font-medium">{camp.totalLeads}</td>
                                    </tr>
                                );
                            })
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );

    const renderWizard = () => {
        const selectedCatName = catalogues.find(c => c.id === selectedCatalogueId)?.name;
        const selectedEvent = events.find(e => e.id === selectedEventId);
        
        // Count selected leads
        const selectedLeadsCount = getSelectedLeads().length;

        return (
            <div className="max-w-5xl mx-auto">
                <div className="mb-6 flex items-center gap-2 text-slate-500 text-sm">
                    <button onClick={() => setActiveTab('HISTORY')} className="hover:text-slate-800">Chiến dịch</button>
                    <span>/</span>
                    <span className="text-slate-800 font-medium">Tạo mới</span>
                </div>

                {/* Wizard Steps Header */}
                <div className="flex items-center justify-between mb-8 px-4">
                     <div className={`flex flex-col items-center ${wizardStep === 'EVENT_SELECT' ? 'text-blue-600' : 'text-slate-400'}`}>
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-2 font-bold ${wizardStep === 'EVENT_SELECT' ? 'bg-blue-600 text-white' : 'bg-slate-200'}`}>1</div>
                        <span className="text-sm font-medium">Sự Kiện & Chiến Lược</span>
                    </div>
                     <div className="h-0.5 flex-1 bg-slate-200 mx-4"></div>
                    <div className={`flex flex-col items-center ${wizardStep === 'CONTENT' ? 'text-blue-600' : 'text-slate-400'}`}>
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-2 font-bold ${wizardStep === 'CONTENT' ? 'bg-blue-600 text-white' : 'bg-slate-200'}`}>2</div>
                        <span className="text-sm font-medium">Nội Dung Email</span>
                    </div>
                    <div className="h-0.5 flex-1 bg-slate-200 mx-4"></div>
                    <div className={`flex flex-col items-center ${wizardStep === 'AUDIENCE' ? 'text-blue-600' : 'text-slate-400'}`}>
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-2 font-bold ${wizardStep === 'AUDIENCE' ? 'bg-blue-600 text-white' : 'bg-slate-200'}`}>3</div>
                        <span className="text-sm font-medium">Chọn Danh Sách</span>
                    </div>
                    <div className="h-0.5 flex-1 bg-slate-200 mx-4"></div>
                    <div className={`flex flex-col items-center ${wizardStep === 'SCHEDULE' ? 'text-blue-600' : 'text-slate-400'}`}>
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-2 font-bold ${wizardStep === 'SCHEDULE' ? 'bg-blue-600 text-white' : 'bg-slate-200'}`}>4</div>
                        <span className="text-sm font-medium">Lên Lịch & Gửi</span>
                    </div>
                </div>

                <div className="bg-white p-8 rounded-2xl shadow-lg border border-slate-100 min-h-[500px] flex flex-col">
                    
                    {/* STEP 1: EVENT SELECTION */}
                    {wizardStep === 'EVENT_SELECT' && (
                        <div className="space-y-6 flex-1">
                            <h3 className="text-xl font-bold text-slate-800 mb-4">Bước 1: Chọn Sự Kiện (Tuỳ chọn)</h3>
                            <p className="text-sm text-slate-500 mb-4">Chọn sự kiện để hệ thống gợi ý sản phẩm phù hợp. Bạn cũng có thể bỏ qua nếu chạy chiến dịch thường.</p>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                                <div 
                                    onClick={() => handleSelectEventInWizard('')}
                                    className={`p-4 rounded-xl border cursor-pointer flex flex-col items-center justify-center text-center h-32 hover:border-slate-400 transition-all ${!selectedEventId ? 'bg-slate-100 border-slate-400 ring-1 ring-slate-400' : 'border-slate-200'}`}
                                >
                                    <span className="font-bold text-slate-700">Không theo sự kiện</span>
                                    <span className="text-xs text-slate-500">Chiến dịch thông thường</span>
                                </div>
                                {events.map(evt => {
                                    const isSelected = selectedEventId === evt.id;
                                    return (
                                        <div 
                                            key={evt.id} 
                                            onClick={() => handleSelectEventInWizard(evt.id)}
                                            className={`p-4 rounded-xl border cursor-pointer relative h-32 hover:border-purple-300 transition-all ${isSelected ? 'bg-purple-50 border-purple-500 ring-1 ring-purple-500' : 'border-slate-200'}`}
                                        >
                                            <div className="font-bold text-slate-800">{evt.name}</div>
                                            <div className="text-sm text-slate-500 flex items-center gap-1 mt-1">
                                                <Calendar size={12} /> {new Date(evt.date).toLocaleDateString('vi-VN')}
                                            </div>
                                            {evt.suggestedCatalogueIds.length > 0 && (
                                                <div className="mt-2 flex gap-1 flex-wrap">
                                                    {evt.suggestedCatalogueIds.slice(0, 2).map(id => {
                                                        const cat = catalogues.find(c => c.id === id);
                                                        return cat ? <span key={id} className="text-[10px] bg-white border border-purple-200 px-1.5 py-0.5 rounded text-purple-700">{cat.name}</span> : null;
                                                    })}
                                                </div>
                                            )}
                                        </div>
                                    );
                                })}
                            </div>

                            <div className="flex justify-end pt-6 mt-auto">
                                <button
                                    onClick={() => setWizardStep('CONTENT')}
                                    className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-medium flex items-center gap-2"
                                >
                                    Tiếp tục <ArrowRight size={18} />
                                </button>
                            </div>
                        </div>
                    )}

                    {/* STEP 2: CONTENT */}
                    {wizardStep === 'CONTENT' && (
                        <div className="space-y-6 flex-1">
                            <h3 className="text-xl font-bold text-slate-800 mb-4">Bước 2: Thiết lập Nội Dung</h3>
                            <div className="space-y-4">
                                <div>
                                    <label className="block text-sm font-medium text-slate-700 mb-2">Tên Chiến Dịch</label>
                                    <input
                                        type="text"
                                        className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-white text-black"
                                        placeholder="VD: Chào hàng..."
                                        value={campaignName}
                                        onChange={(e) => setCampaignName(e.target.value)}
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-slate-700 mb-2">Chọn Dòng Sản Phẩm Chào Bán</label>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-40 overflow-y-auto custom-scrollbar">
                                        {catalogues.map(c => {
                                            const isSuggested = selectedEvent?.suggestedCatalogueIds.includes(c.id);
                                            const isSelected = selectedCatalogueId === c.id;
                                            return (
                                                <div 
                                                    key={c.id}
                                                    onClick={() => { setSelectedCatalogueId(c.id); setGeneratedTemplate(''); setSelectedGroupIds([]); }}
                                                    className={`p-3 rounded-lg border cursor-pointer flex justify-between items-center ${isSelected ? 'border-blue-500 bg-blue-50' : 'border-slate-200 hover:bg-slate-50'}`}
                                                >
                                                    <span className="font-medium text-slate-800">{c.name}</span>
                                                    {isSuggested && <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-1 rounded-full flex items-center gap-1"><Sparkles size={10}/> Gợi ý</span>}
                                                </div>
                                            );
                                        })}
                                    </div>
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-slate-700 mb-2">Giọng văn / Ghi chú cho AI</label>
                                    <textarea
                                        className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-sm resize-none bg-white text-black"
                                        rows={2}
                                        placeholder="VD: Viết giọng vui vẻ, thân thiện. Nhấn mạnh giảm giá 10%..."
                                        value={customInstruction}
                                        onChange={(e) => setCustomInstruction(e.target.value)}
                                    />
                                </div>

                                {selectedCatalogueId && (
                                    <div className="pt-2">
                                        <div className="flex justify-between items-center mb-2">
                                            <label className="block text-sm font-medium text-slate-700">Xem trước Mẫu Email (AI Tự động)</label>
                                            <button
                                                onClick={handleGeneratePreview}
                                                disabled={isGeneratingTemplate}
                                                className="text-sm bg-indigo-50 text-indigo-600 px-3 py-1 rounded-md hover:bg-indigo-100 flex items-center gap-1"
                                            >
                                                <Wand2 size={14} /> {generatedTemplate ? 'Tạo lại' : 'Đang tạo...'}
                                            </button>
                                        </div>
                                        <div className="bg-white p-4 rounded-lg border border-slate-200 min-h-[150px] whitespace-pre-wrap text-sm text-slate-700">
                                            {isGeneratingTemplate ? (
                                                <div className="flex items-center justify-center h-full text-slate-400 gap-2">
                                                    <Loader2 className="animate-spin" /> Đang soạn thảo mẫu theo yêu cầu...
                                                </div>
                                            ) : (
                                                generatedTemplate || <span className="text-slate-400 italic">Hệ thống sẽ tự động tạo mẫu khi bạn chọn sản phẩm.</span>
                                            )}
                                        </div>
                                    </div>
                                )}
                            </div>
                            <div className="flex justify-between pt-6 mt-auto">
                                <button onClick={() => setWizardStep('EVENT_SELECT')} className="text-slate-500 hover:text-slate-800 px-4 py-2 font-medium">Quay lại</button>
                                <button
                                    disabled={!selectedCatalogueId || !campaignName || !generatedTemplate}
                                    onClick={() => setWizardStep('AUDIENCE')}
                                    className="bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white px-6 py-2 rounded-lg font-medium flex items-center gap-2"
                                >
                                    Tiếp tục <ArrowRight size={18} />
                                </button>
                            </div>
                        </div>
                    )}

                    {/* STEP 3: AUDIENCE */}
                    {wizardStep === 'AUDIENCE' && (
                        <div className="space-y-6 flex-1">
                            <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-4 gap-4">
                                <div>
                                    <h3 className="text-xl font-bold text-slate-800">Bước 3: Chọn Khách Hàng Mục Tiêu</h3>
                                    <p className="text-sm text-slate-500 mt-1 flex items-center gap-2">
                                        <Filter size={14} /> 
                                        Sản phẩm chiến dịch: <span className="font-bold text-blue-600">{selectedCatName}</span>
                                    </p>
                                </div>
                                <div className="flex flex-col items-end gap-2">
                                     {/* Progress Bar for Email Limit */}
                                    <div className="flex flex-col items-end w-48">
                                        <div className="flex justify-between w-full text-xs mb-1">
                                            <span className={`font-medium ${selectedLeadsCount > MAX_DAILY_LIMIT ? 'text-red-600' : 'text-slate-600'}`}>
                                                Đã chọn: {selectedLeadsCount}/{MAX_DAILY_LIMIT}
                                            </span>
                                            <span className="text-slate-400">Giới hạn ngày</span>
                                        </div>
                                        <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
                                            <div 
                                                className={`h-full rounded-full transition-all duration-500 ${selectedLeadsCount >= MAX_DAILY_LIMIT ? 'bg-red-500' : 'bg-green-500'}`}
                                                style={{ width: `${Math.min((selectedLeadsCount / MAX_DAILY_LIMIT) * 100, 100)}%` }}
                                            />
                                        </div>
                                    </div>

                                    <div className="flex items-center gap-3 mt-1">
                                        <div className="flex items-center gap-2 bg-slate-100 px-3 py-1.5 rounded-lg border border-slate-200">
                                            <span className="text-xs font-medium text-slate-600">Bộ lọc thông minh:</span>
                                            <button 
                                                onClick={() => setFilterByInterest(!filterByInterest)}
                                                className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors focus:outline-none ${filterByInterest ? 'bg-blue-600' : 'bg-slate-300'}`}
                                            >
                                                <span className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white transition-transform ${filterByInterest ? 'translate-x-4.5' : 'translate-x-1'}`} />
                                            </button>
                                            <span className="text-xs text-slate-500">{filterByInterest ? "Chỉ hiện nhóm phù hợp" : "Hiện tất cả"}</span>
                                        </div>
                                        {selectedGroupIds.length > 0 && (
                                            <div className="text-sm font-bold text-blue-600 bg-blue-50 px-3 py-1.5 rounded-lg border border-blue-100">
                                                Đã chọn: {selectedGroupIds.length} nhóm
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                            
                            {displayedContactGroups.length === 0 ? (
                                <div className="text-center p-8 bg-orange-50 rounded-lg border border-orange-200 text-orange-700">
                                    <p className="mb-4">Không tìm thấy nhóm khách hàng nào.</p>
                                    <button 
                                        onClick={onNavigateToContacts}
                                        className="bg-white border border-orange-300 px-4 py-2 rounded-lg font-medium hover:bg-orange-100"
                                    >
                                        Đi tới quản lý danh bạ để thêm
                                    </button>
                                </div>
                            ) : (
                                <div className="space-y-4">
                                     <div className="grid grid-cols-1 gap-3 max-h-[300px] overflow-y-auto pr-1">
                                        {displayedContactGroups.map(group => {
                                            const isSelected = selectedGroupIds.includes(group.id);
                                            const isMatch = !group.catalogueId || group.catalogueId === selectedCatalogueId;
                                            const catName = catalogues.find(c => c.id === group.catalogueId)?.name || 'Chưa phân loại';
                                            
                                            // Check if adding this group would exceed limit (only if not already selected)
                                            const wouldExceedLimit = !isSelected && (selectedLeadsCount + group.leads.length > MAX_DAILY_LIMIT);

                                            return (
                                                <div 
                                                    key={group.id}
                                                    onClick={() => !wouldExceedLimit && toggleGroupSelection(group.id)}
                                                    className={`p-4 rounded-xl border transition-all flex justify-between items-center group relative ${
                                                        isSelected 
                                                        ? 'border-blue-500 bg-blue-50 ring-1 ring-blue-500 cursor-pointer' 
                                                        : wouldExceedLimit
                                                            ? 'border-slate-100 bg-slate-50 opacity-60 cursor-not-allowed'
                                                            : 'border-slate-200 hover:border-blue-300 bg-white cursor-pointer'
                                                    }`}
                                                >
                                                    <div className="flex items-center gap-3">
                                                        <div className={`text-blue-600 ${isSelected ? 'opacity-100' : 'opacity-40'}`}>
                                                            {isSelected ? <CheckSquare size={20} /> : <Square size={20} />}
                                                        </div>
                                                        <div>
                                                            <div className="flex items-center gap-2">
                                                                <h4 className="font-bold text-slate-800">{group.name}</h4>
                                                                {isMatch ? (
                                                                    <span className="text-[10px] bg-green-100 text-green-700 px-1.5 py-0.5 rounded border border-green-200 flex items-center gap-0.5">
                                                                        <ThumbsUp size={10} /> Phù hợp nhất
                                                                    </span>
                                                                ) : (
                                                                    <span className="text-[10px] bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded border border-slate-200 flex items-center gap-0.5">
                                                                        <AlertCircle size={10} /> Khác: {catName}
                                                                    </span>
                                                                )}
                                                            </div>
                                                            <p className="text-xs text-slate-500 mt-0.5">Ngày tạo: {new Date(group.createdAt).toLocaleDateString('vi-VN')}</p>
                                                        </div>
                                                    </div>
                                                    <div className="flex items-center gap-3">
                                                        {wouldExceedLimit && (
                                                            <span className="text-[10px] text-red-500 font-medium flex items-center gap-1">
                                                                <ShieldAlert size={12}/> Quá giới hạn
                                                            </span>
                                                        )}
                                                        <div className={`px-3 py-1 rounded-full border text-sm font-medium ${isSelected ? 'bg-white border-blue-200 text-blue-700' : 'bg-slate-50 border-slate-200 text-slate-700'}`}>
                                                            {group.leads.length} liên hệ
                                                        </div>
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                    
                                    {/* Selected Leads Preview & Quick Send */}
                                    {selectedGroupIds.length > 0 && (
                                        <div className="border-t border-slate-100 pt-4 mt-2">
                                            <h4 className="text-sm font-bold text-slate-700 mb-2">Danh sách tổng hợp ({selectedLeadsCount} khách):</h4>
                                            <div className="bg-slate-50 rounded-lg border border-slate-200 max-h-[200px] overflow-y-auto">
                                                <table className="w-full text-sm text-left">
                                                    <thead className="bg-slate-100 text-slate-500 sticky top-0">
                                                        <tr>
                                                            <th className="px-3 py-2">Công ty</th>
                                                            <th className="px-3 py-2">Nhóm</th>
                                                            <th className="px-3 py-2">Trạng thái</th>
                                                            <th className="px-3 py-2 text-right">Hành động</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody className="divide-y divide-slate-100">
                                                        {getSelectedLeads().map(lead => {
                                                             const groupName = contactGroups.find(g => g.leads.some(l => l.id === lead.id))?.name;
                                                             return (
                                                                <tr key={lead.id}>
                                                                    <td className="px-3 py-2 font-medium">{lead.companyName}</td>
                                                                    <td className="px-3 py-2 text-xs text-slate-500 truncate max-w-[120px]" title={groupName}>{groupName}</td>
                                                                    <td className="px-3 py-2">
                                                                        <span className={`px-2 py-0.5 rounded text-[10px] font-medium 
                                                                            ${lead.status === LeadStatus.NEW ? 'bg-slate-200 text-slate-600' : ''}
                                                                            ${lead.status === LeadStatus.SENDING ? 'bg-blue-100 text-blue-600' : ''}
                                                                            ${lead.status === LeadStatus.SENT ? 'bg-green-100 text-green-700' : ''}
                                                                            ${lead.status === LeadStatus.FAILED ? 'bg-red-100 text-red-600' : ''}
                                                                        `}>
                                                                            {lead.status}
                                                                        </span>
                                                                    </td>
                                                                    <td className="px-3 py-2 text-right">
                                                                        <div className="flex justify-end gap-2">
                                                                            <button
                                                                                onClick={(e) => { e.stopPropagation(); setViewingQuoteLead(lead); }}
                                                                                className="text-xs bg-white border border-slate-200 text-slate-600 px-2 py-1 rounded hover:bg-slate-50 flex items-center gap-1"
                                                                                title="Xem báo giá sơ bộ"
                                                                            >
                                                                                <FileText size={12} /> Báo giá
                                                                            </button>
                                                                            <button 
                                                                                onClick={(e) => { e.stopPropagation(); handleSingleSend(lead); }}
                                                                                disabled={lead.status === LeadStatus.SENDING || lead.status === LeadStatus.SENT}
                                                                                className="text-xs bg-white border border-blue-200 text-blue-600 px-2 py-1 rounded hover:bg-blue-50 disabled:opacity-50 disabled:bg-slate-50 disabled:text-slate-400 flex items-center gap-1"
                                                                            >
                                                                                {lead.status === LeadStatus.SENDING ? <Loader2 size={12} className="animate-spin" /> : <Send size={12} />}
                                                                                {lead.status === LeadStatus.SENDING ? 'Đang gửi...' : 'Gửi ngay'}
                                                                            </button>
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                            );
                                                        })}
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            )}

                            <div className="flex justify-between pt-6 mt-auto">
                                <button onClick={() => setWizardStep('CONTENT')} className="text-slate-500 hover:text-slate-800 px-4 py-2 font-medium">
                                    Quay lại
                                </button>
                                <button
                                    onClick={() => handleFinishCampaign(!!scheduleDate)}
                                    className={`px-8 py-3 rounded-lg font-bold text-white shadow-lg flex items-center gap-2 transition-transform active:scale-95 ${
                                        scheduleDate 
                                        ? 'bg-blue-600 hover:bg-blue-700' 
                                        : 'bg-green-600 hover:bg-green-700'
                                    }`}
                                >
                                    {scheduleDate ? (
                                        <> <Calendar size={20} /> Xác nhận Lên Lịch </>
                                    ) : (
                                        <> <Send size={20} /> Gửi Chiến Dịch Ngay </>
                                    )}
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        );
    };

    return (
        <div className="animate-fade-in space-y-6">
            {activeTab === 'HISTORY' && renderHistory()}
            {activeTab === 'EVENTS' && renderEventManager()}
            {activeTab === 'TEMPLATES' && renderTemplates()}
            {activeTab === 'CREATE_WIZARD' && renderWizard()}

            {renderTemplateDetailModal()}
            {renderDeleteTemplateModal()}
            {renderDeleteEventModal()}
            {renderQuoteModal()}
            {renderSuccessModal()}
        </div>
    );
};

export default CampaignManager;