import React, { useState } from 'react';
import { ActivityType, CatalogueItem, TrashItemType } from '../types';
import { Link2, Trash2, FolderPlus, FileText, ChevronDown, ChevronUp, AlertCircle, ArrowUpDown, Layers, Edit, ExternalLink, AlertTriangle, Save, X, Search, FileDown, Upload, Link as LinkIcon, CloudDownload, Loader2, LayoutGrid, List as ListIcon, FileSpreadsheet, Table, Wand2, Sparkles } from 'lucide-react';
import { generateCatalogueDescription } from '../services/geminiService';

interface CatalogueManagerProps {
  catalogues: CatalogueItem[];
  setCatalogues: React.Dispatch<React.SetStateAction<CatalogueItem[]>>;
  logActivity: (type: ActivityType, action: string, target: string, status?: 'SUCCESS' | 'WARNING' | 'ERROR') => void;
  onMoveToTrash: (item: any, type: TrashItemType, name: string) => void;
}

const CatalogueCard: React.FC<{ 
    cat: CatalogueItem; 
    onDeleteRequest: (cat: CatalogueItem) => void;
    onUpdateLink: (id: string, newLink: string) => void;
}> = ({ cat, onDeleteRequest, onUpdateLink }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isEditingLink, setIsEditingLink] = useState(false);
  const [tempLink, setTempLink] = useState(cat.link);
  
  const isLong = cat.description.length > 100;

  const handleDeleteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    onDeleteRequest(cat);
  };

  const handleSaveLink = () => {
    onUpdateLink(cat.id, tempLink);
    setIsEditingLink(false);
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 hover:shadow-md transition-shadow relative group flex flex-col h-full animate-fade-in">
        <button
            onClick={handleDeleteClick}
            className="absolute top-3 right-3 p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-full transition-all z-20 cursor-pointer"
            title="Xóa danh mục"
            type="button"
        >
            <Trash2 size={18} />
        </button>
      
      <div className="flex items-start justify-between mb-3 pr-8">
        <div className={`p-3 rounded-lg ${cat.link ? 'bg-blue-50 text-blue-600' : 'bg-orange-50 text-orange-600'}`}>
          {cat.link ? <Link2 size={24} /> : <AlertTriangle size={24} />}
        </div>
      </div>
      
      <h3 className="font-bold text-lg text-slate-800 mb-2">{cat.name}</h3>

      <div className="flex-1 mb-4">
        <div className="flex gap-2 items-start text-sm text-slate-500">
          <FileText size={16} className="mt-0.5 shrink-0" />
          <div className="flex-1">
             <p className={`whitespace-pre-wrap transition-all duration-200 ${!isExpanded ? 'line-clamp-3' : ''}`}>
               {cat.description}
             </p>
             {isLong && (
               <button 
                 onClick={() => setIsExpanded(!isExpanded)}
                 className="flex items-center gap-1 text-blue-600 text-xs font-medium mt-1 hover:underline focus:outline-none"
               >
                 {isExpanded ? (
                   <>Thu gọn <ChevronUp size={12} /></>
                 ) : (
                   <>Xem thêm <ChevronDown size={12} /></>
                 )}
               </button>
             )}
          </div>
        </div>
      </div>

      <div className="mt-auto pt-3 border-t border-slate-100">
        {isEditingLink || !cat.link ? (
            <div className="animate-fade-in">
                <label className="text-xs font-medium text-slate-500 mb-1 block">
                    {cat.link ? "Sửa đường dẫn:" : "Dán Link Catalogue vào đây:"}
                </label>
                <div className="flex gap-2">
                    <input 
                        type="text" 
                        value={tempLink}
                        onChange={(e) => setTempLink(e.target.value)}
                        placeholder="https://..."
                        className="flex-1 px-2 py-1.5 text-sm border border-blue-300 rounded focus:ring-1 focus:ring-blue-500 outline-none bg-white text-black"
                        autoFocus
                    />
                    <button 
                        onClick={handleSaveLink}
                        className="bg-blue-600 text-white p-1.5 rounded hover:bg-blue-700 shrink-0"
                        title="Lưu Link"
                    >
                        <Save size={16} />
                    </button>
                    {cat.link && (
                        <button 
                            onClick={() => { setIsEditingLink(false); setTempLink(cat.link); }}
                            className="bg-slate-200 text-slate-600 p-1.5 rounded hover:bg-slate-300 shrink-0"
                            title="Hủy"
                        >
                            <X size={16} />
                        </button>
                    )}
                </div>
            </div>
        ) : (
            <div className="flex gap-2">
                <a
                  href={cat.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 flex items-center justify-center gap-2 text-center bg-slate-50 hover:bg-slate-100 text-slate-700 py-2 rounded-lg text-sm font-medium transition-colors border border-slate-200"
                >
                  Kiểm tra Link <ExternalLink size={14}/>
                </a>
                <button
                    onClick={() => setIsEditingLink(true)}
                    className="px-3 py-2 bg-white border border-slate-200 text-slate-500 rounded-lg hover:bg-blue-50 hover:text-blue-600 hover:border-blue-200 transition-colors"
                    title="Sửa Link"
                >
                    <Edit size={16} />
                </button>
            </div>
        )}
      </div>
    </div>
  );
};

const CatalogueRow: React.FC<{ 
    cat: CatalogueItem; 
    onDeleteRequest: (cat: CatalogueItem) => void;
    onUpdateLink: (id: string, newLink: string) => void;
}> = ({ cat, onDeleteRequest, onUpdateLink }) => {
    const [isEditingLink, setIsEditingLink] = useState(false);
    const [tempLink, setTempLink] = useState(cat.link);

    const handleSaveLink = () => {
        onUpdateLink(cat.id, tempLink);
        setIsEditingLink(false);
    };

    return (
        <tr className="hover:bg-slate-50 transition-colors border-b border-slate-100 last:border-0 group">
            <td className="px-4 py-3 align-top">
                <div className="font-bold text-slate-800">{cat.name}</div>
            </td>
            <td className="px-4 py-3 align-top">
                {isEditingLink ? (
                    <div className="flex gap-2 items-center">
                        <input 
                            type="text" 
                            value={tempLink}
                            onChange={(e) => setTempLink(e.target.value)}
                            className="w-full max-w-xs px-2 py-1 text-sm border border-blue-300 rounded focus:ring-1 focus:ring-blue-500 outline-none bg-white text-black"
                            autoFocus
                        />
                         <button onClick={handleSaveLink} className="text-blue-600 hover:bg-blue-100 p-1 rounded"><Save size={16}/></button>
                         <button onClick={() => { setIsEditingLink(false); setTempLink(cat.link); }} className="text-slate-400 hover:bg-slate-100 p-1 rounded"><X size={16}/></button>
                    </div>
                ) : (
                    <div className="flex items-center gap-2 group/link">
                         {cat.link ? (
                            <a href={cat.link} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline text-sm truncate max-w-[200px] block" title={cat.link}>
                                {cat.link}
                            </a>
                        ) : (
                            <span className="text-orange-500 text-sm italic flex items-center gap-1"><AlertTriangle size={12}/> Chưa có link</span>
                        )}
                        <button 
                            onClick={() => setIsEditingLink(true)} 
                            className="opacity-0 group-hover/link:opacity-100 text-slate-400 hover:text-blue-600 transition-opacity"
                        >
                            <Edit size={14}/>
                        </button>
                    </div>
                )}
            </td>
            <td className="px-4 py-3 align-top">
                <p className="text-sm text-slate-600 line-clamp-2" title={cat.description}>{cat.description}</p>
            </td>
            <td className="px-4 py-3 align-top text-right">
                <button 
                    onClick={() => onDeleteRequest(cat)}
                    className="text-slate-300 hover:text-red-500 p-1 rounded hover:bg-red-50 transition-colors"
                >
                    <Trash2 size={18} />
                </button>
            </td>
        </tr>
    );
};

const CatalogueManager: React.FC<CatalogueManagerProps> = ({ catalogues, setCatalogues, logActivity, onMoveToTrash }) => {
  const [inputMode, setInputMode] = useState<'single' | 'bulk'>('single');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [newItem, setNewItem] = useState({ name: '', link: '', description: '' });
  const [bulkText, setBulkText] = useState('');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest' | 'az'>('newest');
  const [searchTerm, setSearchTerm] = useState('');
  const [driveLink, setDriveLink] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [isGeneratingDesc, setIsGeneratingDesc] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<CatalogueItem | null>(null);

  const isDuplicate = catalogues.some(
    c => c.name.toLowerCase() === newItem.name.trim().toLowerCase()
  );

  const handleAdd = () => {
    if (!newItem.name) return;
    if (isDuplicate) {
        alert("Tên danh mục này đã tồn tại.");
        return;
    }

    const item: CatalogueItem = {
      id: Date.now().toString(),
      name: newItem.name,
      link: newItem.link,
      description: newItem.description || 'Chưa có mô tả'
    };
    setCatalogues(prev => [...prev, item]);
    setNewItem({ name: '', link: '', description: '' });
    logActivity('CATALOGUE', 'Thêm mới danh mục', item.name, 'SUCCESS');
  };

  const handleAutoGenerateDesc = async () => {
      if (!newItem.name) {
          alert("Vui lòng nhập Tên Nhóm Hàng trước.");
          return;
      }
      setIsGeneratingDesc(true);
      try {
          const desc = await generateCatalogueDescription(newItem.name);
          setNewItem(prev => ({ ...prev, description: desc }));
      } catch (error) {
          console.error(error);
          alert("Lỗi khi tạo mô tả. Vui lòng thử lại.");
      } finally {
          setIsGeneratingDesc(false);
      }
  };

  const handleBulkAdd = () => {
    if (!bulkText.trim()) return;

    const lines = bulkText.split('\n');
    let addedCount = 0;
    let updatedCount = 0;

    setCatalogues(prevCatalogues => {
        const updatedCatalogues = [...prevCatalogues];

        lines.forEach((line, index) => {
            if (!line.trim()) return;
            const parts = line.split('|').map(p => p.trim());
            const name = parts[0];
            
            if (!name) return;

            const link = parts[1] || ''; 
            const description = parts[2] || '';

            const existingIndex = updatedCatalogues.findIndex(c => c.name.toLowerCase() === name.toLowerCase());

            if (existingIndex !== -1) {
                let hasChange = false;
                if (link) {
                    updatedCatalogues[existingIndex] = { ...updatedCatalogues[existingIndex], link: link };
                    hasChange = true;
                }
                if (description) {
                    updatedCatalogues[existingIndex] = { ...updatedCatalogues[existingIndex], description: description };
                    hasChange = true;
                }
                if (hasChange) updatedCount++;
            } else {
                const uniqueId = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}-${index}`;
                updatedCatalogues.push({
                    id: uniqueId,
                    name: name,
                    link: link, 
                    description: description || 'Chưa có mô tả'
                });
                addedCount++;
            }
        });
        
        setTimeout(() => {
            alert(`Xử lý hoàn tất!\n- Thêm mới: ${addedCount} danh mục.\n- Cập nhật thông tin: ${updatedCount} danh mục cũ.`);
        }, 100);

        return updatedCatalogues;
    });
    
    logActivity('CATALOGUE', 'Nhập hàng loạt', `Thêm ${addedCount}, Sửa ${updatedCount}`, 'SUCCESS');
    setBulkText('');
  };

  // Helper to ensure CSV fields are properly quoted
  const escapeCsv = (str: string) => {
      if (!str) return '';
      // If string contains comma, quote, or newline, wrap in quotes and escape internal quotes
      if (str.includes(',') || str.includes('"') || str.includes('\n')) {
          return `"${str.replace(/"/g, '""')}"`;
      }
      return str;
  };

  const handleDownloadTemplate = () => {
    const bom = "\uFEFF";
    const headers = "Tên Danh Mục,Link Catalogue,Mô Tả Chi Tiết";
    // Using proper CSV quoting
    const exampleRow1 = `${escapeCsv("Máy Hàn Inox")},${escapeCsv("https://drive.google.com/example1")},${escapeCsv("Chuyên hàn Tig, Mig công nghiệp")}`;
    const exampleRow2 = `${escapeCsv("Máy Cắt Plasma")},${escapeCsv("https://website.com/catalogue2")},${escapeCsv("Dòng máy cắt cnc, độ chính xác cao")}`;
    
    const csvContent = `${bom}${headers}\n${exampleRow1}\n${exampleRow2}`;
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", "mau_nhap_catalogue_chuan.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // 1. Export Excel (CSV with BOM for Unicode support)
  const handleExportExcel = () => {
      if (sortedCatalogues.length === 0) return;
      const bom = "\uFEFF"; // Byte Order Mark for Excel
      const headers = "ID,Tên Danh Mục,Link Catalogue,Mô Tả";
      const rows = sortedCatalogues.map(c => 
          `${escapeCsv(c.id)},${escapeCsv(c.name)},${escapeCsv(c.link)},${escapeCsv(c.description)}`
      ).join("\n");
      const csvContent = `${bom}${headers}\n${rows}`;
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `catalogue_excel_${new Date().toLocaleDateString('vi-VN').replace(/\//g,'-')}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
  };

  // 2. Export Standard CSV (No BOM, standard format)
  const handleExportStandardCSV = () => {
      if (sortedCatalogues.length === 0) return;
      // No BOM
      const headers = "ID,Tên Danh Mục,Link Catalogue,Mô Tả";
      const rows = sortedCatalogues.map(c => 
          `${escapeCsv(c.id)},${escapeCsv(c.name)},${escapeCsv(c.link)},${escapeCsv(c.description)}`
      ).join("\n");
      const csvContent = `${headers}\n${rows}`;
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `catalogue_standard_${new Date().toLocaleDateString('vi-VN').replace(/\//g,'-')}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
  };

  // 3. Export Text (Pipe separated)
  const handleExportTXT = () => {
      if (sortedCatalogues.length === 0) return;
      const content = sortedCatalogues.map(c => 
          `${c.name} | ${c.link} | ${c.description}`
      ).join("\n");
      const blob = new Blob([content], { type: "text/plain;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `catalogue_text_${new Date().toLocaleDateString('vi-VN').replace(/\//g,'-')}.txt`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
        const content = e.target?.result as string;
        if (!content) return;

        const lines = content.split(/\r\n|\n/);
        const processedLines: string[] = [];
        
        // Regex to split by comma ONLY if not inside quotes
        // This handles "Name, Inc", "Desc with, comma" correctly
        const csvSplitRegex = /,(?=(?:(?:[^"]*"){2})*[^"]*$)/;

        lines.forEach((line, idx) => {
            if (!line.trim() || idx === 0) return; // Skip header
            
            // Handle both CSV (comma) and potentially semicolon delimited
            let delimiterRegex = csvSplitRegex;
            if (line.includes(';') && !line.includes(',')) {
                delimiterRegex = /;(?=(?:(?:[^"]*"){2})*[^"]*$)/;
            }

            const parts = line.split(delimiterRegex).map(p => {
                // Remove surrounding quotes and unescape double quotes
                return p.trim().replace(/^["']|["']$/g, '').replace(/""/g, '"');
            });

            const name = parts[0];
            const link = parts[1] || '';
            const desc = parts[2] || '';

            if (name) {
                // Convert back to pipe format for the textarea display
                processedLines.push(`${name} | ${link} | ${desc}`);
            }
        });

        if (processedLines.length > 0) {
            const newText = processedLines.join('\n');
            setBulkText(prev => prev ? prev + '\n' + newText : newText);
            alert(`Đã đọc ${processedLines.length} dòng từ file Excel/CSV. Vui lòng kiểm tra và bấm "Lưu & Xử lý".`);
        } else {
            alert("File không có dữ liệu hợp lệ.");
        }
        event.target.value = ''; // Reset input
    };
    reader.readAsText(file);
  };

  const handleScanDrive = () => {
      if (!driveLink) return;
      setIsScanning(true);
      setTimeout(() => {
          setIsScanning(false);
          setBulkText(prev => prev + '\nMáy Cắt Sắt Thủy Lực | https://drive.google.com/demo1 | Dòng máy mới về\nMáy Uốn Ống | https://drive.google.com/demo2 | Hàng nội địa Trung');
          setDriveLink('');
          alert("Đã quét thấy 2 danh mục từ link Drive. Dữ liệu đã được thêm vào khung nhập liệu.");
      }, 1500);
  };

  const confirmDelete = () => {
    if (!itemToDelete) return;
    onMoveToTrash(itemToDelete, 'CATALOGUE', itemToDelete.name);
    setItemToDelete(null);
  };

  const handleUpdateLink = (id: string, newLink: string) => {
      setCatalogues(prev => prev.map(cat => 
        cat.id === id ? { ...cat, link: newLink } : cat
      ));
      const target = catalogues.find(c => c.id === id)?.name || 'Unknown';
      logActivity('CATALOGUE', 'Cập nhật Link', target, 'SUCCESS');
  };

  const sortedCatalogues = [...catalogues]
    .filter(cat => {
        const term = searchTerm.toLowerCase();
        return cat.name.toLowerCase().includes(term) || cat.description.toLowerCase().includes(term);
    })
    .sort((a, b) => {
        if (sortOrder === 'newest') return Number(b.id.split('-')[0]) - Number(a.id.split('-')[0]); // Handle potentially composite IDs
        if (sortOrder === 'oldest') return Number(a.id.split('-')[0]) - Number(b.id.split('-')[0]);
        if (sortOrder === 'az') return a.name.localeCompare(b.name);
        return 0;
    });

  return (
    <div className="space-y-6">
      {/* Custom Delete Modal */}
      {itemToDelete && (
          <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4 animate-fade-in">
              <div className="bg-white rounded-xl shadow-xl w-full max-w-sm p-6">
                  <div className="flex flex-col items-center text-center mb-6">
                      <div className="w-12 h-12 bg-red-100 text-red-500 rounded-full flex items-center justify-center mb-4">
                          <AlertTriangle size={28} />
                      </div>
                      <h3 className="text-lg font-bold text-slate-800">Xóa Danh Mục?</h3>
                      <p className="text-sm text-slate-500 mt-2">
                          Bạn có chắc muốn xóa <strong>"{itemToDelete.name}"</strong> không? <br/>
                          Dữ liệu sẽ được lưu vào thùng rác 30 ngày.
                      </p>
                  </div>
                  <div className="flex gap-3">
                      <button 
                          onClick={() => setItemToDelete(null)}
                          className="flex-1 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg transition-colors"
                      >
                          Hủy bỏ
                      </button>
                      <button 
                          onClick={confirmDelete}
                          className="flex-1 px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-medium rounded-lg transition-colors"
                      >
                          Xóa & Backup
                      </button>
                  </div>
              </div>
          </div>
      )}

      <div className="bg-blue-50 border border-blue-100 p-4 rounded-lg text-blue-800 text-sm flex items-start gap-2">
        <AlertCircle size={18} className="mt-0.5 shrink-0"/>
        <div>
            <strong>Mẹo quản lý Link:</strong><br/>
            - Bạn có thể tạo tên danh mục trước, sau đó bấm vào nút chỉnh sửa (hoặc ô nhập link) trên từng thẻ để dán link sau.<br/>
            - Hoặc dùng chức năng nhập hàng loạt để tải file Excel/CSV chứa danh sách sản phẩm.
        </div>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
        <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-bold text-slate-800">Thêm Danh Mục Mới</h2>
            <div className="flex bg-slate-100 p-1 rounded-lg">
                <button 
                    onClick={() => setInputMode('single')}
                    className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all flex items-center gap-2 ${inputMode === 'single' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                    <Edit size={14} /> Thủ công
                </button>
                <button 
                    onClick={() => setInputMode('bulk')}
                    className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all flex items-center gap-2 ${inputMode === 'bulk' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                    <Layers size={14} /> Nhập hàng loạt
                </button>
            </div>
        </div>
        
        {inputMode === 'single' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
                <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Tên Nhóm Hàng <span className="text-red-500">*</span></label>
                <input
                    type="text"
                    className={`w-full px-3 py-2 border rounded-lg focus:ring-2 outline-none bg-white text-black ${
                        isDuplicate && newItem.name 
                        ? 'border-red-300 focus:ring-red-500' 
                        : 'border-slate-300 focus:ring-blue-500'
                    }`}
                    placeholder="VD: Máy hàn"
                    value={newItem.name}
                    onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
                />
                {isDuplicate && newItem.name && (
                    <div className="flex items-center gap-1 text-red-500 text-xs mt-1">
                        <AlertCircle size={12} />
                        <span>Tên danh mục này đã tồn tại</span>
                    </div>
                )}
                </div>
                <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Link Drive/Website</label>
                <input
                    type="url"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-white text-black"
                    placeholder="https://drive.google.com/..."
                    value={newItem.link}
                    onChange={(e) => setNewItem({ ...newItem, link: e.target.value })}
                />
                </div>
            </div>
            <div className="flex flex-col">
                <label className="flex justify-between items-center text-sm font-medium text-slate-700 mb-1">
                    <span>Mô tả chi tiết</span>
                    <button 
                        onClick={handleAutoGenerateDesc}
                        className="text-purple-600 hover:text-purple-700 text-xs flex items-center gap-1 hover:bg-purple-50 px-2 py-0.5 rounded transition-colors"
                        title="Tự động viết mô tả dựa trên Tên Nhóm Hàng"
                        disabled={isGeneratingDesc}
                    >
                        {isGeneratingDesc ? <Loader2 size={12} className="animate-spin"/> : <Wand2 size={12} />}
                        {isGeneratingDesc ? 'Đang viết...' : 'Dùng AI viết mô tả'}
                    </button>
                </label>
                <textarea
                    className="w-full flex-1 px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none resize-none bg-white text-black"
                    placeholder="Mô tả về dòng sản phẩm này (VD: Bao gồm các loại máy Mig/Tig...)"
                    value={newItem.description}
                    onChange={(e) => setNewItem({ ...newItem, description: e.target.value })}
                    rows={4}
                />
                <div className="mt-4 flex justify-end">
                <button
                    onClick={handleAdd}
                    disabled={!!(isDuplicate && newItem.name) || !newItem.name}
                    className={`flex items-center gap-2 px-6 py-2 rounded-lg font-medium transition-colors ${
                        !!(isDuplicate && newItem.name) || !newItem.name
                        ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                        : 'bg-blue-600 hover:bg-blue-700 text-white'
                    }`}
                >
                    <FolderPlus size={18} /> Lưu Danh Mục
                </button>
                </div>
            </div>
            </div>
        ) : (
            <div className="space-y-4 animate-fade-in">
                <div className="flex flex-col md:flex-row gap-4 mb-4">
                    {/* File Upload Section */}
                    <div className="flex-1 space-y-2">
                        <div className="flex justify-between items-center">
                            <label className="text-sm font-medium text-slate-700">1. Tải lên file Excel/CSV</label>
                            <button onClick={handleDownloadTemplate} className="text-blue-600 text-xs flex items-center gap-1 hover:underline">
                                <FileDown size={12}/> Tải file mẫu chuẩn
                            </button>
                        </div>
                        <label className="flex flex-col items-center justify-center w-full h-24 border-2 border-slate-300 border-dashed rounded-lg cursor-pointer bg-slate-50 hover:bg-blue-50 hover:border-blue-400 transition-colors">
                            <div className="flex flex-col items-center justify-center pt-5 pb-6">
                                <Upload size={24} className="text-slate-400 mb-2"/>
                                <p className="text-xs text-slate-500">Click để chọn file CSV</p>
                            </div>
                            <input type="file" className="hidden" accept=".csv, .txt" onChange={handleFileUpload} />
                        </label>
                    </div>

                    {/* Google Drive Link Section */}
                    <div className="flex-1 space-y-2">
                        <label className="text-sm font-medium text-slate-700">2. Hoặc nhập Link Google Sheet</label>
                        <div className="flex gap-2 h-10 mt-1">
                            <div className="relative flex-1">
                                <input 
                                    type="text" 
                                    className="w-full pl-8 pr-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none h-full bg-white text-black"
                                    placeholder="https://docs.google.com/spreadsheets/..."
                                    value={driveLink}
                                    onChange={(e) => setDriveLink(e.target.value)}
                                />
                                <LinkIcon size={14} className="absolute left-2.5 top-3 text-slate-400" />
                            </div>
                            <button 
                                onClick={handleScanDrive}
                                disabled={!driveLink || isScanning}
                                className="bg-green-600 hover:bg-green-700 text-white px-3 rounded-lg flex items-center justify-center disabled:bg-slate-300 h-full"
                            >
                                {isScanning ? <Loader2 size={18} className="animate-spin" /> : <CloudDownload size={18} />}
                            </button>
                        </div>
                        <p className="text-[10px] text-slate-400 italic">Hệ thống sẽ tự động quét cột Tên và Link trong sheet.</p>
                    </div>
                </div>

                <div className="bg-white p-3 rounded-lg border border-slate-200 text-sm text-slate-600">
                    <p className="font-bold mb-1">Kiểm tra dữ liệu:</p>
                    <ul className="list-disc pl-5 space-y-1 text-xs">
                        <li>Hệ thống hỗ trợ file CSV tiêu chuẩn (ngăn cách bằng dấu phẩy).</li>
                        <li>Dữ liệu tải lên sẽ được chuyển đổi sang dạng text bên dưới để bạn dễ dàng sửa đổi trước khi lưu.</li>
                    </ul>
                </div>

                <textarea
                    className="w-full h-40 px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none font-mono text-sm bg-white text-black"
                    placeholder={`Máy cắt sắt\nMáy hàn Tig | https://drive.google.com/...\nBulong ốc vít | https://website.com | Đủ kích thước`}
                    value={bulkText}
                    onChange={(e) => setBulkText(e.target.value)}
                />
                <div className="flex justify-end">
                    <button
                        onClick={handleBulkAdd}
                        disabled={!bulkText.trim()}
                        className="flex items-center gap-2 px-6 py-2 rounded-lg font-medium bg-blue-600 hover:bg-blue-700 text-white disabled:bg-slate-300"
                    >
                        <Layers size={18} /> Lưu & Xử Lý
                    </button>
                </div>
            </div>
        )}
      </div>

      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div className="flex items-center gap-3">
            <h3 className="text-lg font-bold text-slate-800">Danh Sách ({sortedCatalogues.length})</h3>
            
            <div className="bg-white border border-slate-200 rounded-lg flex p-0.5">
                <button 
                    onClick={() => setViewMode('grid')}
                    className={`p-1.5 rounded transition-colors ${viewMode === 'grid' ? 'bg-slate-100 text-blue-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                    title="Dạng lưới"
                >
                    <LayoutGrid size={16} />
                </button>
                <button 
                    onClick={() => setViewMode('list')}
                    className={`p-1.5 rounded transition-colors ${viewMode === 'list' ? 'bg-slate-100 text-blue-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                    title="Dạng danh sách"
                >
                    <ListIcon size={16} />
                </button>
            </div>
        </div>
        
        <div className="flex flex-col md:flex-row gap-3 w-full lg:w-auto">
            <div className="flex gap-2">
                <button
                    onClick={handleExportExcel}
                    className="flex items-center gap-1 px-3 py-2 bg-white border border-green-200 text-green-700 hover:bg-green-50 rounded-lg text-sm font-medium transition-colors"
                    title="Xuất Excel (có dấu tiếng Việt)"
                >
                    <FileSpreadsheet size={16} /> <span className="hidden sm:inline">Excel</span>
                </button>
                 <button
                    onClick={handleExportStandardCSV}
                    className="flex items-center gap-1 px-3 py-2 bg-white border border-blue-200 text-blue-700 hover:bg-blue-50 rounded-lg text-sm font-medium transition-colors"
                    title="Xuất CSV chuẩn (Không BOM)"
                >
                    <Table size={16} /> <span className="hidden sm:inline">CSV</span>
                </button>
                <button
                    onClick={handleExportTXT}
                    className="flex items-center gap-1 px-3 py-2 bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 rounded-lg text-sm font-medium transition-colors"
                    title="Xuất ra file Text"
                >
                    <FileText size={16} /> <span className="hidden sm:inline">Text</span>
                </button>
            </div>

            <div className="relative flex-1 md:w-64">
                <Search className="absolute left-3 top-2.5 text-slate-400" size={16} />
                <input 
                    type="text" 
                    placeholder="Tìm theo tên, mô tả..." 
                    className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-white text-black"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>

            <div className="flex items-center gap-2 bg-white px-3 py-2 border border-slate-200 rounded-lg">
                <ArrowUpDown size={16} className="text-slate-400" />
                <span className="text-sm text-slate-500 hidden sm:inline">Sắp xếp:</span>
                <select 
                    className="text-sm bg-transparent outline-none font-medium text-black cursor-pointer"
                    value={sortOrder}
                    onChange={(e) => setSortOrder(e.target.value as any)}
                >
                    <option value="newest">Mới nhất</option>
                    <option value="oldest">Cũ nhất</option>
                    <option value="az">Tên (A-Z)</option>
                </select>
            </div>
        </div>
      </div>

      {sortedCatalogues.length === 0 ? (
             <div className="py-12 text-center text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-300">
                <Search size={32} className="mx-auto mb-2 opacity-20" />
                <p>Không tìm thấy danh mục nào phù hợp.</p>
             </div>
      ) : (
          <>
            {viewMode === 'grid' ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-in">
                    {sortedCatalogues.map((cat) => (
                    <CatalogueCard 
                        key={cat.id} 
                        cat={cat} 
                        onDeleteRequest={setItemToDelete}
                        onUpdateLink={handleUpdateLink}
                    />
                    ))}
                </div>
            ) : (
                <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden animate-fade-in">
                    <table className="w-full text-left text-sm">
                        <thead className="bg-slate-50 text-slate-600 font-medium border-b border-slate-200">
                            <tr>
                                <th className="px-4 py-3">Tên Danh Mục</th>
                                <th className="px-4 py-3 w-1/3">Link Catalogue</th>
                                <th className="px-4 py-3">Mô Tả</th>
                                <th className="px-4 py-3 text-right"></th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {sortedCatalogues.map((cat) => (
                                <CatalogueRow
                                    key={cat.id}
                                    cat={cat}
                                    onDeleteRequest={setItemToDelete}
                                    onUpdateLink={handleUpdateLink}
                                />
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
          </>
      )}
    </div>
  );
};

export default CatalogueManager;