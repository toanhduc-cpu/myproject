import React, { useState } from 'react';
import { ContactGroup, Lead, LeadStatus, CatalogueItem, ActivityType, TrashItemType } from '../types';
import { Upload, Trash2, FileDown, Save, UserCheck, Users, AlertCircle, Tag, Link as LinkIcon, CloudDownload, Loader2, X, Eye, AlertTriangle, Plus, Keyboard, FileUp, FileSpreadsheet, FileText } from 'lucide-react';

interface ContactManagerProps {
  contactGroups: ContactGroup[];
  setContactGroups: React.Dispatch<React.SetStateAction<ContactGroup[]>>;
  catalogues: CatalogueItem[];
  logActivity: (type: ActivityType, action: string, target: string, status?: 'SUCCESS' | 'WARNING' | 'ERROR') => void;
  onMoveToTrash: (item: any, type: TrashItemType, name: string) => void;
}

const ContactManager: React.FC<ContactManagerProps> = ({ contactGroups, setContactGroups, catalogues, logActivity, onMoveToTrash }) => {
  const [newGroupName, setNewGroupName] = useState('');
  const [selectedCatalogueId, setSelectedCatalogueId] = useState('');
  
  // Input Method State
  const [inputMethod, setInputMethod] = useState<'import' | 'manual'>('import');

  // Import State
  const [tempLeads, setTempLeads] = useState<Lead[]>([]);
  const [uploadError, setUploadError] = useState('');
  const [driveLink, setDriveLink] = useState('');
  const [isScanningDrive, setIsScanningDrive] = useState(false);

  // Manual Entry State
  const [manualLeads, setManualLeads] = useState<{name: string, email: string, product: string}[]>([
      { name: '', email: '', product: '' }
  ]);

  // Modal State
  const [viewingGroup, setViewingGroup] = useState<ContactGroup | null>(null);
  const [deleteGroupId, setDeleteGroupId] = useState<string | null>(null);

  // Helper to ensure CSV fields are properly quoted
  const escapeCsv = (str: string) => {
      if (!str) return '';
      if (str.includes(',') || str.includes('"') || str.includes('\n')) {
          return `"${str.replace(/"/g, '""')}"`;
      }
      return str;
  };

  const handleDownloadTemplate = () => {
    const bom = "\uFEFF";
    const headers = "Tên Công Ty/Người nhận,Email,Nhóm Hàng/Sản Phẩm";
    const exampleRow1 = `${escapeCsv("Công ty Xây Dựng ABC")},${escapeCsv("lienhe@xaydungabc.com")},${escapeCsv("Máy hàn")}`;
    const exampleRow2 = `${escapeCsv("Anh Nam, Xưởng Cơ Khí")},${escapeCsv("nam.ck@gmail.com")},${escapeCsv("Dụng cụ cầm tay")}`;
    
    const csvContent = `${bom}${headers}\n${exampleRow1}\n${exampleRow2}`;
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", "mau_nhap_lieu_chuan.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportAllCSV = () => {
    if (contactGroups.length === 0) {
        alert("Chưa có dữ liệu để xuất.");
        return;
    }

    const bom = "\uFEFF";
    const headers = "ID Nhóm,Tên Nhóm,Tên Công Ty,Email,Sản Phẩm Quan Tâm,Trạng Thái,Ngày Tạo";
    
    // Flatten all leads from all groups
    const rows: string[] = [];
    contactGroups.forEach(group => {
        group.leads.forEach(lead => {
            rows.push([
                escapeCsv(group.id),
                escapeCsv(group.name),
                escapeCsv(lead.companyName),
                escapeCsv(lead.email),
                escapeCsv(lead.productInterest),
                escapeCsv(lead.status),
                escapeCsv(new Date(lead.createdAt).toLocaleDateString('vi-VN'))
            ].join(','));
        });
    });

    const csvContent = `${bom}${headers}\n${rows.join('\n')}`;
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `TONG_HOP_DANH_BA_${new Date().toLocaleDateString('vi-VN').replace(/\//g,'-')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportAllTXT = () => {
      if (contactGroups.length === 0) return;
      
      let content = `DANH SÁCH KHÁCH HÀNG - ĐIỆN MÁY LỘC ĐỨC\nXuất ngày: ${new Date().toLocaleString('vi-VN')}\n============================================\n\n`;

      contactGroups.forEach(group => {
          content += `NHÓM: ${group.name.toUpperCase()} (${group.leads.length} khách)\n`;
          content += `--------------------------------------------\n`;
          group.leads.forEach((lead, idx) => {
              content += `${idx + 1}. ${lead.companyName} | ${lead.email} | ${lead.productInterest}\n`;
          });
          content += `\n`;
      });

      const blob = new Blob([content], { type: "text/plain;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `DANH_BA_TEXT_${new Date().toLocaleDateString('vi-VN').replace(/\//g,'-')}.txt`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploadError('');
    setDriveLink(''); // Clear link input if uploading file
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        if (!content) return;

        const lines = content.split(/\r\n|\n/);
        const newLeadsData: Lead[] = [];
        
        // Regex to handle CSV lines respecting quotes
        // Matches quoted fields OR non-quoted fields followed by delimiter or end of line
        const csvSplitRegex = /,(?=(?:(?:[^"]*"){2})*[^"]*$)/;

        lines.forEach((line, index) => {
          if (!line.trim()) return;
          
          let delimiterRegex = csvSplitRegex;
          if (line.includes(';') && !line.includes(',')) {
               delimiterRegex = /;(?=(?:(?:[^"]*"){2})*[^"]*$)/;
          }

          const parts = line.split(delimiterRegex).map(item => {
              // Unquote and unescape double quotes
              return item.trim().replace(/^["']|["']$/g, '').replace(/""/g, '"');
          });

          const companyName = parts[0];
          const email = parts[1];
          const productInterest = parts[2];

          // Skip header
          if (index === 0 && (email?.toLowerCase().includes('email') || companyName?.toLowerCase().includes('tên'))) return;

          if (companyName && email && email.includes('@')) {
            newLeadsData.push({
              id: Math.random().toString(36).substr(2, 9),
              companyName,
              email,
              productInterest: productInterest || 'Chung',
              status: LeadStatus.NEW,
              createdAt: Date.now()
            });
          }
        });

        if (newLeadsData.length === 0) {
            setUploadError("File không có dữ liệu hợp lệ hoặc sai định dạng.");
        } else {
            setTempLeads(newLeadsData);
            // Auto suggest name if empty
            if (!newGroupName) {
                setNewGroupName(`Nhóm tải lên ngày ${new Date().toLocaleDateString('vi-VN')}`);
            }
        }
      } catch (err) {
          setUploadError("Lỗi khi đọc file. Vui lòng thử lại.");
      }
      event.target.value = ''; // Reset input
    };
    reader.readAsText(file);
  };

  const handleScanDrive = () => {
      if (!driveLink) return;
      if (!driveLink.includes('google.com') && !driveLink.includes('docs')) {
          setUploadError("Link không hợp lệ. Vui lòng nhập link Google Sheet hoặc Google Drive.");
          return;
      }

      setUploadError('');
      setIsScanningDrive(true);

      // Simulate API Call to Google Sheets
      setTimeout(() => {
          setIsScanningDrive(false);
          // Mock data returned from "Drive"
          const mockDriveData: Lead[] = [
              { id: 'd1', companyName: 'Công ty Cơ Khí An Phú', email: 'anphu.mech@gmail.com', productInterest: 'Máy hàn Mig', status: LeadStatus.NEW, createdAt: Date.now() },
              { id: 'd2', companyName: 'Xưởng Sắt Mỹ Thuật Việt', email: 'satmythuat@gmail.com', productInterest: 'Que hàn inox', status: LeadStatus.NEW, createdAt: Date.now() },
              { id: 'd3', companyName: 'Tổng thầu Xây Dựng Delta', email: 'procurement@delta.vn', productInterest: 'Dụng cụ cầm tay', status: LeadStatus.NEW, createdAt: Date.now() },
              { id: 'd4', companyName: 'Điện Lạnh Toàn Cầu', email: 'info@toancau-re.com', productInterest: 'Máy khoan pin', status: LeadStatus.NEW, createdAt: Date.now() },
          ];
          setTempLeads(mockDriveData);
          if (!newGroupName) {
              setNewGroupName(`Data Drive - ${new Date().toLocaleDateString('vi-VN')}`);
          }
      }, 2000);
  };

  // Manual Entry Handlers
  const handleAddManualRow = () => {
      setManualLeads([...manualLeads, { name: '', email: '', product: '' }]);
  };

  const handleRemoveManualRow = (index: number) => {
      if (manualLeads.length > 1) {
          const newLeads = [...manualLeads];
          newLeads.splice(index, 1);
          setManualLeads(newLeads);
      }
  };

  const handleManualChange = (index: number, field: 'name' | 'email' | 'product', value: string) => {
      const newLeads = [...manualLeads];
      newLeads[index][field] = value;
      setManualLeads(newLeads);

      // Auto-set global category based on first row input to help validation
      if (field === 'product' && value && !selectedCatalogueId) {
          const cat = catalogues.find(c => c.name === value);
          if (cat) setSelectedCatalogueId(cat.id);
      }
  };

  const handleSaveGroup = () => {
    let finalLeads: Lead[] = [];

    if (inputMethod === 'import') {
        finalLeads = tempLeads;
    } else {
        // Process Manual Data
        finalLeads = manualLeads
            .filter(l => l.name && l.email && l.email.includes('@'))
            .map(l => ({
                id: Math.random().toString(36).substr(2, 9),
                companyName: l.name,
                email: l.email,
                productInterest: l.product || 'Chung',
                status: LeadStatus.NEW,
                createdAt: Date.now()
            }));
    }

    // Determine Final Catalogue ID
    let finalCatalogueId = selectedCatalogueId;
    // If Manual mode and no global catalogue selected, try to infer from data
    if (inputMethod === 'manual' && !finalCatalogueId) {
        const leadWithProduct = manualLeads.find(l => l.product && catalogues.some(c => c.name === l.product));
        if (leadWithProduct) {
             const cat = catalogues.find(c => c.name === leadWithProduct.product);
             if (cat) finalCatalogueId = cat.id;
        }
    }

    if (!newGroupName || finalLeads.length === 0 || !finalCatalogueId) {
        if (!finalCatalogueId && inputMethod === 'manual') {
             alert("Vui lòng chọn danh mục sản phẩm ở phía trên hoặc chọn nhóm hàng cho từng khách trong bảng.");
        }
        return;
    }
    
    const newGroup: ContactGroup = {
      id: Date.now().toString(),
      name: newGroupName,
      catalogueId: finalCatalogueId,
      leads: finalLeads,
      createdAt: Date.now()
    };
    
    setContactGroups([...contactGroups, newGroup]);
    logActivity('CONTACT', 'Thêm mới danh bạ', `${newGroupName} (${finalLeads.length} khách)`, 'SUCCESS');
    
    // Reset Form
    setTempLeads([]);
    setManualLeads([{ name: '', email: '', product: '' }]);
    setNewGroupName('');
    setSelectedCatalogueId('');
    setDriveLink('');
    setUploadError('');
    alert("Đã lưu danh bạ thành công!");
  };

  const confirmDeleteGroup = () => {
    if (deleteGroupId) {
        const groupToDelete = contactGroups.find(g => g.id === deleteGroupId);
        if (groupToDelete) {
            onMoveToTrash(groupToDelete, 'CONTACT_GROUP', groupToDelete.name);
            
            if (viewingGroup?.id === deleteGroupId) setViewingGroup(null);
            setDeleteGroupId(null);
        }
    }
  };

  // Helper validation for saving
  const isValidToSave = () => {
      if (!newGroupName) return false;
      
      if (inputMethod === 'import') {
          return tempLeads.length > 0 && !!selectedCatalogueId;
      }
      
      if (inputMethod === 'manual') {
          const hasValidRows = manualLeads.some(l => l.name && l.email && l.email.includes('@'));
          // In manual mode, allow if global ID is set OR if we can infer it from rows
          const canInferCatalogue = manualLeads.some(l => l.product && catalogues.some(c => c.name === l.product));
          return hasValidRows && (!!selectedCatalogueId || canInferCatalogue);
      }
      return false;
  };

  return (
    <div className="space-y-6">
      {/* Delete Confirmation Modal */}
      {deleteGroupId && (
          <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4 animate-fade-in">
              <div className="bg-white rounded-xl shadow-xl w-full max-w-sm p-6">
                  <div className="flex flex-col items-center text-center mb-6">
                      <div className="w-12 h-12 bg-red-100 text-red-500 rounded-full flex items-center justify-center mb-4">
                          <AlertTriangle size={28} />
                      </div>
                      <h3 className="text-lg font-bold text-slate-800">Xóa Nhóm Khách Hàng?</h3>
                      <p className="text-sm text-slate-500 mt-2">
                          Bạn có chắc chắn muốn xóa nhóm này không? Dữ liệu sẽ được lưu vào thùng rác 30 ngày.
                      </p>
                  </div>
                  <div className="flex gap-3">
                      <button 
                          onClick={() => setDeleteGroupId(null)}
                          className="flex-1 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg transition-colors"
                      >
                          Hủy bỏ
                      </button>
                      <button 
                          onClick={confirmDeleteGroup}
                          className="flex-1 px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-medium rounded-lg transition-colors"
                      >
                          Xóa & Backup
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* View Detail Modal */}
      {viewingGroup && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-xl w-full max-w-4xl max-h-[80vh] flex flex-col">
                <div className="p-6 border-b border-slate-100 flex justify-between items-center">
                    <div>
                        <h3 className="text-xl font-bold text-slate-800">{viewingGroup.name}</h3>
                        <p className="text-sm text-slate-500">
                            Danh mục: {catalogues.find(c => c.id === viewingGroup.catalogueId)?.name} | {viewingGroup.leads.length} liên hệ
                        </p>
                    </div>
                    <button onClick={() => setViewingGroup(null)} className="p-2 hover:bg-slate-100 rounded-full text-slate-500">
                        <X size={24} />
                    </button>
                </div>
                <div className="flex-1 overflow-y-auto p-6 bg-slate-50">
                    <div className="bg-white rounded-lg border border-slate-200 overflow-hidden shadow-sm">
                        <table className="w-full text-sm text-left">
                            <thead className="bg-slate-50 text-slate-700 font-medium">
                                <tr>
                                    <th className="px-4 py-3 border-b">Tên Công Ty</th>
                                    <th className="px-4 py-3 border-b">Email</th>
                                    <th className="px-4 py-3 border-b">Sản Phẩm Quan Tâm</th>
                                    <th className="px-4 py-3 border-b">Trạng Thái</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                {viewingGroup.leads.map((lead) => (
                                    <tr key={lead.id} className="hover:bg-slate-50">
                                        <td className="px-4 py-3 font-medium text-slate-800">{lead.companyName}</td>
                                        <td className="px-4 py-3 text-blue-600">{lead.email}</td>
                                        <td className="px-4 py-3 text-slate-600">{lead.productInterest}</td>
                                        <td className="px-4 py-3">
                                            <span className={`px-2 py-1 rounded text-xs font-medium 
                                                ${lead.status === LeadStatus.NEW ? 'bg-slate-100 text-slate-600' : ''}
                                                ${lead.status === LeadStatus.SENT ? 'bg-green-100 text-green-700' : ''}
                                            `}>
                                                {lead.status}
                                            </span>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
                <div className="p-4 border-t border-slate-100 bg-white rounded-b-xl flex justify-end">
                    <button onClick={() => setViewingGroup(null)} className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-lg font-medium text-slate-700">Đóng</button>
                </div>
            </div>
        </div>
      )}

      {/* Creation Area */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
        <div className="flex justify-between items-start mb-4">
            <h2 className="text-lg font-bold text-slate-800">Thêm Nhóm Danh Bạ Mới</h2>
            <button
                onClick={handleDownloadTemplate}
                className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center gap-2"
            >
                <FileDown size={16} /> Tải file mẫu CSV
            </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-start mb-6">
            <div className="space-y-1 lg:col-span-1">
                <label className="block text-sm font-medium text-slate-700">Tên Nhóm <span className="text-red-500">*</span></label>
                <input
                    type="text"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-white text-black"
                    placeholder="VD: Khách KCN Tân Bình..."
                    value={newGroupName}
                    onChange={(e) => setNewGroupName(e.target.value)}
                />
            </div>

            <div className="space-y-1 lg:col-span-1">
                <label className="block text-sm font-medium text-slate-700">Gán Danh Mục Sản Phẩm <span className="text-red-500">*</span></label>
                <select
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-white text-black"
                    value={selectedCatalogueId}
                    onChange={(e) => setSelectedCatalogueId(e.target.value)}
                >
                    <option value="">-- Chọn danh mục --</option>
                    {catalogues.map(cat => (
                        <option key={cat.id} value={cat.id}>{cat.name}</option>
                    ))}
                </select>
                <p className="text-[10px] text-slate-400 mt-1">
                    {inputMethod === 'manual' ? 'Nếu bỏ trống, hệ thống sẽ lấy theo sản phẩm chọn ở bảng dưới.' : 'AI sẽ dựa vào link của danh mục này để gửi kèm.'}
                </p>
            </div>
        </div>

        {/* INPUT METHOD SELECTION */}
        <div className="mb-4">
             <label className="block text-sm font-medium text-slate-700 mb-2">Chọn nguồn dữ liệu</label>
             <div className="flex gap-2">
                <button
                    onClick={() => setInputMethod('import')}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                        inputMethod === 'import' 
                        ? 'bg-blue-600 text-white shadow-md' 
                        : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                >
                    <FileUp size={16} /> Nhập từ File/Link
                </button>
                <button
                    onClick={() => setInputMethod('manual')}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                        inputMethod === 'manual' 
                        ? 'bg-blue-600 text-white shadow-md' 
                        : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                >
                    <Keyboard size={16} /> Nhập Thủ Công
                </button>
             </div>
        </div>
            
        {/* IMPORT METHOD UI */}
        {inputMethod === 'import' && (
            <div className="space-y-3 p-4 bg-slate-50 rounded-xl border border-slate-100 animate-fade-in">
                <div className="grid grid-cols-2 gap-3">
                    {/* File Upload */}
                    <label className={`cursor-pointer border border-dashed hover:border-blue-500 text-black px-3 py-2 rounded-lg text-sm font-medium flex items-center justify-center gap-2 transition-colors h-[42px] ${!driveLink && !isScanningDrive ? 'bg-white' : 'bg-white opacity-50'}`}>
                        <Upload size={16} />
                        <span className="truncate">{tempLeads.length > 0 && !driveLink ? `Đã tải ${tempLeads.length} dòng` : "Tải file Excel/CSV"}</span>
                        <input
                            type="file"
                            accept=".csv, .txt"
                            className="hidden"
                            onChange={handleFileUpload}
                            disabled={isScanningDrive}
                        />
                    </label>

                    {/* Drive Link Input Group */}
                    <div className="flex gap-2">
                        <div className="flex-1 relative">
                            <input 
                                type="text" 
                                className="w-full pl-8 pr-2 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none h-[42px] bg-white text-black"
                                placeholder="Link Google Sheet..."
                                value={driveLink}
                                onChange={(e) => {
                                    setDriveLink(e.target.value);
                                    if(e.target.value) setTempLeads([]); // Clear file upload if typing link
                                }}
                                disabled={isScanningDrive}
                            />
                            <LinkIcon size={14} className="absolute left-2.5 top-3.5 text-slate-400" />
                        </div>
                        <button 
                            onClick={handleScanDrive}
                            disabled={!driveLink || isScanningDrive}
                            className="bg-green-600 hover:bg-green-700 disabled:bg-slate-300 text-white px-3 rounded-lg h-[42px] flex items-center justify-center"
                            title="Quét dữ liệu từ Link"
                        >
                            {isScanningDrive ? <Loader2 size={18} className="animate-spin" /> : <CloudDownload size={18} />}
                        </button>
                    </div>
                </div>
                {uploadError && <p className="text-xs text-red-500 flex items-center gap-1"><AlertCircle size={10}/> {uploadError}</p>}
                
                {/* Preview leads if uploaded */}
                {tempLeads.length > 0 && (
                    <div className="mt-4">
                        <div className="flex justify-between items-center mb-2">
                            <p className="text-sm font-medium text-slate-700">
                                <span className="text-green-600 font-bold">✓ Đã tìm thấy {tempLeads.length} liên hệ</span> (Xem trước 3 dòng đầu):
                            </p>
                            <button onClick={() => setTempLeads([])} className="text-xs text-red-500 hover:underline">Hủy bỏ</button>
                        </div>
                        <div className="bg-white rounded border border-slate-200 overflow-hidden">
                            <table className="w-full text-sm text-left">
                                <thead className="bg-slate-50 text-slate-500">
                                    <tr>
                                        <th className="px-3 py-2">Công ty</th>
                                        <th className="px-3 py-2">Email</th>
                                        <th className="px-3 py-2">Sản phẩm QT</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100">
                                        {tempLeads.slice(0, 3).map((lead, idx) => (
                                        <tr key={idx}>
                                            <td className="px-3 py-2">{lead.companyName}</td>
                                            <td className="px-3 py-2 text-blue-600">{lead.email}</td>
                                            <td className="px-3 py-2 text-slate-500">{lead.productInterest}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                        {tempLeads.length > 3 && <p className="text-xs text-slate-500 mt-2 italic text-center">... và {tempLeads.length - 3} khách hàng khác.</p>}
                    </div>
                )}
            </div>
        )}

        {/* MANUAL METHOD UI */}
        {inputMethod === 'manual' && (
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 animate-fade-in">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left mb-2">
                        <thead className="bg-slate-200 text-slate-600">
                            <tr>
                                <th className="px-3 py-2 rounded-tl-lg">Tên Công Ty/Người nhận <span className="text-red-500">*</span></th>
                                <th className="px-3 py-2">Email <span className="text-red-500">*</span></th>
                                <th className="px-3 py-2">Nhóm Hàng/Sản Phẩm</th>
                                <th className="px-3 py-2 rounded-tr-lg w-10"></th>
                            </tr>
                        </thead>
                        <tbody className="space-y-2">
                            {manualLeads.map((row, idx) => (
                                <tr key={idx} className="bg-white border-b border-slate-100">
                                    <td className="p-2">
                                        <input 
                                            type="text" 
                                            className="w-full border border-slate-200 rounded px-2 py-1 focus:ring-1 focus:ring-blue-500 outline-none text-black bg-white"
                                            placeholder="Công ty A..."
                                            value={row.name}
                                            onChange={(e) => handleManualChange(idx, 'name', e.target.value)}
                                        />
                                    </td>
                                    <td className="p-2">
                                        <input 
                                            type="email" 
                                            className="w-full border border-slate-200 rounded px-2 py-1 focus:ring-1 focus:ring-blue-500 outline-none text-black bg-white"
                                            placeholder="sales@company..."
                                            value={row.email}
                                            onChange={(e) => handleManualChange(idx, 'email', e.target.value)}
                                        />
                                    </td>
                                    <td className="p-2">
                                        <select 
                                            className="w-full border border-slate-200 rounded px-2 py-1 focus:ring-1 focus:ring-blue-500 outline-none text-black bg-white"
                                            value={row.product}
                                            onChange={(e) => handleManualChange(idx, 'product', e.target.value)}
                                        >
                                            <option value="">-- Chọn nhóm hàng --</option>
                                            {catalogues.map(cat => (
                                                <option key={cat.id} value={cat.name}>{cat.name}</option>
                                            ))}
                                        </select>
                                    </td>
                                    <td className="p-2 text-center">
                                        {manualLeads.length > 1 && (
                                            <button 
                                                onClick={() => handleRemoveManualRow(idx)}
                                                className="text-slate-300 hover:text-red-500 transition-colors"
                                            >
                                                <X size={16} />
                                            </button>
                                        )}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                <button 
                    onClick={handleAddManualRow}
                    className="flex items-center gap-1 text-sm text-blue-600 hover:text-blue-700 font-medium px-2 py-1"
                >
                    <Plus size={16} /> Thêm dòng
                </button>
            </div>
        )}
        
        {/* Action Buttons Row */}
        <div className="mt-6 border-t border-slate-100 pt-4 flex justify-end">
             <button
                onClick={handleSaveGroup}
                disabled={!isValidToSave()}
                className="bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white px-6 py-2 rounded-lg font-bold transition-colors flex items-center gap-2 shadow-sm"
            >
                <Save size={18} /> Lưu Danh Bạ Mới
            </button>
        </div>
      </div>

      {/* List Area */}
      <div>
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4">
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <Users size={20} className="text-indigo-600"/> 
                Danh Sách Các Nhóm Đã Lưu ({contactGroups.length})
            </h3>
            
            {/* Export Toolbar */}
            <div className="flex gap-2">
                <button
                    onClick={handleExportAllCSV}
                    className="flex items-center gap-1 px-3 py-2 bg-white border border-green-200 text-green-700 hover:bg-green-50 rounded-lg text-sm font-medium transition-colors"
                    title="Xuất Excel/CSV Tổng hợp (Master List)"
                >
                    <FileSpreadsheet size={16} /> <span className="hidden sm:inline">Xuất Excel Tổng</span>
                </button>
                <button
                    onClick={handleExportAllTXT}
                    className="flex items-center gap-1 px-3 py-2 bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 rounded-lg text-sm font-medium transition-colors"
                    title="Xuất file Text"
                >
                    <FileText size={16} /> <span className="hidden sm:inline">Xuất Text</span>
                </button>
            </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {contactGroups.map(group => {
                const linkedCat = catalogues.find(c => c.id === group.catalogueId);
                return (
                    <div key={group.id} className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 hover:shadow-md transition-shadow relative group">
                        <div className="flex justify-between items-start mb-3">
                            <div className="p-3 bg-indigo-50 text-indigo-600 rounded-lg">
                                <UserCheck size={24} />
                            </div>
                            <div className="flex gap-2">
                                <button
                                    onClick={() => setViewingGroup(group)}
                                    className="text-slate-300 hover:text-blue-500 transition-colors"
                                    title="Xem chi tiết"
                                >
                                    <Eye size={18} />
                                </button>
                                <button 
                                    onClick={() => setDeleteGroupId(group.id)}
                                    className="text-slate-300 hover:text-red-500 transition-colors"
                                    title="Xóa danh bạ"
                                >
                                    <Trash2 size={18} />
                                </button>
                            </div>
                        </div>
                        
                        <h4 className="font-bold text-lg text-slate-800 mb-1">{group.name}</h4>
                        
                        {/* Catalogue Tag */}
                        <div className="mb-4">
                            {linkedCat ? (
                                <span className="inline-flex items-center gap-1 text-xs font-medium px-2 py-1 rounded bg-blue-100 text-blue-700">
                                    <Tag size={12} /> {linkedCat.name}
                                </span>
                            ) : (
                                <span className="inline-flex items-center gap-1 text-xs font-medium px-2 py-1 rounded bg-slate-100 text-slate-500">
                                    <Tag size={12} /> Chưa phân loại
                                </span>
                            )}
                        </div>

                        <p className="text-xs text-slate-500 mb-2">Ngày tạo: {new Date(group.createdAt).toLocaleDateString('vi-VN')}</p>
                        
                        <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                            <span className="text-sm text-slate-600">Tổng số khách:</span>
                            <span className="text-lg font-bold text-indigo-600">{group.leads.length}</span>
                        </div>
                    </div>
                );
            })}
            
            {contactGroups.length === 0 && (
                <div className="col-span-full py-12 text-center text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-300">
                    <Users size={48} className="mx-auto mb-3 opacity-20" />
                    <p>Chưa có danh bạ nào được lưu.</p>
                    <p className="text-sm mt-1">Hãy tải file CSV và chọn danh mục để bắt đầu.</p>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default ContactManager;