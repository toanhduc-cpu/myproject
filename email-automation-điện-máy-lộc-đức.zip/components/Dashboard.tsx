import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, AreaChart, Area } from 'recharts';
import { Stats, ActivityLog } from '../types';
import { TrendingUp, Users, Mail, CheckCircle, ArrowUpRight, Clock, MoreHorizontal, BookOpen, Layers, Zap } from 'lucide-react';

interface DashboardProps {
  stats: Stats;
  activities: ActivityLog[];
}

const data = [
  { name: 'T2', emails: 40, leads: 24 },
  { name: 'T3', emails: 30, leads: 13 },
  { name: 'T4', emails: 20, leads: 18 },
  { name: 'T5', emails: 27, leads: 19 },
  { name: 'T6', emails: 18, leads: 10 },
  { name: 'T7', emails: 23, leads: 15 },
  { name: 'CN', emails: 10, leads: 5 },
];

const StatCard: React.FC<{ title: string; value: string | number; subtext: string; icon: React.ElementType; color: string }> = ({ title, value, subtext, icon: Icon, color }) => (
  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow relative overflow-hidden group">
    <div className={`absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity ${color.replace('bg-', 'text-')}`}>
        <Icon size={64} />
    </div>
    <div className="relative z-10 flex flex-col h-full justify-between">
        <div className="flex items-start justify-between mb-4">
            <div className={`p-3 rounded-xl ${color} bg-opacity-10 text-${color.split('-')[1]}-600`}>
                <Icon size={24} className={color.replace('bg-', 'text-')} />
            </div>
            <span className="flex items-center text-xs font-medium text-green-600 bg-green-50 px-2 py-1 rounded-full">
                <ArrowUpRight size={12} className="mr-1" /> +12%
            </span>
        </div>
        <div>
            <h3 className="text-3xl font-bold text-slate-800 tracking-tight">{value}</h3>
            <p className="text-sm font-medium text-slate-500 mt-1">{title}</p>
            <p className="text-xs text-slate-400 mt-2">{subtext}</p>
        </div>
    </div>
  </div>
);

const Dashboard: React.FC<DashboardProps> = ({ stats, activities }) => {
  const getTypeIcon = (type: string) => {
    switch(type) {
        case 'CATALOGUE': return <BookOpen size={14}/>;
        case 'CONTACT': return <Users size={14}/>;
        case 'CAMPAIGN': return <Zap size={14}/>;
        default: return <Layers size={14}/>;
    }
  };

  const getTypeStyle = (type: string) => {
      switch(type) {
        case 'CATALOGUE': return 'bg-orange-100 text-orange-700';
        case 'CONTACT': return 'bg-indigo-100 text-indigo-700';
        case 'CAMPAIGN': return 'bg-blue-100 text-blue-700';
        default: return 'bg-slate-100 text-slate-700';
    }
  };

  const formatTime = (timestamp: number) => {
      const diff = Date.now() - timestamp;
      const minutes = Math.floor(diff / 60000);
      const hours = Math.floor(minutes / 60);
      const days = Math.floor(hours / 24);

      if (minutes < 1) return 'Vừa xong';
      if (minutes < 60) return `${minutes} phút trước`;
      if (hours < 24) return `${hours} giờ trước`;
      return `${days} ngày trước`;
  };

  return (
    <div className="space-y-8 animate-fade-in pb-10">
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
            title="Email Đã Gửi" 
            value={stats.totalSent.toLocaleString()} 
            subtext="Tổng số email marketing đã gửi đi"
            icon={Mail} 
            color="bg-blue-500" 
        />
        <StatCard 
            title="Khách Quan Tâm (Leads)" 
            value={stats.leadsGenerated} 
            subtext="Khách hàng phản hồi hoặc click link"
            icon={Users} 
            color="bg-indigo-500" 
        />
        <StatCard 
            title="Tỷ Lệ Mở Email" 
            value={`${stats.openRate}%`} 
            subtext="Hiệu suất tiêu đề email trung bình"
            icon={TrendingUp} 
            color="bg-green-500" 
        />
        <StatCard 
            title="Tỷ Lệ Chuyển Đổi" 
            value={`${stats.responseRate}%`} 
            subtext="Khách hàng yêu cầu báo giá"
            icon={CheckCircle} 
            color="bg-teal-500" 
        />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-6">
            <div>
                <h3 className="text-lg font-bold text-slate-800">Hiệu Suất Chiến Dịch</h3>
                <p className="text-sm text-slate-500">So sánh lượng email gửi đi và lượng khách quan tâm theo ngày</p>
            </div>
            <select className="text-sm border-none bg-slate-50 rounded-lg px-3 py-1 text-slate-600 outline-none cursor-pointer">
                <option>7 ngày qua</option>
                <option>Tháng này</option>
            </select>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorEmails" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorLeads" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }} />
                <Area type="monotone" dataKey="emails" stroke="#3b82f6" strokeWidth={2} fillOpacity={1} fill="url(#colorEmails)" name="Email Gửi" />
                <Area type="monotone" dataKey="leads" stroke="#6366f1" strokeWidth={2} fillOpacity={1} fill="url(#colorLeads)" name="Leads" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-800 mb-2">Tăng Trưởng Tuần</h3>
          <p className="text-sm text-slate-500 mb-6">Xu hướng khách hàng mới</p>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{ borderRadius: '8px', border: 'none' }} />
                <Bar dataKey="leads" fill="#10b981" radius={[4, 4, 0, 0]} barSize={30} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Recent Activity Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex items-center justify-between">
            <h3 className="text-lg font-bold text-slate-800">Nhật Ký Hoạt Động</h3>
            <span className="text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded-full">
                {activities.length} hoạt động
            </span>
          </div>
          <div className="overflow-x-auto max-h-[400px] overflow-y-auto">
            <table className="w-full text-left text-sm">
                <thead className="bg-slate-50 text-slate-500 font-medium sticky top-0 z-10">
                    <tr>
                        <th className="px-6 py-4">Loại hình</th>
                        <th className="px-6 py-4">Hành động</th>
                        <th className="px-6 py-4">Đối tượng</th>
                        <th className="px-6 py-4">Trạng Thái</th>
                        <th className="px-6 py-4">Thời Gian</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                    {activities.length === 0 ? (
                        <tr>
                            <td colSpan={5} className="px-6 py-8 text-center text-slate-400">Chưa có hoạt động nào được ghi nhận.</td>
                        </tr>
                    ) : (
                        activities.map((activity) => (
                            <tr key={activity.id} className="hover:bg-slate-50 transition-colors">
                                <td className="px-6 py-4">
                                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border border-transparent ${getTypeStyle(activity.type)}`}>
                                        {getTypeIcon(activity.type)}
                                        {activity.type === 'CATALOGUE' && 'Danh mục'}
                                        {activity.type === 'CONTACT' && 'Danh bạ'}
                                        {activity.type === 'CAMPAIGN' && 'Chiến dịch'}
                                        {activity.type === 'SYSTEM' && 'Hệ thống'}
                                    </span>
                                </td>
                                <td className="px-6 py-4 font-medium text-slate-800">{activity.action}</td>
                                <td className="px-6 py-4 text-slate-600">{activity.target}</td>
                                <td className="px-6 py-4">
                                    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-bold
                                        ${activity.status === 'SUCCESS' ? 'text-green-600' : ''}
                                        ${activity.status === 'WARNING' ? 'text-orange-600' : ''}
                                        ${activity.status === 'ERROR' ? 'text-red-600' : ''}
                                    `}>
                                        {activity.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-slate-500 flex items-center gap-1">
                                    <Clock size={14} /> {formatTime(activity.timestamp)}
                                </td>
                            </tr>
                        ))
                    )}
                </tbody>
            </table>
          </div>
      </div>
    </div>
  );
};

export default Dashboard;