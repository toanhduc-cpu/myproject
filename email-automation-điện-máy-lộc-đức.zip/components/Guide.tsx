import React from 'react';
import { ShieldCheck, Database, Mail } from 'lucide-react';

const Guide: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-2xl p-8 text-white shadow-lg">
        <h2 className="text-3xl font-bold mb-4">Quy Trình Marketing Tự Động Hóa</h2>
        <p className="text-blue-100 text-lg">
          Dành riêng cho Điện Máy Lộc Đức. Hệ thống giúp bạn tiết kiệm nhân sự, tăng chuyên nghiệp và tiếp cận hàng ngàn khách hàng B2B.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <div className="w-12 h-12 bg-green-100 text-green-600 rounded-lg flex items-center justify-center mb-4">
            <ShieldCheck size={24} />
          </div>
          <h3 className="font-bold text-lg mb-2">Bước 1: Hạ Tầng</h3>
          <p className="text-slate-600 text-sm leading-relaxed">
            Tuyệt đối không dùng @gmail.com. Hãy đăng ký email tên miền (VD: <strong>sales@dienmaylocduc.vn</strong>) để tăng độ uy tín và tránh Spam.
          </p>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <div className="w-12 h-12 bg-orange-100 text-orange-600 rounded-lg flex items-center justify-center mb-4">
            <Database size={24} />
          </div>
          <h3 className="font-bold text-lg mb-2">Bước 2: Dữ Liệu</h3>
          <p className="text-slate-600 text-sm leading-relaxed">
            Thu thập email từ Trang Vàng, Hội nhóm Facebook hoặc Google Maps (KCN). Phân loại khách theo nhu cầu (Máy hàn, Dụng cụ điện...).
          </p>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <div className="w-12 h-12 bg-purple-100 text-purple-600 rounded-lg flex items-center justify-center mb-4">
            <Mail size={24} />
          </div>
          <h3 className="font-bold text-lg mb-2">Bước 3: Vận Hành Tool</h3>
          <p className="text-slate-600 text-sm leading-relaxed">
            Nhập Data vào Tab "Chiến dịch Auto". AI sẽ tự viết mail theo từng khách. Bạn chỉ cần duyệt và bấm gửi. Hệ thống tự đính kèm Catalogue.
          </p>
        </div>
      </div>

      <div className="bg-slate-50 p-6 rounded-xl border border-slate-200">
        <h3 className="font-bold text-slate-800 mb-3">Mẫu nội dung AI được huấn luyện:</h3>
        <blockquote className="bg-white p-4 border-l-4 border-blue-500 italic text-slate-600 shadow-sm">
          "Chào bộ phận thu mua [Tên Khách],<br/><br/>
          Điện Máy Lộc Đức chuyên cung cấp sỉ [Sản Phẩm Quan Tâm]. Do không có nhân sự sale làm phiền, tôi gửi link Catalogue và giá sỉ ưu đãi tại đây: [Link]... "
        </blockquote>
      </div>
    </div>
  );
};

export default Guide;