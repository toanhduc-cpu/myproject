import React, { useState } from 'react';
import { RecycleBinItem, TrashItemType, ActivityType } from '../types';
import { RotateCcw, XCircle, Trash2, AlertTriangle, Clock } from 'lucide-react';

interface RecycleBinProps {
    items: RecycleBinItem[];
    onRestore: (item: RecycleBinItem) => void;
    onPermanentDelete: (id: string) => void;
    logActivity: (type: ActivityType, action: string, target: string, status?: 'SUCCESS' | 'WARNING' | 'ERROR') => void;
}

const RecycleBin: React.FC<RecycleBinProps> = ({ items, onRestore, onPermanentDelete, logActivity }) => {
    // State to manage the confirmation modal
    const [actionModal, setActionModal] = useState<{
        type: 'RESTORE' | 'DELETE';
        item: RecycleBinItem;
    } | null>(null);

    const getDaysRemaining = (deletedAt: number) => {
        const daysPassed = (Date.now() - deletedAt) / (1000 * 60 * 60 * 24);
        const daysLeft = 30 - daysPassed;
        return Math.max(0, Math.floor(daysLeft));
    };

    const getTypeLabel = (type: TrashItemType) => {
        switch(type) {
            case 'CATALOGUE': return 'Danh mục SP';
            case 'CONTACT_GROUP': return 'Nhóm danh bạ';
            case 'EVENT': return 'Sự kiện';
            case 'CAMPAIGN_TEMPLATE': return 'Mẫu chiến dịch';
            default: return 'Khác';
        }
    };

    const getItemDetail = (item: RecycleBinItem) => {
        const { type, originalData } = item;
        try {
            switch(type) {
                case 'CATALOGUE': 
                    return <span className="text-slate-500 italic truncate max-w-[200px] block">{originalData.link || 'Không có link'}</span>;
                case 'CONTACT_GROUP': 
                    return <span className="font-medium text-blue-600">{originalData.leads?.length || 0} liên hệ</span>;
                case 'EVENT': 
                    return <span className="text-slate-600">Ngày: {originalData.date}</span>;
                case 'CAMPAIGN_TEMPLATE': 
                    return <span className="text-xs text-slate-400">Mẫu sẵn có</span>;
                default: return null;
            }
        } catch (e) {
            return null;
        }
    };

    const handleConfirmAction = () => {
        if (!actionModal) return;

        if (actionModal.type === 'RESTORE') {
            onRestore(actionModal.item);
            logActivity('RECYCLE', 'Khôi phục dữ liệu', actionModal.item.name, 'SUCCESS');
        } else {
            onPermanentDelete(actionModal.item.id);
            logActivity('RECYCLE', 'Xóa vĩnh viễn', actionModal.item.name, 'WARNING');
        }
        setActionModal(null);
    };

    return (
        <div className="space-y-6 animate-fade-in relative">
            {/* Confirmation Modal */}
            {actionModal && (
                <div className="fixed inset-0 bg-black/50 z-[80] flex items-center justify-center p-4 animate-fade-in">
                    <div className="bg-white rounded-xl shadow-xl w-full max-w-sm p-6 transform transition-all scale-100">
                        <div className="flex flex-col items-center text-center mb-6">
                            <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-4 ${
                                actionModal.type === 'DELETE' ? 'bg-red-100 text-red-500' : 'bg-blue-100 text-blue-600'
                            }`}>
                                {actionModal.type === 'DELETE' ? <AlertTriangle size={28} /> : <RotateCcw size={28} />}
                            </div>
                            <h3 className="text-lg font-bold text-slate-800">
                                {actionModal.type === 'DELETE' ? 'Xóa Vĩnh Viễn?' : 'Khôi Phục Dữ Liệu?'}
                            </h3>
                            <p className="text-sm text-slate-500 mt-2">
                                {actionModal.type === 'DELETE' 
                                    ? <span>Bạn sắp xóa <strong>"{actionModal.item.name}"</strong>. <br/>Hành động này <strong>không thể hoàn tác</strong>!</span>
                                    : <span>Khôi phục <strong>"{actionModal.item.name}"</strong> về danh sách quản lý ban đầu?</span>
                                }
                            </p>
                        </div>
                        <div className="flex gap-3">
                            <button 
                                onClick={() => setActionModal(null)}
                                className="flex-1 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg transition-colors"
                            >
                                Hủy bỏ
                            </button>
                            <button 
                                onClick={handleConfirmAction}
                                className={`flex-1 px-4 py-2 font-medium rounded-lg transition-colors text-white ${
                                    actionModal.type === 'DELETE' 
                                    ? 'bg-red-600 hover:bg-red-700' 
                                    : 'bg-blue-600 hover:bg-blue-700'
                                }`}
                            >
                                {actionModal.type === 'DELETE' ? 'Xác nhận Xóa' : 'Đồng ý Khôi phục'}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                <div className="flex items-center gap-4 mb-4">
                    <div className="w-12 h-12 bg-red-50 text-red-600 rounded-full flex items-center justify-center">
                        <Trash2 size={24} />
                    </div>
                    <div>
                        <h2 className="text-xl font-bold text-slate-800">Thùng rác & Backup dữ liệu</h2>
                        <p className="text-sm text-slate-500">
                            Các mục đã xóa sẽ được lưu trữ tại đây trong <span className="font-bold text-red-600">30 ngày</span> trước khi bị xóa vĩnh viễn.
                        </p>
                    </div>
                </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                <table className="w-full text-left text-sm">
                    <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                        <tr>
                            <th className="p-4">Tên Mục</th>
                            <th className="p-4">Loại Dữ Liệu</th>
                            <th className="p-4">Chi Tiết</th>
                            <th className="p-4">Ngày Xóa</th>
                            <th className="p-4">Tự hủy sau</th>
                            <th className="p-4 text-right">Hành động</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {items.length === 0 ? (
                            <tr>
                                <td colSpan={6} className="p-12 text-center text-slate-400">
                                    <Trash2 size={48} className="mx-auto mb-3 opacity-20" />
                                    <p>Thùng rác trống. Chưa có dữ liệu nào bị xóa.</p>
                                </td>
                            </tr>
                        ) : (
                            items.map(item => {
                                const daysLeft = getDaysRemaining(item.deletedAt);
                                return (
                                    <tr key={item.id} className="hover:bg-slate-50 text-black transition-colors">
                                        <td className="p-4 font-bold">{item.name}</td>
                                        <td className="p-4">
                                            <span className="bg-slate-100 text-slate-700 px-2 py-1 rounded text-xs font-medium border border-slate-200">
                                                {getTypeLabel(item.type)}
                                            </span>
                                        </td>
                                        <td className="p-4 text-sm">
                                            {getItemDetail(item)}
                                        </td>
                                        <td className="p-4 text-slate-600">
                                            {new Date(item.deletedAt).toLocaleString('vi-VN')}
                                        </td>
                                        <td className="p-4 text-orange-600 font-medium flex items-center gap-1">
                                            <Clock size={14} /> {daysLeft} ngày
                                        </td>
                                        <td className="p-4 text-right">
                                            <div className="flex justify-end gap-2">
                                                <button 
                                                    onClick={() => setActionModal({ type: 'RESTORE', item })}
                                                    className="flex items-center gap-1 px-3 py-1.5 bg-blue-600 text-white rounded hover:bg-blue-700 font-medium transition-colors shadow-sm"
                                                >
                                                    <RotateCcw size={14} /> Khôi phục
                                                </button>
                                                <button 
                                                    onClick={() => setActionModal({ type: 'DELETE', item })}
                                                    className="flex items-center gap-1 px-3 py-1.5 bg-white border border-red-200 text-red-600 rounded hover:bg-red-50 font-medium transition-colors"
                                                >
                                                    <XCircle size={14} /> Xóa hẳn
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                );
                            })
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default RecycleBin;