import React from 'react';
import { LayoutDashboard, Send, BookOpen, BookCheck, Users, Trash2 } from 'lucide-react';
import { ViewState } from '../types';

interface SidebarProps {
  currentView: ViewState;
  onChangeView: (view: ViewState) => void;
  recycleBinCount: number;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, onChangeView, recycleBinCount }) => {
  const navItems = [
    { id: 'dashboard', label: 'Tổng quan', icon: LayoutDashboard },
    { id: 'contacts', label: 'Quản lý Danh bạ', icon: Users },
    { id: 'catalogues', label: 'Quản lý Catalogue', icon: BookOpen },
    { id: 'campaign', label: 'Chiến dịch Auto', icon: Send },
    { id: 'guide', label: 'Hướng dẫn & Quy trình', icon: BookCheck },
  ];

  return (
    <div className="w-64 bg-slate-900 text-white flex flex-col h-screen fixed left-0 top-0 z-10 shadow-xl">
      <div className="p-6 border-b border-slate-700">
        <h1 className="text-xl font-bold flex items-center gap-2">
          <span className="text-blue-400">Lộc Đức</span> Hub
        </h1>
        <p className="text-xs text-slate-400 mt-1">B2B Automation System</p>
      </div>

      <nav className="flex-1 p-4 space-y-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onChangeView(item.id as ViewState)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                isActive
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Icon size={20} />
              <span className="font-medium">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-700">
        <button
            onClick={() => onChangeView('recycleBin')}
            className={`w-full flex items-center justify-between px-4 py-3 rounded-lg transition-colors group ${
            currentView === 'recycleBin'
                ? 'bg-red-900/50 text-red-200 border border-red-800'
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
        >
            <div className="flex items-center gap-3">
                <Trash2 size={20} />
                <span className="font-medium">Thùng rác</span>
            </div>
            {recycleBinCount > 0 && (
                <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                    currentView === 'recycleBin' ? 'bg-red-600 text-white' : 'bg-red-600 text-white group-hover:bg-red-500'
                }`}>
                    {recycleBinCount}
                </span>
            )}
        </button>
      </div>
    </div>
  );
};

export default Sidebar;