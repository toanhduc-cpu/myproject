import { GoogleGenAI } from "@google/genai";
import { CatalogueItem } from "../types";

const getAIClient = () => {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
        throw new Error("API Key chưa được cấu hình trong hệ thống.");
    }
    return new GoogleGenAI({ apiKey });
};

export const suggestCataloguesForEvent = async (
    eventName: string,
    eventNote: string,
    catalogues: CatalogueItem[]
): Promise<string[]> => {
    const ai = getAIClient();
    
    const catalogueList = catalogues.map(c => `- ID: ${c.id}, Tên: ${c.name}, Mô tả: ${c.description}`).join('\n');

    const prompt = `
    Bạn là chuyên gia Marketing B2B cho ngành kim khí, điện máy.
    
    Sự kiện: "${eventName}"
    Ghi chú sự kiện: "${eventNote}"

    Danh sách các dòng sản phẩm hiện có:
    ${catalogueList}

    Nhiệm vụ: Hãy chọn ra các ID của dòng sản phẩm phù hợp nhất để chạy khuyến mãi hoặc chào hàng trong dịp sự kiện này.
    Ví dụ: Cuối năm thì nên bán Dụng cụ làm sạch, sửa chữa nhà cửa. Đầu năm khai trương thì bán máy móc sản xuất.

    Chỉ trả về kết quả là một mảng JSON chứa các ID. Ví dụ: ["1", "3"]. Không giải thích gì thêm.
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        
        const text = response.text || "[]";
        // Extract JSON array from text (handling potential markdown wrapping)
        const jsonMatch = text.match(/\[.*\]/s);
        if (jsonMatch) {
            return JSON.parse(jsonMatch[0]);
        }
        return [];
    } catch (error) {
        console.error("AI Suggestion Error:", error);
        return []; // Return empty if error, fallback to manual selection
    }
};

export const generateEmailTemplate = async (
    catalogue: CatalogueItem,
    eventName?: string,
    customInstruction?: string
): Promise<string> => {
    const ai = getAIClient();

    const eventContext = eventName 
        ? `Nhân dịp sự kiện "${eventName}", hãy lồng ghép lời chúc hoặc lý do khuyến mãi liên quan đến sự kiện này thật khéo léo.`
        : "";

    const instructionContext = customInstruction
        ? `Lưu ý ĐẶC BIỆT về giọng văn/yêu cầu từ người gửi: "${customInstruction}"`
        : "";

    const prompt = `
    Bạn là nhân viên kinh doanh của công ty "Điện Máy Lộc Đức".
    Hãy viết một mẫu email chào hàng (Email Template) chung để gửi cho các công ty khách hàng.

    Sản phẩm chào bán: ${catalogue.name}
    Link Catalogue: ${catalogue.link}
    Mô tả sản phẩm: ${catalogue.description}
    ${eventContext}
    ${instructionContext}

    Yêu cầu:
    - Sử dụng các placeholder như [Tên Khách Hàng], [Tên Công Ty] để người dùng hiểu đây là mẫu.
    - Tiêu đề hấp dẫn, bắt trend sự kiện (nếu có).
    - Nội dung chuyên nghiệp, ngắn gọn, tập trung vào lợi ích B2B (giá sỉ, hàng chính hãng).
    - Trả về định dạng văn bản thuần túy.
  `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        return response.text || "Không thể tạo mẫu. Vui lòng thử lại.";
    } catch (error) {
        console.error("Gemini Template Error:", error);
        throw new Error("Lỗi khi kết nối với AI để tạo mẫu.");
    }
};

export const generateSalesEmail = async (
  companyName: string,
  productInterest: string,
  catalogue: CatalogueItem | undefined
): Promise<string> => {
  const ai = getAIClient();

  const catalogueContext = catalogue
    ? `Tôi có đính kèm Catalogue và Bảng giá cho dòng sản phẩm ${catalogue.name} tại đường dẫn sau: ${catalogue.link}`
    : `Tôi có đính kèm link Catalogue tổng hợp các sản phẩm ${productInterest} để quý công ty tham khảo.`;

  const prompt = `
    Bạn là nhân viên kinh doanh chuyên nghiệp của công ty "Điện Máy Lộc Đức" (dienmaylocduc.vn).
    Công ty chuyên cung cấp sỉ B2B các thiết bị kim khí, điện máy (Bosch, Makita, máy hàn, dụng cụ cầm tay...).

    Hãy viết một email chào hàng ngắn gọn, chuyên nghiệp, lịch sự gửi tới bộ phận thu mua của công ty khách hàng.

    Thông tin khách hàng:
    - Tên công ty: ${companyName}
    - Sản phẩm quan tâm: ${productInterest}

    Yêu cầu nội dung:
    1. Tiêu đề email hấp dẫn, chuyên nghiệp (Ví dụ: Giải pháp cung ứng vật tư...).
    2. Chào hỏi lịch sự.
    3. Nhấn mạnh vào việc cung cấp hàng chính hãng, giá sỉ tốt nhất thị trường, và dịch vụ hỗ trợ kỹ thuật.
    4. Chèn ngữ cảnh catalogue này vào thân bài một cách tự nhiên: "${catalogueContext}"
    5. Kết thúc bằng lời kêu gọi hành động (Call to Action) nhẹ nhàng (ví dụ: xem báo giá cập nhật).
    6. Ký tên: Ban Kinh Doanh - Điện Máy Lộc Đức.

    Chỉ trả về nội dung email (bao gồm tiêu đề và thân bài), không trả về lời dẫn của AI.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text || "Không thể tạo nội dung. Vui lòng thử lại.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Lỗi khi kết nối với Gemini AI.");
  }
};

export const generateCatalogueDescription = async (categoryName: string): Promise<string> => {
    const ai = getAIClient();
    
    const prompt = `
    Bạn là chuyên viên nội dung của công ty Điện Máy Lộc Đức (B2B).
    Hãy viết một đoạn mô tả ngắn (khoảng 2 câu) cho danh mục sản phẩm: "${categoryName}".
    
    Yêu cầu:
    - Liệt kê nhanh các dòng sản phẩm con phổ biến thuộc danh mục này.
    - Nêu ứng dụng chính hoặc lợi ích cho khách hàng doanh nghiệp (công trình, nhà xưởng).
    - Văn phong chuyên nghiệp, súc tích.
    
    Ví dụ input: "Máy hàn"
    Ví dụ output: "Bao gồm đa dạng các dòng máy hàn que, Tig, Mig, cắt Plasma chính hãng từ Jasic, Weldcom. Giải pháp tối ưu cho xưởng cơ khí, thi công kết cấu thép và công trình xây dựng."
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        return response.text?.trim() || "Chuyên cung cấp các sản phẩm chính hãng, giá sỉ cho công trình.";
    } catch (error) {
        console.error("Description Gen Error:", error);
        return "";
    }
};