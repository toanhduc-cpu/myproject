
export interface CatalogueItem {
  id: string;
  name: string; // e.g., "Máy hàn", "Dụng cụ cầm tay"
  link: string; // Google Drive or Website link
  description: string;
}

export enum LeadStatus {
  NEW = 'Mới',
  GENERATED = 'Đã viết nội dung',
  SENDING = 'Đang gửi...',
  SENT = 'Đã gửi',
  FAILED = 'Gửi lỗi'
}

export interface Lead {
  id: string;
  email: string;
  companyName: string;
  productInterest: string; // Matches a CatalogueItem name or generic
  status: LeadStatus;
  generatedContent?: string;
  createdAt: number;
}

export interface ContactGroup {
  id: string;
  name: string; // e.g., "Khách hàng KCN Bình Dương", "Khách hàng Xây Dựng"
  catalogueId: string; // Linked Product Category ID
  leads: Lead[];
  createdAt: number;
}

export interface MarketingEvent {
  id: string;
  name: string; // e.g. "Tết Nguyên Đán"
  date: string; // YYYY-MM-DD
  note: string;
  suggestedCatalogueIds: string[]; // List of IDs suitable for this event
}

export interface CampaignTemplate {
  id: string;
  name: string;
  catalogueId: string;
  targetGroupIds: string[]; // Changed from single ID to Array
  customInstruction: string;
}

export enum CampaignStatus {
  DRAFT = 'Nháp',
  SCHEDULED = 'Đã lên lịch',
  COMPLETED = 'Hoàn thành',
  CANCELLED = 'Đã hủy'
}

export interface Campaign {
  id: string;
  name: string;
  catalogueId: string;
  targetGroupIds: string[]; // Changed from single ID to Array
  status: CampaignStatus;
  scheduledTime: number; // Timestamp
  sentTime?: number;
  totalLeads: number;
  successCount: number;
  templatePreview?: string; // Saved snapshot of the template used
  eventId?: string; // Linked event
}

export interface Stats {
  totalSent: number;
  openRate: number; // Simulated percentage
  responseRate: number; // Simulated
  leadsGenerated: number;
}

export type ViewState = 'dashboard' | 'campaign' | 'catalogues' | 'guide' | 'contacts' | 'recycleBin';

export type ActivityType = 'CATALOGUE' | 'CONTACT' | 'CAMPAIGN' | 'SYSTEM' | 'RECYCLE';

export interface ActivityLog {
    id: string;
    type: ActivityType;
    action: string;
    target: string; // Tên đối tượng bị tác động (Tên nhóm, tên chiến dịch...)
    status: 'SUCCESS' | 'WARNING' | 'ERROR';
    timestamp: number;
}

export type TrashItemType = 'CATALOGUE' | 'CONTACT_GROUP' | 'EVENT' | 'CAMPAIGN_TEMPLATE';

export interface RecycleBinItem {
    id: string; // ID of the deleted item
    originalData: any; // The full object
    type: TrashItemType;
    name: string;
    deletedAt: number;
}
