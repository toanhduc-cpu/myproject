import React, { useState, useCallback, useRef, useEffect } from 'react';
import { Header } from './components/Header';
import { ProductInput } from './components/ProductInput';
import { ResultTable } from './components/ResultTable';
import { PreviewModal } from './components/PreviewModal';
import { generateSEOContent } from './services/geminiService';
import { ProcessingItem, ModelType, SEOContent } from './types';

type ProcessingStatus = 'idle' | 'running' | 'paused';

function App() {
  const [items, setItems] = useState<ProcessingItem[]>([]);
  const [processingStatus, setProcessingStatus] = useState<ProcessingStatus>('idle');
  const [selectedItem, setSelectedItem] = useState<SEOContent | null>(null);
  const [darkMode, setDarkMode] = useState(false);

  // Initialize Dark Mode based on system preference
  useEffect(() => {
    if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setDarkMode(true);
    }
  }, []);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  // --- REACTIVE QUEUE PROCESSOR ---
  // This effect monitors the list and status. It automatically picks up the next item.
  useEffect(() => {
    if (processingStatus !== 'running') return;

    // Check if there is already an item being processed (prevent concurrency issues)
    const isCurrentlyGenerating = items.some(i => i.status === 'generating');
    if (isCurrentlyGenerating) return;

    // Find the next idle item
    const nextItemIndex = items.findIndex(i => i.status === 'idle');

    // If no idle items left, stop the processor
    if (nextItemIndex === -1) {
      setProcessingStatus('idle');
      return;
    }

    const nextItem = items[nextItemIndex];

    const processItem = async () => {
      // 1. Mark as generating
      setItems(prev => {
        const newItems = [...prev];
        newItems[nextItemIndex] = { ...nextItem, status: 'generating' };
        return newItems;
      });

      try {
        // 2. Call API using the item's specific model
        const result = await generateSEOContent(nextItem.originalName, nextItem.model);
        
        // 3. Update success
        setItems(prev => prev.map(i => i.id === nextItem.id ? { ...i, status: 'success', result } : i));
      } catch (error: any) {
        // 3. Update error
        setItems(prev => prev.map(i => i.id === nextItem.id ? { ...i, status: 'error', error: error.message || "Unknown error" } : i));
      }
      
      // The effect will re-run automatically after state update to pick the next one
    };

    processItem();

  }, [items, processingStatus]);

  // --- HANDLERS ---

  const handleAddToQueue = useCallback((productNames: string[], model: ModelType) => {
    const newItems: ProcessingItem[] = productNames.map(name => ({
      id: Math.random().toString(36).substr(2, 9),
      originalName: name,
      status: 'idle',
      model: model // Bind the selected model to the item
    }));

    setItems(prev => [...prev, ...newItems]);
    
    // Auto-start if it was idle. If it was paused, keep it paused (user must resume manually).
    setProcessingStatus(prev => prev === 'idle' ? 'running' : prev);
  }, []);

  const handlePause = () => setProcessingStatus('paused');
  const handleResume = () => setProcessingStatus('running');
  
  const handleStop = () => {
    setProcessingStatus('idle');
    // We leave items in the queue (as idle) so user can resume/restart if they want.
  };

  const handleClearQueue = () => {
    setProcessingStatus('idle');
    setItems([]);
  };

  const handleExport = () => {
    const headers = [
      "Input Product", "Category", "Brand", "SEO Product Name", "Meta Title", "Meta Description", 
      "Short Desc (HTML)", "Main Content (HTML)", "Specs (HTML)", "Tags"
    ];

    const rows = items
      .filter(i => i.status === 'success' && i.result)
      .map(i => {
        const r = i.result!;
        return [
          `"${i.originalName.replace(/"/g, '""')}"`,
          `"${r.category.replace(/"/g, '""')}"`,
          `"${r.brand.replace(/"/g, '""')}"`,
          `"${r.product_name_optimized.replace(/"/g, '""')}"`,
          `"${r.meta_title.replace(/"/g, '""')}"`,
          `"${r.meta_description.replace(/"/g, '""')}"`,
          `"${r.short_description_html.replace(/"/g, '""')}"`,
          `"${r.long_description_html.replace(/"/g, '""')}"`,
          `"${r.specifications_html.replace(/"/g, '""')}"`,
          `"${r.tags.join(', ').replace(/"/g, '""')}"`
        ].join(',');
      });

    const csvContent = "data:text/csv;charset=utf-8,\uFEFF" + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "dienmaylocduc_seo_content.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className={`${darkMode ? 'dark' : ''}`}>
        <div className="min-h-screen bg-slate-50 dark:bg-slate-900 pb-20 transition-colors duration-300">
        <Header darkMode={darkMode} toggleDarkMode={toggleDarkMode} />
        
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column: Input */}
            <div className="lg:col-span-1">
                <ProductInput 
                onStartProcessing={handleAddToQueue} 
                processingStatus={processingStatus}
                onClearQueue={handleClearQueue}
                />
                
                <div className="bg-blue-50 dark:bg-blue-900/30 border border-blue-100 dark:border-blue-800 rounded-lg p-4">
                <h4 className="font-semibold text-blue-800 dark:text-blue-300 text-sm mb-2">💡 Mẹo tối ưu:</h4>
                <ul className="text-xs text-blue-700 dark:text-blue-400 space-y-2 list-disc pl-4">
                    <li>Bạn có thể thêm tiếp sản phẩm vào hàng đợi ngay cả khi hệ thống đang chạy.</li>
                    <li>Sử dụng Gemini 2.5 Flash cho tốc độ nhanh nhất.</li>
                    <li>Sử dụng Gemini 2.0 Pro cho các bài viết cần độ sâu và sáng tạo cao.</li>
                </ul>
                </div>
            </div>

            {/* Right Column: Results */}
            <div className="lg:col-span-2 space-y-6">
                <ResultTable 
                items={items} 
                onView={(item) => setSelectedItem(item.result || null)}
                onExport={handleExport}
                processingStatus={processingStatus}
                onPause={handlePause}
                onResume={handleResume}
                onStop={handleStop}
                />
                
                {items.length === 0 && (
                <div className="text-center py-20 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50/50 dark:bg-slate-800/50">
                    <div className="mx-auto h-12 w-12 text-slate-300 dark:text-slate-600">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                    </svg>
                    </div>
                    <h3 className="mt-2 text-sm font-medium text-slate-900 dark:text-slate-200">Chưa có dữ liệu</h3>
                    <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Nhập danh sách sản phẩm bên trái để bắt đầu.</p>
                </div>
                )}
            </div>
            </div>
        </main>

        {selectedItem && (
            <PreviewModal 
            content={selectedItem} 
            onClose={() => setSelectedItem(null)} 
            />
        )}
        </div>
    </div>
  );
}

export default App;