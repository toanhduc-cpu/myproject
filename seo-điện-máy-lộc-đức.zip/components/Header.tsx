import React from 'react';
import { Zap, BookOpen, Sun, Moon } from 'lucide-react';

interface HeaderProps {
    darkMode: boolean;
    toggleDarkMode: () => void;
}

export const Header: React.FC<HeaderProps> = ({ darkMode, toggleDarkMode }) => {
  return (
    <header className="bg-blue-700 dark:bg-slate-900 text-white shadow-lg sticky top-0 z-50 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="bg-white p-2 rounded-full">
            <Zap className="h-6 w-6 text-blue-700 dark:text-slate-900" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">Lộc Đức SEO Auto</h1>
            <p className="text-xs text-blue-200 dark:text-slate-400">Powered by Gemini AI</p>
          </div>
        </div>
        <div className="flex items-center space-x-4">
            <button 
                onClick={toggleDarkMode}
                className="p-2 rounded-full hover:bg-blue-600 dark:hover:bg-slate-800 transition-colors text-blue-100"
                title={darkMode ? "Chuyển sang chế độ sáng" : "Chuyển sang chế độ tối"}
            >
                {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </button>
            <a href="#" className="flex items-center space-x-1 text-sm text-blue-100 hover:text-white transition">
                <BookOpen className="h-4 w-4" />
                <span className="hidden sm:inline">Hướng dẫn</span>
            </a>
            <div className="bg-blue-800 dark:bg-slate-800 px-3 py-1 rounded text-xs font-mono border border-blue-600 dark:border-slate-700">
                v1.1.0
            </div>
        </div>
      </div>
    </header>
  );
};