import React, { useState } from 'react';
import { X, Copy, Check, Code, FileText, ThumbsUp, ThumbsDown, Image as ImageIcon, Tag, Search, Edit3, Sparkles } from 'lucide-react';
import { SEOContent } from '../types';

interface PreviewModalProps {
  content: SEOContent | null;
  onClose: () => void;
}

export const PreviewModal: React.FC<PreviewModalProps> = ({ content, onClose }) => {
  const [copied, setCopied] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'content' | 'schema'>('content');

  if (!content) return null;

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopied(key);
    setTimeout(() => setCopied(null), 2000);
  };

  const CopyButton = ({ text, id, className = "" }: { text: string, id: string, className?: string }) => (
    <button
      onClick={() => handleCopy(text, id)}
      className={`absolute top-2 right-2 p-1.5 rounded-md bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-200 transition-colors z-10 ${className}`}
      title="Copy to clipboard"
    >
      {copied === id ? <Check className="w-4 h-4 text-green-600 dark:text-green-400" /> : <Copy className="w-4 h-4" />}
    </button>
  );

  // Handle clicks within the HTML content (Event Delegation)
  const handleContentClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const target = e.target as HTMLElement;
    const btn = target.closest('button[data-action]');
    
    if (btn) {
        e.preventDefault();
        const action = btn.getAttribute('data-action');
        const query = btn.getAttribute('data-query') || '';

        if (action === 'custom-search') {
            const newQuery = window.prompt("Nhập từ khóa tìm kiếm ảnh:", query);
            if (newQuery) {
                window.open(`https://www.google.com/search?tbm=isch&q=${encodeURIComponent(newQuery)}`, '_blank');
            }
        } else if (action === 'copy-prompt') {
            const prompt = `Professional product photography of ${query}, studio lighting, high resolution, 4k, photorealistic`;
            navigator.clipboard.writeText(prompt);
            alert("Đã copy Prompt tạo ảnh vào Clipboard:\n\n" + prompt);
        }
    }
  };

  // Helper to inject Image Highlight styles
  const processHtml = (html: string) => {
      // Replace [IMAGE: ...] with a styled block containing interactive buttons
      return html.replace(
          /\[IMAGE:\s*(.*?)\]/g, 
          (match, description) => {
              const cleanDesc = description.trim();
              const query = encodeURIComponent(cleanDesc);
              
              // We use SVG icons directly in string to avoid React hydration issues in dangerouslySetInnerHTML
              return `
              <div class="block my-6 p-4 bg-yellow-50 dark:bg-yellow-900/20 border-l-4 border-yellow-400 dark:border-yellow-600 rounded-r-lg shadow-sm group font-sans not-prose">
                <div class="flex items-start gap-3">
                     <span class="mt-0.5 p-1.5 bg-yellow-200 dark:bg-yellow-800 rounded text-yellow-700 dark:text-yellow-300 shrink-0">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                     </span>
                     <div class="flex-1 min-w-0">
                        <div class="mb-2">
                            <strong class="block text-sm font-bold text-yellow-800 dark:text-yellow-100 mb-0.5">Cần chèn ảnh</strong>
                            <span class="block text-sm italic text-yellow-900 dark:text-yellow-200/90 break-words">"${cleanDesc}"</span>
                        </div>
                        
                        <div class="flex flex-wrap gap-2">
                            <a href="https://www.google.com/search?tbm=isch&q=${query}" target="_blank" rel="noopener noreferrer" class="inline-flex items-center px-2.5 py-1.5 rounded text-xs font-medium border border-yellow-300 dark:border-yellow-700 bg-yellow-100 dark:bg-yellow-800/40 text-yellow-800 dark:text-yellow-100 hover:bg-yellow-200 dark:hover:bg-yellow-700 transition-colors no-underline">
                                <svg class="w-3.5 h-3.5 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                                Google Images
                            </a>
                            
                            <button type="button" data-action="custom-search" data-query="${cleanDesc.replace(/"/g, '&quot;')}" class="inline-flex items-center px-2.5 py-1.5 rounded text-xs font-medium border border-yellow-300 dark:border-yellow-700 bg-white dark:bg-slate-800 text-yellow-800 dark:text-yellow-100 hover:bg-yellow-50 dark:hover:bg-slate-700 transition-colors cursor-pointer">
                                <svg class="w-3.5 h-3.5 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                                Sửa từ khóa
                            </button>

                            <button type="button" data-action="copy-prompt" data-query="${cleanDesc.replace(/"/g, '&quot;')}" class="inline-flex items-center px-2.5 py-1.5 rounded text-xs font-medium border border-purple-300 dark:border-purple-700 bg-purple-50 dark:bg-purple-900/30 text-purple-800 dark:text-purple-100 hover:bg-purple-100 dark:hover:bg-purple-800 transition-colors cursor-pointer">
                                <svg class="w-3.5 h-3.5 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"></path></svg>
                                Copy Prompt
                            </button>
                        </div>
                     </div>
                </div>
              </div>`;
          }
      );
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-5xl max-h-[90vh] flex flex-col animate-in fade-in zoom-in-95 duration-200 transition-colors">
        
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-700 flex flex-col md:flex-row justify-between items-start md:items-center bg-slate-50 dark:bg-slate-800 rounded-t-2xl gap-4">
          <div className="flex-1">
             <div className="flex items-center gap-2 mb-1">
                {(content.category || content.brand) && (
                    <div className="flex gap-2">
                        {content.category && <span className="text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400 bg-slate-200 dark:bg-slate-700 px-2 py-0.5 rounded tracking-wider">{content.category}</span>}
                        {content.brand && <span className="text-[10px] uppercase font-bold text-blue-600 dark:text-blue-400 bg-blue-100 dark:bg-blue-900/50 px-2 py-0.5 rounded tracking-wider">{content.brand}</span>}
                    </div>
                )}
             </div>
             <h3 className="text-lg font-bold text-slate-800 dark:text-white truncate max-w-md md:max-w-xl">
                {content.product_name_optimized}
             </h3>
          </div>
          
          <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
             <div className="flex space-x-1 bg-slate-200 dark:bg-slate-700 p-1 rounded-lg">
                <button 
                    onClick={() => setActiveTab('content')}
                    className={`px-3 py-1 rounded-md text-sm font-medium transition-all ${activeTab === 'content' ? 'bg-white dark:bg-slate-600 text-blue-700 dark:text-blue-300 shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'}`}
                >
                    <div className="flex items-center space-x-1">
                        <FileText className="w-4 h-4" />
                        <span>Nội dung</span>
                    </div>
                </button>
                <button 
                    onClick={() => setActiveTab('schema')}
                    className={`px-3 py-1 rounded-md text-sm font-medium transition-all ${activeTab === 'schema' ? 'bg-white dark:bg-slate-600 text-purple-700 dark:text-purple-300 shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'}`}
                >
                    <div className="flex items-center space-x-1">
                        <Code className="w-4 h-4" />
                        <span>Schema JSON-LD</span>
                    </div>
                </button>
             </div>
             <button 
                onClick={onClose}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-full transition-colors"
             >
                <X className="w-6 h-6" />
             </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-50/50 dark:bg-slate-900 prose-preview">
          
          {activeTab === 'content' ? (
            <div className="space-y-6">
                {/* SEO Meta */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2 relative group bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                        <label className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider flex items-center">
                            Title Tag (SEO)
                            <span className="ml-2 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 text-[10px] px-2 py-0.5 rounded-full">{content.meta_title.length} chars</span>
                        </label>
                        <div className="text-sm text-slate-900 dark:text-slate-100 font-medium">
                            {content.meta_title}
                        </div>
                        <CopyButton text={content.meta_title} id="meta_title" />
                    </div>
                    <div className="space-y-2 relative group bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                        <label className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider flex items-center">
                            Meta Description
                            <span className="ml-2 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 text-[10px] px-2 py-0.5 rounded-full">{content.meta_description.length} chars</span>
                        </label>
                        <div className="text-sm text-slate-900 dark:text-slate-300">
                            {content.meta_description}
                        </div>
                        <CopyButton text={content.meta_description} id="meta_desc" />
                    </div>
                </div>

                {/* Pros & Cons Analysis */}
                {content.pros_cons && (content.pros_cons.pros.length > 0 || content.pros_cons.cons.length > 0) && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                         <div className="bg-green-50 dark:bg-green-900/20 border border-green-100 dark:border-green-800/50 rounded-xl p-4">
                            <h4 className="flex items-center text-green-800 dark:text-green-400 font-bold mb-3">
                                <ThumbsUp className="w-4 h-4 mr-2" /> Ưu điểm
                            </h4>
                            <ul className="space-y-1">
                                {content.pros_cons.pros.map((p, i) => (
                                    <li key={i} className="text-sm text-green-900 dark:text-green-200 flex items-start">
                                        <span className="mr-2 text-green-700 dark:text-green-500">•</span> {p}
                                    </li>
                                ))}
                            </ul>
                         </div>
                         <div className="bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-800/50 rounded-xl p-4">
                            <h4 className="flex items-center text-red-800 dark:text-red-400 font-bold mb-3">
                                <ThumbsDown className="w-4 h-4 mr-2" /> Nhược điểm
                            </h4>
                            <ul className="space-y-1">
                                {content.pros_cons.cons.map((c, i) => (
                                    <li key={i} className="text-sm text-red-900 dark:text-red-200 flex items-start">
                                        <span className="mr-2 text-red-700 dark:text-red-500">•</span> {c}
                                    </li>
                                ))}
                            </ul>
                         </div>
                    </div>
                )}

                {/* Short Desc */}
                <div className="space-y-2 relative group bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                    <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Short Description (HTML)</label>
                    <div 
                        className="bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-600 rounded p-3 text-sm prose prose-sm prose-slate dark:prose-invert max-w-none text-slate-900 dark:text-slate-200 force-text-black" 
                        dangerouslySetInnerHTML={{ __html: content.short_description_html }} 
                    />
                    <CopyButton text={content.short_description_html} id="short_desc" />
                </div>

                {/* Main Content */}
                <div className="space-y-2 relative group bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                    <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider flex items-center justify-between">
                        <span>Main Content (HTML)</span>
                        <span className="text-[10px] font-normal text-slate-400">Preview rendering below</span>
                    </label>
                    <div className="relative">
                        <div className="absolute top-0 right-0 z-10">
                             <CopyButton text={content.long_description_html} id="long_desc" className="!static" />
                        </div>
                        <div 
                            className="mt-2 border border-slate-100 dark:border-slate-600 rounded-lg p-6 prose prose-blue prose-slate dark:prose-invert max-w-none bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-200 force-text-black"
                            onClick={handleContentClick}
                        >
                            <div dangerouslySetInnerHTML={{ __html: processHtml(content.long_description_html) }} />
                        </div>
                    </div>
                </div>

                {/* Specs */}
                <div className="space-y-2 relative group bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                    <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Thông số kỹ thuật (HTML Table)</label>
                    <div className="mt-2 overflow-x-auto">
                        <div 
                            className="prose prose-sm prose-slate dark:prose-invert max-w-none text-slate-900 dark:text-slate-200 force-text-black" 
                            dangerouslySetInnerHTML={{ __html: content.specifications_html }} 
                        />
                    </div>
                    <CopyButton text={content.specifications_html} id="specs" />
                </div>
            </div>
          ) : (
            <div className="space-y-6 animate-in fade-in duration-300">
                <div className="bg-purple-50 dark:bg-purple-900/20 border border-purple-100 dark:border-purple-800 rounded-xl p-6">
                    <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-4">
                            <div className="p-3 bg-purple-100 dark:bg-purple-900/50 rounded-full text-purple-600 dark:text-purple-300">
                                <Code className="w-6 h-6" />
                            </div>
                            <div>
                                <h4 className="text-lg font-bold text-purple-900 dark:text-purple-200">Schema Markup (JSON-LD)</h4>
                                <p className="text-sm text-purple-700 dark:text-purple-300 mt-1">
                                    Copy đoạn mã này và dán vào thẻ <code className="bg-purple-200 dark:bg-purple-900 px-1 rounded text-purple-900 dark:text-purple-200">&lt;head&gt;</code> hoặc <code className="bg-purple-200 dark:bg-purple-900 px-1 rounded text-purple-900 dark:text-purple-200">&lt;body&gt;</code> của trang sản phẩm.
                                </p>
                            </div>
                        </div>
                        <button
                          onClick={() => handleCopy(`<script type="application/ld+json">\n${JSON.stringify(content.schema_markup, null, 2)}\n</script>`, 'schema_full')}
                          className="flex items-center space-x-2 bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors shadow-sm"
                        >
                            {copied === 'schema_full' ? (
                                <>
                                    <Check className="w-4 h-4" />
                                    <span>Đã copy</span>
                                </>
                            ) : (
                                <>
                                    <Copy className="w-4 h-4" />
                                    <span>Copy Script</span>
                                </>
                            )}
                        </button>
                    </div>
                </div>

                <div className="relative group">
                    <pre className="bg-slate-900 text-slate-50 p-6 rounded-xl overflow-x-auto font-mono text-sm leading-relaxed shadow-inner">
                        <code className="language-html">
{`<script type="application/ld+json">
${JSON.stringify(content.schema_markup, null, 2)}
</script>`}
                        </code>
                    </pre>
                </div>
                
                {content.faq_list.length > 0 && (
                    <div className="mt-4">
                        <h4 className="font-bold text-slate-700 dark:text-slate-300 mb-3">Nội dung FAQ (Đã bao gồm trong Schema trên)</h4>
                        <div className="space-y-3">
                            {content.faq_list.map((f, i) => (
                                <div key={i} className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-4 rounded-lg">
                                    <p className="font-semibold text-blue-700 dark:text-blue-400">Q: {f.question}</p>
                                    <p className="text-slate-900 dark:text-slate-200 mt-1">A: {f.answer}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>
          )}

        </div>
        
        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 rounded-b-2xl flex justify-between items-center">
          <div className="flex items-center space-x-2 text-xs text-slate-500 dark:text-slate-400">
             <span className="bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-200 px-2 py-1 rounded-full font-medium">Auto SEO v2.0</span>
             <span>• Generated by Gemini AI</span>
          </div>
          <button 
            onClick={onClose}
            className="px-6 py-2 bg-slate-800 hover:bg-slate-900 dark:bg-blue-600 dark:hover:bg-blue-700 text-white rounded-lg font-medium transition-colors shadow-lg shadow-slate-300/50 dark:shadow-none"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};