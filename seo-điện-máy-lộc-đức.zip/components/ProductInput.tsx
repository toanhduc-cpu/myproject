import React, { useState, useRef } from 'react';
import { Upload, Play, Trash2, ListPlus, PauseCircle, Settings2, FileSpreadsheet, Link as LinkIcon, Type, FileUp, XCircle, CheckCircle2 } from 'lucide-react';
import { ModelType } from '../types';
import * as XLSX from 'xlsx';

interface ProductInputProps {
  onStartProcessing: (products: string[], model: ModelType) => void;
  processingStatus: 'idle' | 'running' | 'paused';
  onClearQueue: () => void;
}

type InputMode = 'text' | 'file' | 'url';

export const ProductInput: React.FC<ProductInputProps> = ({ onStartProcessing, processingStatus, onClearQueue }) => {
  const [inputMode, setInputMode] = useState<InputMode>('text');
  const [selectedModel, setSelectedModel] = useState<ModelType>(ModelType.FLASH);
  
  // Text Mode State
  const [inputText, setInputText] = useState('');

  // File Mode State
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);
  const [parsedFileProducts, setParsedFileProducts] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // URL Mode State
  const [sheetUrl, setSheetUrl] = useState('');
  const [urlStatus, setUrlStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [urlMessage, setUrlMessage] = useState('');
  const [parsedUrlProducts, setParsedUrlProducts] = useState<string[]>([]);

  // --- HANDLERS ---

  const handleStart = () => {
    let products: string[] = [];

    if (inputMode === 'text') {
        products = inputText.split('\n').map(p => p.trim()).filter(p => p.length > 0);
    } else if (inputMode === 'file') {
        products = parsedFileProducts;
    } else if (inputMode === 'url') {
        products = parsedUrlProducts;
    }

    if (products.length > 0) {
      onStartProcessing(products, selectedModel);
      
      // Clear states after start
      setInputText('');
      setUploadedFileName(null);
      setParsedFileProducts([]);
      if (fileInputRef.current) fileInputRef.current.value = '';
      setParsedUrlProducts([]);
      setSheetUrl('');
      setUrlStatus('idle');
    }
  };

  const loadSampleData = () => {
    const samples = [
        "Máy giặt LG Inverter 9 kg FV1409S4W",
        "Tủ lạnh Samsung Inverter 236 lít RT22M4032BY/SV",
        "Điều hòa Daikin 9000BTU 1 chiều FTKB25XVMV"
    ];
    
    if (inputMode === 'text') {
        setInputText(samples.join('\n'));
    } else {
        setInputMode('text');
        setInputText(samples.join('\n'));
    }
  }

  // --- FILE HANDLING ---
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      setUploadedFileName(file.name);
      
      try {
          const data = await file.arrayBuffer();
          const workbook = XLSX.read(data);
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          
          // Convert to JSON (array of arrays)
          const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][];
          
          // Extract data: Assume the first column contains product names
          // Filter out empty rows and header if it looks like "Product Name" etc.
          const products: string[] = [];
          
          for (let i = 0; i < jsonData.length; i++) {
              const row = jsonData[i];
              if (row && row.length > 0) {
                  const val = String(row[0]).trim();
                  // Simple heuristic to skip header: if row is index 0 and contains "Tên" or "Name"
                  if (i === 0 && (val.toLowerCase().includes('tên') || val.toLowerCase().includes('name') || val.toLowerCase().includes('product'))) {
                      continue;
                  }
                  if (val) products.push(val);
              }
          }

          if (products.length === 0) {
              alert("Không tìm thấy dữ liệu trong file. Vui lòng kiểm tra lại cột A của file Excel.");
              setUploadedFileName(null);
              setParsedFileProducts([]);
          } else {
              setParsedFileProducts(products);
          }

      } catch (error) {
          console.error(error);
          alert("Lỗi đọc file. Hãy đảm bảo file đúng định dạng Excel (.xlsx, .xls) hoặc CSV.");
          setUploadedFileName(null);
          setParsedFileProducts([]);
      }
  };

  // --- URL HANDLING ---
  const handleUrlParse = async () => {
      if (!sheetUrl) return;

      // Extract Sheet ID
      // Matches: /d/SHEET_ID/
      const match = sheetUrl.match(/\/d\/(.*?)(\/|$)/);
      if (!match) {
          setUrlStatus('error');
          setUrlMessage("Link không hợp lệ. Hãy dùng link Google Sheets chuẩn.");
          return;
      }
      
      const sheetId = match[1];
      const csvUrl = `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=csv`;

      setUrlStatus('loading');
      setUrlMessage("Đang tải dữ liệu...");

      try {
          const response = await fetch(csvUrl);
          if (!response.ok) {
              throw new Error("Không thể truy cập. Hãy chắc chắn Sheet đã được chia sẻ công khai (Anyone with the link).");
          }
          const text = await response.text();
          
          // Simple CSV Parse
          const lines = text.split('\n');
          const products = lines
            .map(line => {
                // Handle basic CSV quotes
                const col1 = line.split(',')[0];
                return col1.replace(/^"|"$/g, '').trim();
            })
            .filter(p => p.length > 0 && !p.toLowerCase().includes('tên sản phẩm')); // Filter header heuristics

          if (products.length > 0) {
              setParsedUrlProducts(products);
              setUrlStatus('success');
              setUrlMessage(`Đã tìm thấy ${products.length} sản phẩm.`);
          } else {
              setUrlStatus('error');
              setUrlMessage("File trống hoặc không đọc được cột đầu tiên.");
          }

      } catch (error: any) {
          setUrlStatus('error');
          setUrlMessage("Lỗi: " + (error.message || "CORS Blocked. Hãy thử File Upload."));
      }
  };

  // --- RENDER HELPERS ---
  const getProductCount = () => {
      if (inputMode === 'text') return inputText.split('\n').filter(x => x.trim()).length;
      if (inputMode === 'file') return parsedFileProducts.length;
      if (inputMode === 'url') return parsedUrlProducts.length;
      return 0;
  };

  const productCount = getProductCount();
  
  // Determine button state visuals
  const getButtonConfig = () => {
    const disabled = productCount === 0;

    if (disabled) {
       return {
         text: 'Tạo Nội Dung SEO',
         icon: <Play className="w-5 h-5 mr-2" />,
         className: 'bg-slate-400 dark:bg-slate-600 cursor-not-allowed',
         disabled: true
       };
    }

    switch (processingStatus) {
      case 'running':
        return {
          text: `Thêm ${productCount} SP vào hàng đợi`,
          icon: <ListPlus className="w-5 h-5 mr-2" />,
          className: 'bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white transform hover:-translate-y-0.5',
          disabled: false
        };
      case 'paused':
        return {
          text: `Thêm ${productCount} SP (Đang tạm dừng)`,
          icon: <PauseCircle className="w-5 h-5 mr-2" />,
          className: 'bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white transform hover:-translate-y-0.5',
          disabled: false
        };
      default: // idle
        return {
          text: `Bắt đầu tạo (${productCount} SP)`,
          icon: <Play className="w-5 h-5 mr-2" />,
          className: 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white transform hover:-translate-y-0.5',
          disabled: false
        };
    }
  };

  const btnConfig = getButtonConfig();

  return (
    <div className="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 p-6 mb-8 transition-colors">
      
      {/* HEADER */}
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-lg font-semibold text-slate-800 dark:text-slate-100 flex items-center">
          <Upload className="w-5 h-5 mr-2 text-blue-600 dark:text-blue-400" />
          Nguồn dữ liệu
        </h2>
        <div className="flex space-x-3">
             <button 
                onClick={onClearQueue}
                className="text-xs text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 font-medium flex items-center"
                title="Xóa danh sách hàng đợi"
            >
                <Trash2 className="w-3 h-3 mr-1" /> Xóa
            </button>
            <button 
                onClick={loadSampleData}
                className="text-sm text-blue-600 hover:underline hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 font-medium"
            >
                Mẫu thử
            </button>
        </div>
      </div>

      {/* TABS */}
      <div className="flex space-x-1 mb-4 bg-slate-100 dark:bg-slate-900/50 p-1 rounded-lg">
          <button
            onClick={() => setInputMode('text')}
            className={`flex-1 flex items-center justify-center py-2 text-sm font-medium rounded-md transition-all ${inputMode === 'text' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-300 shadow-sm' : 'text-slate-500 hover:text-slate-700 dark:text-slate-400'}`}
          >
              <Type className="w-4 h-4 mr-2" /> Nhập Text
          </button>
          <button
            onClick={() => setInputMode('file')}
            className={`flex-1 flex items-center justify-center py-2 text-sm font-medium rounded-md transition-all ${inputMode === 'file' ? 'bg-white dark:bg-slate-700 text-green-600 dark:text-green-300 shadow-sm' : 'text-slate-500 hover:text-slate-700 dark:text-slate-400'}`}
          >
              <FileSpreadsheet className="w-4 h-4 mr-2" /> Excel / CSV
          </button>
          <button
            onClick={() => setInputMode('url')}
            className={`flex-1 flex items-center justify-center py-2 text-sm font-medium rounded-md transition-all ${inputMode === 'url' ? 'bg-white dark:bg-slate-700 text-orange-600 dark:text-orange-300 shadow-sm' : 'text-slate-500 hover:text-slate-700 dark:text-slate-400'}`}
          >
              <LinkIcon className="w-4 h-4 mr-2" /> Google Sheets
          </button>
      </div>

      {/* INPUT AREA */}
      <div className="mb-6">
          {inputMode === 'text' && (
             <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Nhập tên mỗi sản phẩm trên một dòng...&#10;Ví dụ:&#10;Máy giặt LG Inverter 9 kg FV1409S4W&#10;Tủ lạnh Samsung RT22M4032BY/SV"
                className="w-full h-40 p-4 border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-sm resize-y animate-in fade-in duration-200"
            />
          )}

          {inputMode === 'file' && (
             <div className="bg-slate-50 dark:bg-slate-900/50 border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-lg h-40 flex flex-col items-center justify-center animate-in fade-in duration-200 relative">
                 <input 
                    type="file" 
                    accept=".xlsx, .xls, .csv" 
                    onChange={handleFileUpload}
                    ref={fileInputRef}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                 />
                 {uploadedFileName ? (
                     <div className="text-center z-10 pointer-events-none">
                         <FileSpreadsheet className="w-10 h-10 text-green-500 mx-auto mb-2" />
                         <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">{uploadedFileName}</p>
                         <p className="text-xs text-slate-500 mt-1">Tìm thấy {parsedFileProducts.length} sản phẩm</p>
                     </div>
                 ) : (
                    <div className="text-center z-10 pointer-events-none">
                        <FileUp className="w-10 h-10 text-slate-400 mx-auto mb-2" />
                        <p className="text-sm font-medium text-slate-600 dark:text-slate-300">Kéo thả hoặc click để tải file</p>
                        <p className="text-xs text-slate-400 mt-1">Hỗ trợ .xlsx, .xls, .csv (Đọc cột đầu tiên)</p>
                    </div>
                 )}
             </div>
          )}

          {inputMode === 'url' && (
              <div className="h-40 flex flex-col justify-center animate-in fade-in duration-200">
                  <div className="relative">
                    <input 
                        type="text" 
                        value={sheetUrl}
                        onChange={(e) => setSheetUrl(e.target.value)}
                        placeholder="Dán link Google Sheets (Công khai)..."
                        className="w-full pl-10 pr-24 py-3 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    />
                    <LinkIcon className="absolute left-3 top-3.5 w-5 h-5 text-slate-400" />
                    <button 
                        onClick={handleUrlParse}
                        disabled={!sheetUrl}
                        className="absolute right-2 top-2 px-3 py-1.5 bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold rounded-md disabled:bg-slate-300 dark:disabled:bg-slate-700 transition-colors"
                    >
                        Kiểm tra
                    </button>
                  </div>
                  
                  {/* Status Messages */}
                  <div className="mt-3">
                      {urlStatus === 'loading' && <p className="text-xs text-blue-600 dark:text-blue-400 flex items-center"><span className="animate-spin mr-2">⏳</span> Đang tải dữ liệu...</p>}
                      {urlStatus === 'error' && <p className="text-xs text-red-500 flex items-center"><XCircle className="w-3 h-3 mr-1" /> {urlMessage}</p>}
                      {urlStatus === 'success' && <p className="text-xs text-green-600 dark:text-green-400 flex items-center"><CheckCircle2 className="w-3 h-3 mr-1" /> {urlMessage}</p>}
                      {urlStatus === 'idle' && <p className="text-[10px] text-slate-400 italic mt-1">* Lưu ý: Google Sheet phải ở chế độ "Bất kỳ ai có đường liên kết" (Anyone with the link).</p>}
                  </div>
              </div>
          )}
      </div>

      {/* CONTROLS */}
      <div className="space-y-4">
        <div className="bg-slate-50 dark:bg-slate-700/50 p-3 rounded-lg border border-slate-100 dark:border-slate-700">
             <label className="text-sm font-medium text-slate-700 dark:text-slate-300 flex items-center gap-2 mb-2">
                <Settings2 className="w-4 h-4 text-slate-500" />
                Cấu hình AI:
             </label>
             <select 
                value={selectedModel}
                onChange={(e) => setSelectedModel(e.target.value as ModelType)}
                className="bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
             >
                <option value={ModelType.FLASH}>Gemini 2.5 Flash (Tốc độ nhanh - Khuyên dùng)</option>
                <option value={ModelType.PRO}>Gemini 2.0 Pro (Thông minh hơn - Chậm hơn)</option>
             </select>
        </div>

        <button
          onClick={handleStart}
          disabled={btnConfig.disabled}
          className={`flex items-center justify-center px-6 py-3 rounded-xl font-bold shadow-lg transition-all w-full ${btnConfig.className}`}
        >
            {btnConfig.icon}
            {btnConfig.text}
        </button>
      </div>
    </div>
  );
};