import React, { useState, useMemo } from 'react';
import { CheckCircle, AlertCircle, Clock, Eye, Download, Loader2, Pause, Play, Square, Filter } from 'lucide-react';
import { ProcessingItem } from '../types';

interface ResultTableProps {
  items: ProcessingItem[];
  onView: (item: ProcessingItem) => void;
  onExport: () => void;
  processingStatus: 'idle' | 'running' | 'paused';
  onPause: () => void;
  onResume: () => void;
  onStop: () => void;
}

export const ResultTable: React.FC<ResultTableProps> = ({ 
    items, onView, onExport, 
    processingStatus, onPause, onResume, onStop 
}) => {
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterBrand, setFilterBrand] = useState<string>('all');

  // Extract unique categories and brands from successful items
  const { categories, brands } = useMemo(() => {
    const cats = new Set<string>();
    const brs = new Set<string>();
    items.forEach(item => {
      if (item.status === 'success' && item.result) {
        if (item.result.category) cats.add(item.result.category);
        if (item.result.brand) brs.add(item.result.brand);
      }
    });
    return {
      categories: Array.from(cats).sort(),
      brands: Array.from(brs).sort()
    };
  }, [items]);

  // Filter items logic
  const filteredItems = useMemo(() => {
    return items.filter(item => {
      if (filterCategory === 'all' && filterBrand === 'all') return true;
      if (item.status !== 'success' || !item.result) return false;
      const matchCategory = filterCategory === 'all' || item.result.category === filterCategory;
      const matchBrand = filterBrand === 'all' || item.result.brand === filterBrand;
      return matchCategory && matchBrand;
    });
  }, [items, filterCategory, filterBrand]);

  if (items.length === 0) return null;

  const completedCount = items.filter(i => i.status === 'success').length;
  const errorCount = items.filter(i => i.status === 'error').length;
  const pendingCount = items.filter(i => i.status === 'idle').length;

  return (
    <div className="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 overflow-hidden transition-colors">
      <div className="p-4 sm:p-6 border-b border-slate-100 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 space-y-4">
        
        {/* Top Row: Title, Stats, Controls */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">Tiến độ xử lý</h3>
                {processingStatus === 'running' && <span className="text-[10px] font-bold text-white bg-blue-500 px-2 py-0.5 rounded-full animate-pulse">RUNNING</span>}
                {processingStatus === 'paused' && <span className="text-[10px] font-bold text-white bg-yellow-500 px-2 py-0.5 rounded-full">PAUSED</span>}
            </div>
            <div className="flex space-x-3 mt-1 text-xs">
               <span className="text-green-600 dark:text-green-400 font-medium">Xong: {completedCount}</span>
               <span className="text-red-600 dark:text-red-400 font-medium">Lỗi: {errorCount}</span>
               <span className="text-slate-500 dark:text-slate-400">Chờ: {pendingCount}</span>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
                {/* Control Buttons */}
                {processingStatus === 'running' && (
                     <button 
                        onClick={onPause}
                        className="flex items-center space-x-1 px-3 py-1.5 bg-yellow-100 hover:bg-yellow-200 text-yellow-700 rounded-lg transition-colors text-xs font-semibold"
                        title="Tạm dừng sau khi xử lý xong item hiện tại"
                    >
                        <Pause className="w-4 h-4" /> <span>Tạm dừng</span>
                    </button>
                )}
                
                {processingStatus === 'paused' && (
                     <button 
                        onClick={onResume}
                        className="flex items-center space-x-1 px-3 py-1.5 bg-blue-100 hover:bg-blue-200 text-blue-700 rounded-lg transition-colors text-xs font-semibold"
                        title="Tiếp tục xử lý"
                    >
                        <Play className="w-4 h-4" /> <span>Tiếp tục</span>
                    </button>
                )}

                {(processingStatus === 'running' || processingStatus === 'paused') && (
                     <button 
                        onClick={onStop}
                        className="flex items-center space-x-1 px-3 py-1.5 bg-red-100 hover:bg-red-200 text-red-700 rounded-lg transition-colors text-xs font-semibold"
                        title="Dừng hẳn quy trình"
                    >
                        <Square className="w-4 h-4" /> <span>Dừng</span>
                    </button>
                )}

              {(completedCount > 0) && (
                  <button 
                      onClick={onExport}
                      className="flex items-center space-x-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors shadow-sm ml-2"
                  >
                      <Download className="w-4 h-4" />
                      <span className="hidden sm:inline">Xuất Excel</span>
                  </button>
              )}
          </div>
        </div>

        {/* Bottom Row: Filters */}
        {(categories.length > 0 || brands.length > 0) && (
            <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-slate-200 dark:border-slate-700/50">
                <div className="flex items-center text-xs text-slate-500 dark:text-slate-400 font-medium">
                    <Filter className="w-3 h-3 mr-1" /> Bộ lọc:
                </div>
                
                {categories.length > 0 && (
                    <select
                        value={filterCategory}
                        onChange={(e) => setFilterCategory(e.target.value)}
                        className="bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-200 text-xs rounded-md px-2 py-1 focus:ring-1 focus:ring-blue-500 outline-none"
                    >
                        <option value="all">Tất cả danh mục</option>
                        {categories.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                )}

                {brands.length > 0 && (
                    <select
                        value={filterBrand}
                        onChange={(e) => setFilterBrand(e.target.value)}
                        className="bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-200 text-xs rounded-md px-2 py-1 focus:ring-1 focus:ring-blue-500 outline-none"
                    >
                        <option value="all">Tất cả thương hiệu</option>
                        {brands.map(b => <option key={b} value={b}>{b}</option>)}
                    </select>
                )}
                
                {(filterCategory !== 'all' || filterBrand !== 'all') && (
                    <button 
                        onClick={() => { setFilterCategory('all'); setFilterBrand('all'); }}
                        className="text-xs text-blue-600 dark:text-blue-400 hover:underline"
                    >
                        Xóa lọc
                    </button>
                )}
            </div>
        )}
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
          <thead className="bg-slate-50 dark:bg-slate-700 text-slate-700 dark:text-slate-200 font-semibold uppercase text-xs">
            <tr>
              <th className="px-6 py-4">Sản phẩm</th>
              <th className="px-6 py-4">Phân loại</th>
              <th className="px-6 py-4">Trạng thái</th>
              <th className="px-6 py-4 text-right">Thao tác</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-700">
            {filteredItems.map((item) => (
              <tr key={item.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">
                <td className="px-6 py-4 font-medium text-slate-900 dark:text-white max-w-md">
                  <div className="truncate" title={item.originalName}>{item.originalName}</div>
                  {item.result && (
                     <div className="text-xs text-blue-600 dark:text-blue-400 font-normal mt-1 truncate" title={item.result.product_name_optimized}>
                        → {item.result.product_name_optimized}
                     </div>
                  )}
                </td>
                <td className="px-6 py-4">
                    {item.result ? (
                        <div className="flex flex-col gap-1">
                            {item.result.category && (
                                <span className="inline-flex w-fit items-center px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 dark:bg-slate-600 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-500">
                                    {item.result.category}
                                </span>
                            )}
                            {item.result.brand && (
                                <span className="inline-flex w-fit items-center px-2 py-0.5 rounded text-[10px] font-medium bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-blue-800">
                                    {item.result.brand}
                                </span>
                            )}
                        </div>
                    ) : (
                        <span className="text-xs text-slate-400">-</span>
                    )}
                </td>
                <td className="px-6 py-4">
                  {item.status === 'idle' && (
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 dark:bg-slate-700 text-slate-800 dark:text-slate-300">
                      <Clock className="w-3 h-3 mr-1" /> Chờ xử lý
                    </span>
                  )}
                  {item.status === 'generating' && (
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 dark:bg-blue-900/40 text-blue-800 dark:text-blue-200 animate-pulse">
                      <Loader2 className="w-3 h-3 mr-1 animate-spin" /> Đang viết...
                    </span>
                  )}
                  {item.status === 'success' && (
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900/40 text-green-800 dark:text-green-200">
                      <CheckCircle className="w-3 h-3 mr-1" /> Hoàn thành
                    </span>
                  )}
                  {item.status === 'error' && (
                    <div className="flex flex-col items-start">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 dark:bg-red-900/40 text-red-800 dark:text-red-200">
                            <AlertCircle className="w-3 h-3 mr-1" /> Lỗi
                        </span>
                        <span className="text-[10px] text-red-500 mt-1 max-w-[200px] truncate" title={item.error}>
                            {item.error}
                        </span>
                    </div>
                  )}
                </td>
                <td className="px-6 py-4 text-right">
                  {item.status === 'success' && (
                    <button
                      onClick={() => onView(item)}
                      className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 font-medium inline-flex items-center transition-colors"
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      Xem
                    </button>
                  )}
                </td>
              </tr>
            ))}
            {filteredItems.length === 0 && items.length > 0 && (
                <tr>
                    <td colSpan={4} className="px-6 py-8 text-center text-slate-500 dark:text-slate-400 text-sm">
                        Không tìm thấy sản phẩm nào phù hợp với bộ lọc hiện tại.
                    </td>
                </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};