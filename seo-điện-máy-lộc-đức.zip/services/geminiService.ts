import { GoogleGenAI } from "@google/genai";
import { SEOContent, ModelType } from "../types";

const SYSTEM_INSTRUCTION = `
Bạn là Chuyên gia SEO & Content Manager cấp cao tại "Điện Máy Lộc Đức" (dienmaylocduc.vn).
Mục tiêu: Viết nội dung sản phẩm đạt chuẩn E-E-A-T (Kinh nghiệm - Chuyên môn - Thẩm quyền - Tin cậy) của Google.

Nguyên tắc viết bài:
1. **Search Intent:** Tập trung vào người dùng muốn mua hàng (Transactional Intent).
2. **Ngôn ngữ:** Tiếng Việt tự nhiên, chuyên nghiệp nhưng gần gũi. Dùng từ ngữ kích thích cảm xúc (Power words).
3. **Định dạng:** Sử dụng HTML semantic (h2, h3, ul, li, strong) để Google dễ đọc.
4. **Trung thực:** Thông số kỹ thuật phải chính xác tuyệt đối. Nếu không chắc chắn, hãy tìm kiếm kỹ.
`;

const wait = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

/**
 * Attempts to repair malformed JSON strings, specifically fixing unescaped control characters
 * (newlines, tabs) inside string literals, which often crash JSON.parse.
 */
function repairJson(jsonStr: string): string {
    let result = "";
    let inString = false;
    let escaped = false;
    
    for (let i = 0; i < jsonStr.length; i++) {
        const char = jsonStr[i];
        
        if (char === '"' && !escaped) {
            inString = !inString;
        }
        
        if (char === '\\' && !escaped) {
            escaped = true;
            result += char;
            continue;
        }
        
        if (escaped) {
            escaped = false;
        }
        
        if (inString) {
             if (char === '\n') {
                 result += "\\n";
             } else if (char === '\r') {
                 // skip CR inside string
             } else if (char === '\t') {
                 result += "\\t";
             } else {
                 result += char;
             }
        } else {
            result += char;
        }
    }
    return result;
}

export const generateSEOContent = async (
  productName: string,
  model: ModelType = ModelType.FLASH
): Promise<SEOContent> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("Chưa cấu hình API Key. Vui lòng kiểm tra biến môi trường.");
  }

  const ai = new GoogleGenAI({ apiKey });
  
  // Retry configuration
  const MAX_RETRIES = 3;
  let lastError: any;

  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      const response = await ai.models.generateContent({
        model: model,
        contents: `Phân tích và viết nội dung SEO toàn diện cho sản phẩm: "${productName}".
        
        NHIỆM VỤ CỤ THỂ:
        1. **Tra cứu thông số:** Dùng Google Search tìm thông tin chính xác nhất về model này.
        2. **Phân loại:** Xác định chính xác loại sản phẩm (Category) và thương hiệu (Brand).
        3. **Cấu trúc bài viết (Main Content):**
           - Mở đầu: Lôi cuốn, nêu bật USP.
           - Thân bài: Chia nhỏ các tính năng bằng thẻ H2, H3. Dùng công thức "Tính năng -> Lợi ích".
           - **QUAN TRỌNG - ẢNH:** Tại mỗi phần tính năng chính, hãy chèn một placeholder cho ảnh theo định dạng: 
             [IMAGE: Mô tả chi tiết ảnh cần chèn]
             Ví dụ: [IMAGE: Hình ảnh tủ lạnh Samsung mở cửa thấy rõ các ngăn chứa thực phẩm]
           - Kết bài: Kêu gọi hành động (CTA), nhắc đến Hotline/Zalo Lộc Đức.
        4. **Phân tích Ưu/Nhược điểm:** Khách quan.
        5. **Schema Markup:** JSON-LD cho Product và FAQPage.

        ĐỊNH DẠNG ĐẦU RA (JSON Only):
        1. Trả về kết quả dưới dạng JSON hợp lệ.
        2. **TUYỆT ĐỐI KHÔNG** sử dụng phép nối chuỗi (dấu +) để ngắt dòng trong JSON. Tất cả giá trị chuỗi phải nằm trên một dòng hoặc sử dụng ký tự xuống dòng \\n bên trong chuỗi.
           - SAI: "text" + "text"
           - ĐÚNG: "text text"
        3. Bắt buộc đặt JSON trong thẻ code block để tránh lỗi định dạng:
           \`\`\`json
           { ... }
           \`\`\`
        4. QUY TẮC AN TOÀN JSON:
           - Với các thẻ HTML bên trong chuỗi JSON, hãy dùng dấu nháy đơn (') cho các thuộc tính HTML.
           - Đảm bảo thoát (escape) các ký tự đặc biệt đúng cách.
        
        Cấu trúc JSON yêu cầu:
        {
          "product_name_optimized": "Tên chuẩn SEO (H1)",
          "category": "Loại sản phẩm",
          "brand": "Thương hiệu",
          "meta_title": "Title Tag",
          "meta_description": "Meta Description",
          "short_description_html": "HTML <ul>...</ul>",
          "long_description_html": "HTML String (H2, H3, P...).",
          "specifications_html": "HTML String <table>...</table>",
          "pros_cons": {
            "pros": ["Ưu điểm 1", "Ưu điểm 2"],
            "cons": ["Nhược điểm"]
          },
          "faq_list": [
            { "question": "Hỏi", "answer": "Đáp" }
          ],
          "tags": ["tag1", "tag2"],
          "schema_markup": {
             "@context": "https://schema.org",
             "@type": "Product",
             "name": "Tên SP",
             "description": "Mô tả",
             "brand": { "@type": "Brand", "name": "Hãng" },
             "review": { 
                "@type": "Review", 
                "reviewRating": { "@type": "Rating", "ratingValue": "5" },
                "author": { "@type": "Person", "name": "Chuyên gia Lộc Đức" }
             }
          }
        }
        `,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          tools: [{ googleSearch: {} }],
        },
      });

      let text = response.text || "";
      
      // Clean up markdown code blocks if present (Model might still output them even with application/json)
      text = text.replace(/^```json\s*/i, "").replace(/^```\s*/i, "").replace(/```$/i, "");

      // FIX: Remove JS-style string concatenation (e.g. "str" + "ing") which is invalid in JSON but generated by some models
      // This regex matches: double quote, optional whitespace, plus sign, optional whitespace, double quote
      // It effectively joins the split strings.
      text = text.replace(/"\s*\+\s*"/g, "");

      // Robust JSON extraction
      const firstBrace = text.indexOf('{');
      const lastBrace = text.lastIndexOf('}');

      if (firstBrace === -1 || lastBrace === -1) {
        console.error("Format Error - No JSON braces found in:", text);
        throw new Error("AI trả về sai định dạng (Không tìm thấy JSON).");
      }

      const jsonString = text.substring(firstBrace, lastBrace + 1);

      try {
          const data = JSON.parse(jsonString) as SEOContent;
          
          // Data validation / Migration
          if (!data.pros_cons) data.pros_cons = { pros: [], cons: [] };
          if (!data.schema_markup) data.schema_markup = {};
          if (!data.category) data.category = "Khác";
          if (!data.brand) data.brand = "Khác";
          
          return data;
      } catch (parseError: any) {
          console.warn("Standard JSON Parse failed, attempting repair...", parseError.message);
          
          try {
              // Attempt to repair the JSON string
              const repairedJson = repairJson(jsonString);
              const data = JSON.parse(repairedJson) as SEOContent;
              
              // Validate again after repair
              if (!data.pros_cons) data.pros_cons = { pros: [], cons: [] };
              if (!data.schema_markup) data.schema_markup = {};
              if (!data.category) data.category = "Khác";
              if (!data.brand) data.brand = "Khác";

              return data;
          } catch (repairError: any) {
              console.error("JSON Repair Failed:", repairError);
              console.error("Bad JSON String:", jsonString);
              throw new Error(`Lỗi đọc dữ liệu JSON: ${parseError.message}`);
          }
      }
      
    } catch (error: any) {
      lastError = error;
      console.warn(`Attempt ${attempt} failed:`, error);
      
      const isClientError = error.message && error.message.includes("400");
      
      // Retry on 5xx or specific errors, but not on 400 (unless it's a specific fixable case, but INVALID_ARGUMENT is fatal for config)
      // Since we fixed the config, subsequent calls should not return 400 for this reason.
      if (attempt < MAX_RETRIES && !isClientError) {
        const backoff = attempt * 2000;
        console.log(`Retrying in ${backoff}ms...`);
        await wait(backoff);
        continue;
      }
    }
  }

  // Final Error Handling
  console.error("Gemini API Error Final:", lastError);
  const msg = lastError?.message || "Lỗi không xác định";
  
  if (msg.includes("500") || msg.includes("xhr error") || msg.includes("Rpc failed")) {
      throw new Error("Máy chủ Google đang bận (Lỗi 500). Vui lòng thử lại sau.");
  }
  if (msg.includes("429") || msg.includes("Quota")) {
      throw new Error("Đã vượt quá giới hạn API (Quota Exceeded). Vui lòng đợi 1 phút.");
  }
  if (msg.includes("400") || msg.includes("INVALID_ARGUMENT")) {
      throw new Error("Dữ liệu đầu vào không hợp lệ hoặc cấu hình API lỗi. Vui lòng kiểm tra lại mã nguồn.");
  }
  if (msg.includes("JSON")) {
      throw new Error("AI trả về dữ liệu lỗi định dạng. Vui lòng thử lại.");
  }
  
  throw new Error(`Lỗi xử lý: ${msg}`);
};