export interface FAQItem {
  question: string;
  answer: string;
}

export interface SEOContent {
  product_name_optimized: string;
  category: string;
  brand: string;
  meta_title: string;
  meta_description: string;
  short_description_html: string;
  long_description_html: string;
  specifications_html: string;
  faq_list: FAQItem[];
  tags: string[];
  // New SEO fields
  pros_cons: {
    pros: string[];
    cons: string[];
  };
  schema_markup: any; // Relaxed type to handle Object or Array
}

export interface ProcessingItem {
  id: string;
  originalName: string;
  status: 'idle' | 'generating' | 'success' | 'error';
  model: ModelType; // Store the selected model for this specific item
  result?: SEOContent;
  error?: string;
}

export enum ModelType {
  FLASH = 'gemini-2.5-flash',
  PRO = 'gemini-3-pro-preview'
}